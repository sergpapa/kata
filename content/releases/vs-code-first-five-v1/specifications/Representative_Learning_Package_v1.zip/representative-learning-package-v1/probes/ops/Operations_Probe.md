---
document_id: UNIT-OPS-001
version: "1.0.0"
slice_id: SL-OPS
module_placement: [M049, M050]
lesson_ids: [LS-OPS-01, LS-OPS-02, LS-OPS-03, LS-OPS-04]
status: "Author candidate; Docker rehearsal and qualified operational review pending; blocked for learner release"
effort: "3–5 active hours plus 45–60 minute fresh check; unmeasured"
---

# A running process that cannot serve its client

The issue report says the bulletin process is healthy, yet the known client cannot reach it. The exercise asks you to reconstruct the actual path and repair the failed boundary. It uses real Docker/Compose tooling and synthetic data. It does not award cloud, security-specialist, or Kubernetes competence.

**Release gate:** Docker is unavailable in the author environment used for this package. The source and configuration have been inspected, but image build, Compose interpretation, network behavior, resource enforcement, and cleanup have not been executed here. A lab owner must complete the rehearsal below, pin the image digest, and review the exact supported host environment before giving this probe to learners. The commands below are rehearsal instructions, not a claim that they have already succeeded.

## Entry and scope

Learners need CP002, CP007, CP014–CP020: safe commands/files, source modules, hypotheses/evidence, processes/ports, prior bounded container use, configuration, logs, scope, and reset. If those are missing, route to the relevant M049 preparation. Docker installation itself is not this diagnostic exercise.

The approved target is this local Compose project and its synthetic `/healthz` service. Use a dedicated lab copy and a project name you own; the examples use `fsse-probe-r1`. If that name already belongs to another session, choose a unique name and substitute it consistently. Check your Docker context before acting. A remote/production context, unknown project ownership, unexpected mount or privilege, public host binding, unrelated credentials, or unbounded resource behavior is a stop condition: pause and have the lab owner correct the environment.

The authored manifest has no host mounts, Docker socket, credentials, privileged containers, or host networking. It requests an ordinary user, read-only root filesystem, dropped capabilities, bounded memory/CPU/processes/logs, and an internal network. The only published host port is loopback `127.0.0.1:4320`. These are configuration intentions to verify in the rehearsal, not proof of isolation against all hostile code. Docker's [Compose service reference](https://docs.docker.com/reference/compose-file/services/) defines these fields; its [network overview](https://docs.docker.com/engine/network/) explains the relevant network boundaries.

Initial image acquisition needs approved network access and local disk. The Dockerfile currently names mutable `node:24-alpine`; the lab owner must choose a reviewed digest, build it, and record image ID/digest, platform, Docker Engine/Desktop, Compose version, disk usage, and measured behavior before release. Do not advertise a pinned/reproducible image based only on this tag.

## LS-OPS-01: reconstruct the path

**First model:** containers are separate locations with their own network context. `localhost` is relative to the process making or accepting the connection. The model is useful for diagnosis; containers still share host infrastructure and are not independent physical machines.

Read `compose.yaml`, `Dockerfile`, `server.mjs`, and `client.mjs`. Identify the app's listening address/port, the host-published port, the client's target, and the namespace from which each health check runs. A service name and a host address do different jobs in this setup. Do not assume a green health indicator tested the same route as the failing client.

**EX-OPS-01, L2.** Draw or write a path map with the host, bulletin container, client container, each relevant address/port, and the probe location. Annotate the permitted scope and stop conditions. Indicators: CTR-03.i01, LNX-03.i01, SEC-09.i01.

## LS-OPS-02: compare useful observations

After the lab owner releases this exact fixture, work from `probes/ops`:

```sh
docker context show
docker compose version
docker compose -p fsse-probe-r1 -f compose.yaml config
docker compose -p fsse-probe-r1 -f compose.yaml up -d --build bulletin
docker compose -p fsse-probe-r1 -f compose.yaml ps
docker compose -p fsse-probe-r1 -f compose.yaml logs --tail 40 bulletin
docker compose -p fsse-probe-r1 -f compose.yaml run --rm --no-deps client
curl --max-time 3 -i http://127.0.0.1:4320/healthz
```

The client command starts only the disposable course client. Its approved target is restricted by the supplied source. Compare that result with an in-container request:

```sh
docker compose -p fsse-probe-r1 -f compose.yaml exec bulletin node --input-type=module -e "const r = await fetch('http://127.0.0.1:3000/healthz'); console.log(r.status, await r.text())"
```

**EX-OPS-02, L3.** Predict each result, then capture actual status/exit/log evidence. Form two hypotheses and identify which observation distinguishes them. Explain whether the optional telemetry warning is involved in the request path. Indicators: CTR-03.i01, OBS-01.i01. A failed container image build or unsupported host feature is environment evidence, not confirmation of the seeded network defect.

**Model correction:** “the process is running” describes process state. “this client can obtain this response through this path” describes a different observable behavior. Health checks cover exactly what they probe, including their network location.

## LS-OPS-03: repair the correct boundary

**EX-OPS-03, L3.** Make a focused configuration repair. Preserve the host loopback publication, ordinary user, resource constraints, and internal network. Recreate the affected service, then verify both the actual client and the health behavior. Rebuilding or restarting alone is not a causal explanation.

```sh
docker compose -p fsse-probe-r1 -f compose.yaml up -d --build bulletin
docker compose -p fsse-probe-r1 -f compose.yaml run --rm --no-deps client
curl --max-time 3 -i http://127.0.0.1:4320/healthz
```

Explain why adding privilege, using host networking, or opening the host port publicly is unnecessary for this requirement. Indicators: CTR-06.i01, LNX-03.i01. Preserve your diff and note which boundary each check exercised.

## LS-OPS-04: reset and hand off

**EX-OPS-04, L3.** Write a runbook another person can follow, including source/config identity, expected path, observed symptom, repair, verification, scope, and cleanup. Then remove only this project:

```sh
docker compose -p fsse-probe-r1 -f compose.yaml down --remove-orphans
docker ps -a --filter label=com.docker.compose.project=fsse-probe-r1
docker network ls --filter label=com.docker.compose.project=fsse-probe-r1
```

Verify that the project has no remaining containers or network, and that port 4320 no longer serves this lab. An unexpected responding process requires investigation of ownership, not blind termination. This manifest declares no volumes. The built image and build cache can remain; list them as retained local artifacts. Remove the specific image only when it is yours and unused by any other project; never use a global prune as the reset instruction.

Use a new pristine copy of the manifest to reproduce the starter after preserving your repair. Cleanup alone does not restore edited source. Another observer should be able to repeat the runbook without hidden steps. Indicators: REL-08.i01, SEC-09.i01, COM-01.i01.

## EX-OPS-05: changed boundary, fresh task (L4)

Use a pristine `compose.yaml` together with `compose.transfer.yaml`, a fresh owned project name, and the corresponding name/files on every command:

```sh
docker compose -p fsse-probe-r2 -f compose.yaml -f compose.transfer.yaml config
docker compose -p fsse-probe-r2 -f compose.yaml -f compose.transfer.yaml up -d --build bulletin
docker compose -p fsse-probe-r2 -f compose.yaml -f compose.transfer.yaml run --rm --no-deps client
```

Stop the previous project first because both use host port 4320. The new symptom must be investigated from the resolved configuration, not the filename. Compare host, in-container, and client observations. Make a focused repair and validate/reset the new project with both files and its correct name. Indicators: CTR-06.i01, COM-01.i01. Record previous access and help; an already exposed variant is practice, not fresh independence evidence.

## Hints and full explanation

H1: identify where each request begins. H2: compare the listening address with the client's network location. H3: compare an in-container loopback request with the service-name request from the other container. H4: the first server listens only on its own loopback interface; the container-to-container path cannot reach that listener. H5: in the main manifest set `BIND_ADDRESS` to `"0.0.0.0"`, retaining host publication `127.0.0.1:4320:3000`, then recreate and verify. Changing the container listener is not the same as publishing on every host interface.

For the transfer, H1 asks which port each client uses; H2 points to the resolved client target; H3 compares that target with the actual listening port; H4 identifies `3001` versus `3000`; H5 changes transfer `TARGET_URL` to `http://bulletin:3000/healthz`. The transfer overlay already changes the listener correctly, so copying only the first repair is insufficient. These are source-based expected diagnoses awaiting runtime rehearsal.

The optional telemetry log is non-causal because the server's health response does not depend on an external exporter. The client/host/health distinctions must still be demonstrated in the actual supported engine/network implementation. Local success cannot establish safety of future cloud or Kubernetes labs; those require separate environments, fixtures, and verification.

## Required author rehearsal record

Before learner release, a qualified lab owner must record: exact supported OS/runtime/Compose/context/image identities; resolved configuration; initial build; main failure from the intended client; healthy internal observation; repaired client/host result; fresh variant failure/repair; effective user/capabilities/mounts/network/host publication/resource limits; bounded logs; and cleanup evidence. Repeat clean failure/repair/reset at least three times, including a restart/re-entry and an accessible text-based observation route. Record any residual image/cache state. Any unresolved scope, cleanup, essential access, or resource defect blocks release. All of these fields remain **pending** for this package.
