const target = process.env.TARGET_URL ?? 'http://bulletin:3000/healthz';
if (!/^http:\/\/(bulletin|127\.0\.0\.1):(3000|3001)\/healthz$/.test(target)) throw new Error('Target is outside the approved probe');
try {
  const response = await fetch(target, {signal: AbortSignal.timeout(3000)});
  const body = await response.text();
  console.log(JSON.stringify({target, status: response.status, body}));
  if (response.status !== 200 || body !== 'bulletin-ready\n') process.exitCode = 1;
} catch (error) {
  console.error(JSON.stringify({target, error: error.message, cause: error.cause?.code ?? null}));
  process.exitCode = 1;
}
