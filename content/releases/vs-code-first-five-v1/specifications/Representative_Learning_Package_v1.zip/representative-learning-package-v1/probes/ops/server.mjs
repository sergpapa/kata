import http from 'node:http';
const bind = process.env.BIND_ADDRESS ?? '127.0.0.1';
const port = Number(process.env.SERVICE_PORT ?? 3000);
if (!['127.0.0.1', '0.0.0.0'].includes(bind) || port !== 3000) throw new Error('Outside approved probe configuration');
const server = http.createServer({maxHeaderSize: 8192}, (request, response) => {
  const ok = request.method === 'GET' && request.url === '/healthz';
  response.writeHead(ok ? 200 : 404, {'Content-Type': 'text/plain', 'Cache-Control': 'no-store'});
  response.end(ok ? 'bulletin-ready\n' : 'not-found\n');
  console.log(JSON.stringify({event: 'request', method: request.method, path: request.url, status: ok ? 200 : 404}));
});
server.headersTimeout = 5000; server.requestTimeout = 5000;
server.listen(port, bind, () => {
  console.log(JSON.stringify({event: 'listening', address: bind, port}));
  console.log(JSON.stringify({event: 'optional_telemetry_disabled', impact: 'No external exporter configured'}));
});
const stop = () => { server.closeAllConnections(); server.close(); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
