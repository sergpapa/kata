import {classify} from './classify.mjs';
import {checkRule} from './rule-cases.mjs';
const outcomes = checkRule(classify, 60);
for (const item of outcomes) console.log(`${item.passed ? 'PASS' : 'FAIL'} ${item.input}: ${item.actual} (expected ${item.expected})`);
process.exitCode = outcomes.every(x => x.passed) ? 0 : 1;
