import {classify} from './classify.mjs';
try {
  if (process.argv.length !== 3 || !/^\d+$/.test(process.argv[2])) throw new Error('Usage: node probes/beginner/run.mjs WHOLE_MINUTES');
  const minutes = Number(process.argv[2]);
  console.log(JSON.stringify({minutes, category: classify(minutes)}));
} catch (error) { console.error(error.message); process.exitCode = 1; }
