---
document_id: UNIT-START-001
version: "1.0.0"
slice_id: SL-START
module_placement: [M001, M002, M004, M005]
lesson_ids: [LS-START-01, LS-START-02, LS-START-03, LS-START-04]
effort: "2–4 active hours; unmeasured pilot estimate"
---

# First program and a harmless environment fault

This short probe tests whether our entry teaching is understandable and recoverable. It is not the whole beginner programming course. Use an approved installation of Node 24.x and an editor. You need only basic familiarity with files; a facilitator can help you open the project folder and terminal. Record setup help separately from what you understand about the program.

The problem uses synthetic room-booking durations. A nonnegative whole number of minutes is **standard when it is at most 60**, otherwise **extended**. No money, accounts, real bookings, or external services are involved. The supplied first program has one boundary mistake.

## LS-START-01: find the intended workspace

A folder is a named place containing files. A path tells the computer how to find one. The terminal has a current folder, which supplies a starting point for relative paths. This is a useful first model; shortcuts, symbolic links, permissions, and multiple processes complicate it later.

Open the extracted package in VS Code. Open its terminal and run `pwd` on the rehearsed Bash path. Locate `probes/beginner/run.mjs` in the editor. Ask the facilitator to explain `node --version`: `node` names the executable, the remaining text is an argument, and the printed output is a result. Do not paste unexplained privileged installation commands when a tool is missing.

**EX-START-01, L1.** Write the current folder and the intended program path. Predict whether `node --version` edits the program, then run it. Label your prediction and observation. Indicators: LNX-01.i01.

## LS-START-02: trace a tiny rule

A value is information the program can use. Here it is a number such as 30. A function takes that input and returns a category. A condition chooses between branches. Calling it a “decision” is a first model: the program follows the written expression, including mistakes; it does not infer the business rule from the comment.

Read `classify.mjs`. `Number.isSafeInteger` and the negative check reject invalid inputs; for this first task you can treat that guard as a supplied boundary. The central condition compares minutes with 60. The runner reads your command argument, converts the digits to a number, calls the function, and prints a small JSON object with input and result.

From the package root, predict then run:

```sh
node probes/beginner/run.mjs 30
node probes/beginner/run.mjs 90
```

**EX-START-02, L1.** Trace input 30 through the condition to its returned category, then input 90. Explain why two correct examples do not establish that every supported value works. Indicator: PRG-09.i01.

## LS-START-03: make the boundary explicit

“At most 60” includes exactly 60. Compare a value just below, exactly on, and just above the boundary. Before running, write what the requirement demands and what the current expression will do. A disagreement is a useful bug report.

```sh
node probes/beginner/run.mjs 59
node probes/beginner/run.mjs 60
node probes/beginner/run.mjs 61
node probes/beginner/check.mjs
```

**EX-START-03, L2.** Change the function so it implements the written rule, keeping invalid-input handling. Run the boundary and ordinary examples again. Explain which character/operator changed and how it affects the equality case. Indicators: PRG-09.i01, PRG-09.i02, ENG-04.i01.

Do not change expected results merely to agree with the original code. The rule comes from the requirement. The check script helps you observe cases; you still need to explain the conditional.

## LS-START-04: recover from the wrong starting folder

Only after successful runs from the package root, intentionally change into this known subfolder:

```sh
cd probes/beginner
node probes/beginner/run.mjs 30
```

This harmless command asks for a nested path relative to the new current folder. It should fail to find the intended module. It is not evidence that Node disappeared or that the source needs reinstalling. Read the path in the actual error.

**EX-START-04, L2.** State two explanations for the failure, then use `pwd` and the editor's folder tree to distinguish them. From this folder, run `node run.mjs 30`. Explain why that path works, then return to the root with `cd ../..` and verify the original command. Change only the path/current-folder relation, not your program and installed tools simultaneously.

Submit only `classify.mjs` and a short note containing the relevant command, current folder, actual error, correction, and explanation. Exclude unrelated projects, environment files, home-folder listings, and credentials. A facilitator can provide a textual error record or help operate a tool; record the support and assess the intended concept separately. Indicators: LNX-01.i01, LNX-05.i01, ENG-04.i01, AIE-02.i01.

## EX-START-05: a changed rule (L2)

After the first explanation, the facilitator supplies a fresh limit, for example 45. The new rule says **less than 45 is standard; 45 or more is extended**. In a separate copy or a preserved diff, implement that requirement and predict 44, 45, and 46. The earlier `check.mjs` belongs to the 60-inclusive rule, so do not pretend it evaluates the changed requirement. Write/run the new cases yourself. Record any help. Indicator: PRG-09.i02.

This changed inequality deliberately prevents success through replacing only the old number. A learner who already read this variant needs a different comparable limit/inclusivity combination for independent verification.

## Help and complete explanation

H1: inspect an example exactly at the boundary. H2: distinguish `<` from `<=`. H3: compare 59/60/61 while holding the code constant. H4: the original condition excludes 60 from standard; include equality. H5: [the complete corrected function](../../instructor/solutions/beginner.mjs). For the path task, a H3 diagnostic is to compare the current folder with the relative path in the error; a H5 explanation is the corrected `node run.mjs 30` from this subfolder.

The initial program returns standard for 30 and extended for 90. It incorrectly returns extended for 60. The corrected 60-inclusive function returns standard for 0, 1, 59, and 60; extended for 61 and 120. The supplied author checks verify this contrast. For the fresh 45-exclusive rule, 44 is standard while 45 and 46 are extended. Merely changing 60 to 45 in the first corrected `<=` expression would be wrong.

For the directory fault, the repeated relative path contains the already-entered folder twice. Correct the path or return to the root; a successful run plus an explanation shows recovery. A statement that “it worked after reinstalling everything” would not isolate the cause.

## Reset and pilot observations

Restore a fresh copy of `classify.mjs` from the original archive if you want another starter; preserve your diff first. No database, background process, or outside file is created by the commands. Returning to the package root restores the starting directory context. Record active setup/learning time, confusing instructions, rescue steps, boundary explanations, accessibility obstacles, and whether context selection was appropriate. These observations evaluate the curriculum as well as the learner.
