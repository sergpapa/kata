export function checkRule(classify, limit) {
  return [0, 1, limit - 1, limit, limit + 1, 120].map(input => {
    const expected = input <= limit ? 'standard' : 'extended';
    let actual;
    try { actual = classify(input); } catch (error) { actual = `Error: ${error.message}`; }
    return {input, expected, actual, passed: actual === expected};
  });
}
