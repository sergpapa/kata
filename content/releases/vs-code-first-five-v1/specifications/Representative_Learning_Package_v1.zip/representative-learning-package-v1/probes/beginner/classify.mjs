// Exercise rule: nonnegative whole minutes; at most 60 is 'standard', above 60 is 'extended'.
export function classify(minutes) {
  if (!Number.isSafeInteger(minutes) || minutes < 0) throw new Error('Use nonnegative whole minutes');
  if (minutes < 60) return 'standard';
  return 'extended';
}
