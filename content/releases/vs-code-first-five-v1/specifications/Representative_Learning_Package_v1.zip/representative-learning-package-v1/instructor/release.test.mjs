// Author verification only. These are known course fixtures, never uploaded student code.
import test from 'node:test';
import assert from 'node:assert/strict';
import {runContract} from '../test/contract-cases.mjs';
import {makeValidator as hash} from './solutions/main-hash.mjs';
import {makeValidator as version} from './solutions/main-version.mjs';
import * as keyed from './solutions/transfer-keyed.mjs';
import * as simple from './solutions/transfer-simple.mjs';
import {classify as beginnerStarter} from '../probes/beginner/classify.mjs';
import {classify as beginnerSolution} from './solutions/beginner.mjs';
import {checkRule} from '../probes/beginner/rule-cases.mjs';

const failures = report => report.filter(x => !x.passed).map(x => x.id);
test('beginner starter fails only the published equality boundary among six cases', () => {
  assert.deepEqual(checkRule(beginnerStarter, 60).filter(x => !x.passed).map(x => x.input), [60]);
});
test('beginner reference satisfies ordinary and boundary cases and retains input validation', () => {
  assert.ok(checkRule(beginnerSolution, 60).every(x => x.passed));
  for (const input of [-1, 0.5, '30', Number.NaN]) assert.throws(() => beginnerSolution(input));
});
test('main starter has exactly the intended changed-representation failures', async () => {
  assert.deepEqual(failures(await runContract('main')), ['HC04', 'HC05', 'HC14']);
});
test('transfer starter passes main behavior and fails selection in both request orders', async () => {
  assert.deepEqual(failures(await runContract('transfer')), ['TX01', 'TX02', 'TX03']);
});
for (const [name, makeValidator] of [['content hash', hash], ['controlled version', version]]) {
  test(`main alternative passes the contract: ${name}`, async () => {
    assert.deepEqual(failures(await runContract('main', {makeValidator})), []);
  });
}
for (const [name, solution] of [['complete memo key', keyed], ['direct representation', simple]]) {
  test(`transfer alternative passes the contract: ${name}`, async () => {
    assert.deepEqual(failures(await runContract('transfer', {
      selectRepresentation: solution.selectRepresentation, reset: solution.resetRepresentationCache
    })), []);
  });
}
test('copying the main hash solution into transfer cannot repair selection', async () => {
  assert.deepEqual(failures(await runContract('transfer', {makeValidator: hash})), ['TX01', 'TX02', 'TX03']);
});
test('the contract rejects disabling caching, unconditional 304, unstable tags, and incomplete tags', async () => {
  let serial = 0;
  const mutants = [
    ['always 200', {makeValidator: hash, compare: () => false}, 'HC03'],
    ['always 304', {makeValidator: hash, compare: () => true}, 'HC01'],
    ['no-store workaround', {makeValidator: hash, cachePolicy: 'no-store'}, 'HC01'],
    ['new tag for every request', {makeValidator: () => `"request-${++serial}"`}, 'HC02'],
    ['title-only tag', {makeValidator: ({record}) => `"${Buffer.from(record.title).toString('hex')}"`}, 'HC05']
  ];
  for (const [name, options, expectedFailure] of mutants) {
    assert.ok(failures(await runContract('main', options)).includes(expectedFailure), name);
  }
});
