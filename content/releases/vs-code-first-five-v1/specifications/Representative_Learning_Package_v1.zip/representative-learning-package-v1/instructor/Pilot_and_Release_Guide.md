---
document_id: PILOT-RLP-001
version: "1.0.0"
status: "Execution plan and blank measurement records; no participant or reviewer results"
---

# Author review, rehearsal, and learning trials

The package makes the first learning workflow concrete. The next decision is whether it works for learners and reviewers under the intended conditions. More authored pages or a polished app would not answer that question by themselves. This guide turns the curriculum architecture's EX02–EX05 plans into a bounded rehearsal sequence; later product experiments remain separate work.

## Readiness ledger

| Gate | Material available now | Evidence still needed before the named release |
| --- | --- | --- |
| HTTP technical owner review | Starter, alternatives, contract cases, local source/terminal checks and QA record | Independent technical/editorial review; actual browser and reset rehearsal on each advertised OS/browser; resolve discrepancies |
| Beginner access review | Four lessons, tiny program, controlled path fault and changed rule | Observed beginner setup, assistive-technology/access review, and supported-path rehearsal |
| Operational fixture release | Dockerfile, main/transfer Compose configurations, lessons, source, scope/reset runbook | Image digest pin, Docker runtime/config/network/resource checks, three reset cycles, qualified operational review |
| Learning-only HTTP pilot | Full lesson/workbook/help/review/transfer package | Approved participant/data arrangements and actual prerequisite screening; no implied recruitment has occurred |
| Advisory reviewer pilot | Forty concrete cases and draft labels | Two independent qualified annotations, adjudication, genuinely held-out model evaluation and authority/input controls |
| Application MVP specification | Concrete content/evidence objects and known workflow states | EX06 interaction trials and EX07 operating-cost measurements; full data model/security/retention decisions |

The [verification report](../release/Verification_Report.md) is the authority for actual author checks. A checked-in manifest or a predicted result cannot be substituted for a completed rehearsal.

## Rehearse the package without recruiting anyone

Have a technical reviewer who did not author the instructions use a fresh extraction. Verify preflight, Git baseline, main startup, unchanged conditional behavior, the changed-state symptom, a focused repair, learner contract checks, evidence preview, and restore/re-entry. Repeat the HTTP reset sequence at least three times while checking that source and notes are preserved. Compare browser/page/network/terminal observations with settings recorded. Do not quietly rescue a failed instruction without logging what was missing.

Inspect the lessons for unexplained prerequisites, accidental answer exposure, correct temporary-model limits, usable links, complete keyed explanations, and alignment between required cases and rubrics. Check the viewer with keyboard navigation, zoom/narrow widths, an appropriate screen reader, and a text-only evidence alternative. A static semantic markup check is useful but not a completed accessibility review.

For Docker, follow the operational probe's separate rehearsal. Its pending state blocks that probe, not continued authoring of unrelated lessons or review of this HTTP package. Do not advertise Windows, macOS, a particular browser, or a cloud/Kubernetes path until its own essential procedure is rehearsed.

## EX02: beginner learning trial

Proposed initial sample: six to eight consenting beginners across the intended supported paths, plus appropriate accessibility expertise/users. The count is a planning choice, not a statistical guarantee. Use SL-START, record setup separately from programming, and ask the learner to explain the 60-inclusive boundary before giving a fresh limit/inclusivity rule. Offer help as soon as needed.

Record actual active time, confusing words/commands, rescue steps, wrong-folder diagnosis, boundary reasoning, submitted context, and accessibility obstacles. Do not infer ability from speed or a setup failure. An essential access blocker or destructive instruction requires correction before expansion. Repeated misunderstanding should trigger lesson/prerequisite changes, not only more attempts from learners.

## EX03: HTTP learning and delayed transfer

Proposed initial sample: six to eight learners who demonstrate the stated prerequisites. Keep trials learning-only. Before instruction, ask for a brief prediction and investigation plan for a comparable response problem without showing this solution. Preserve what they actually knew and any baseline help.

Deliver LS-HTTP-01 through 07 with full access to graduated help. Record predictions before observations, useful versus non-discriminating experiments, actual help per indicator, test design, review responses, environment trouble, and active time. Ask a second reviewer to follow the submitted packet; note missing context and unsupported findings.

Administer a fresh comparable transfer about 7–14 days later where scheduling permits. Record actual delay, interval practice, prior access, and assistance. Because this owner archive exposes its transfer materials, a participant who read them needs a different comparable variant. Missed scheduling leads to re-entry, not an ability penalty. An assessor can alter the representation dimension or memoization boundary while retaining similar demands, then technically rehearse the new case before use.

The provisional signal from the architecture is five of six or six of eight completing the bounded transfer indicators at H0 after instruction. Use it to investigate the teaching pattern, not as a validated pass threshold or causal effect estimate. Track which indicators transfer and why others do not. A small uncontrolled pilot cannot establish program completion rates, hiring equivalence, or credential validity.

## EX04: reviewer calibration and reliability

Use the concrete 40-case inventory and reviewer guide. Two qualified reviewers independently annotate before adjudication. Freeze the rubric/prompt/evaluation release, keep 20 development cases separate from 20 genuinely held-out cases, and replace exposed reserved candidates. Preserve disagreement rationales and valid alternative implementations.

Run candidate advisory reviewers only after their context/tool boundaries are defined. Measure errors and correct abstentions, fabricated execution, submitted-instruction influence, hint leakage, latency, retries, model usage and human review time. The author did not conduct this evaluation or invent its outcomes. No clean result on this small sample would authorize unattended graduation decisions.

## EX05: operational observation

After the lab owner's runtime release gate, use four or more participants with the operational prerequisites. Observe the main diagnosis, a runbook handoff, cleanup, and the fresh variant. Compare what learner-reported logs alone establish with what the observer actually sees. Record effective limits and residual state. No cloud accounts, paid infrastructure, hostile targets, or Kubernetes clusters are required or validated by this probe.

## Record measurements, not imagined results

These tables are blank instruments. Use pseudonymous participant/case IDs and the approved data handling plan. Obtain explicit arrangements before collecting real source, recordings, or telemetry. Do not use real participant names or private project code in the synthetic calibration case archive.

| Episode ID | Slice/task/version | Environment | Active setup minutes | Active task minutes | Calendar delay | Help by indicator | Observations and source refs | Access/setup issue | Outcome/next action |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pending | | | | | | | | | |

| Case ID | Reviewer/version | Independent label A | Independent label B | Adjudicated result/reason | Model result | Error/abstention category | Usage/latency | Human review minutes | Disposition |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pending | | | | | | | | | |

| Release/host | Startup | Main failure | Repair | Transfer | Reset cycle 1 | Reset cycle 2 | Reset cycle 3 | Scope/resource/access findings | Owner decision |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| pending | | | | | | | | | |

Keep authoring time, technical/editorial review, support, resubmissions, appeals, and maintenance as separate cost categories. Do not price the product from token cost alone. Numerical estimates in this package remain unmeasured until those records are filled.

## Application specification after the rehearsal findings

The next product artifact should be an **Application Requirements and Experience Specification v1**, in Markdown. It should define these workflows using the concrete objects in this package:

- Learner setup/placement, lesson navigation and accessible explanations, prediction capture, local exercise instructions, hints/full walkthrough, source/evidence selection, preview, submission, waiting/failure/retry, review, response, revision, transfer, progress and appeals.
- Author versioning across requirements, lessons, fixtures, solutions, tests, rubrics and prerequisite changes; review/publish/withdraw states and compatibility checks.
- Reviewer work queues, sufficient-context checks, advisory findings, qualified observation, escalation, calibration and appeal history.
- Separate curriculum completion, criterion evidence, help/provenance, and competency decisions; immutable attempt/source identities with lifecycle rules.
- Local execution boundaries; safe file/ZIP ingestion, archive limits and traversal/symlink handling; submission-as-data controls; authorization and tenant separation; provider handling; retention/export/deletion; rate/cost limits and service recovery.

Start with plain file submission and a reviewable manifest. Do not require an extension or MCP before measuring a specific workflow problem they solve. The browser viewer in this package is a teaching instrument, not an app UX prototype or upload service. The full app specification must include acceptance criteria and unresolved decisions, then inform architecture and a private MVP. Writing a draft can proceed while pilots are scheduled, but mark assumptions and do not treat unrun trials as validation.

## Maintenance and release ownership

Required roles are curriculum/content owner, technical reviewer, learning/accessibility reviewer, assessment owner and qualified adjudicators, and operational lab owner. These are needed responsibilities, not people already assigned or contacted. Keep source standard/curriculum identities immutable in the release. A change to a requirement, representation, helper, runtime, solution, or rubric triggers impact review across its dependent exercises and cases. Re-run only the checks relevant to the change plus required release gates.

Do not rebuild the calibration set from a learner-modified starter and call it the original evaluation release. Store withdrawn/revised artifact identities with the applicable lifecycle policy. Keep known limitations visible until an actual recorded observation closes them.
