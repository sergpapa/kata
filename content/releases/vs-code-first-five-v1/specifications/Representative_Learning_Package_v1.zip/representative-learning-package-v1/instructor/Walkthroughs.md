---
document_id: SOL-HTTP-001
version: "1.0.0"
audience: "Teachers and any learner requesting complete explanations"
exposure: "Reading a solution-specific diagnosis before completing the affected task is H4/H5 help"
---

# Worked explanations and acceptable alternatives

These answers explain the supplied fixture. They are not a required writing style or an exact patch to match. Compare a learner's own evidence with the published contract. Different tag values, tests, explanations, or patches can be valid. The outcomes below are the expected behavior of this release; the [verification report](../release/Verification_Report.md) records what the author actually executed.

## EX-HTTP-01 to 03: exchange and source trace

**01.** curl's API URL requests the notice representation, not the HTML viewer. Its normal method is GET. The response begins with a status, then metadata, then JSON. `ETag` describes the selected representation for validation; a response Date is not the fixture's edit history. Read the actual output rather than copying an assumed Date or length. A response header cannot be relabeled a request header merely because both appear together in DevTools.

**02.** `tools/start.mjs` chooses a scenario/port and listens. `lab/lib/scenario.mjs` wires implementations into the handler. `lab/lib/state.mjs` reads/validates current runtime data. `lab/main/representation.mjs` selects and serializes the three fields. `lab/main/validator.mjs` supplies the tag. `lab/lib/app.mjs` invokes the conditional helper and selects the response. An unknown route returns 404 before a bulletin is selected. It never reaches that bulletin's validator. A readable responsibility table can combine the two startup entries; grading does not depend on a fixed row count if all responsibilities are accounted for.

**03.** Browser and curl can request the same resource. They can differ in request headers, stored client state, and how the response reaches the UI. The browser may revalidate a stored response, whereas the shown plain curl invocation does not automatically retain an HTTP body cache between calls. Preserve actual conditional headers and cache settings. “They both display the closing time” is too weak to identify the cache path.

## EX-HTTP-04 to 06: identity, representation, and no-op changes

**04.** Changing `notice.body` leaves the resource URL and ID unchanged, increments the controlled runtime revision, and changes the returned body. It does not itself create a Git commit or change the source. In the faulty starter the tag remains `"notice"`; that observed behavior is not the intended change relationship. A correct response after a changed body must not validate a stale tag as if the old content still applied.

**05.** For the seed notice, the serialized string is:

```json
{"id":"notice","title":"Community room opening hours","body":"The community room closes at 18:00."}
```

The returned string also contains a final newline. `revision` is absent because the representation function explicitly constructs an object with three fields. A future serialization/template change can alter bytes without a record edit, which requires re-examining a record-only version design. The byte-level distinction matters even when the browser renders two values similarly.

**06.** An identical-value edit leaves revision and representation unchanged under `setField`'s contract. Changing a character advances revision and changes the content. The meeting record remains unchanged. A no-op command is not itself evidence that the validator's changed-content path works; test a real change separately.

## EX-HTTP-07 to 09: wire response and client content

**07.** Starting clean, `get` produces a 200 with a body and tag, then saves that body/tag in the terminal client's file. `revalidate` sends the saved tag; unchanged data produces a 304 and zero wire-body bytes. The model client displays its previously saved content. That is a client action after a no-body response.

**08.** The original main defect produces this sequence:

| Event | Origin data | Request condition | Wire result | Terminal model content |
| --- | --- | --- | --- | --- |
| First GET | Closing time 18:00 | None | 200, original body, tag `"notice"` | Original body saved/displayed |
| Unchanged validation | 18:00 | `"notice"` | 304, no body | Stored 18:00 body |
| Edit then validation | 20:30 | Still `"notice"` | Incorrect 304, no body | Incorrectly retains 18:00 body |
| Unconditional diagnostic | 20:30 | None | 200, current body | Current content visible |

The data reader and serializer can produce the new content, but the conditional path wrongly confirms the obsolete copy. This narrows the investigation to the relationship used by that decision. It does not prove that every UI symptom has the same cause.

**09.** A bypass can retrieve the current origin representation and help separate the paths. It does not repair what happens when another client presents an old tag. Normal browser fetching can expose a reconstructed 200 to page code while the wire exchange uses 304. Review the actual browser observations and settings; different browser behavior should be investigated rather than forced into a preferred transcript.

## EX-HTTP-10: completed case matrix

| Case | Correct wire status | Wire content | Reason in this fixture |
| --- | --- | --- | --- |
| A | 200 | Current full JSON | No condition suppresses content |
| B | 304 | None | Current selected representation matches the saved tag |
| C | 200 | New JSON/title | Old tag cannot validate changed selected content |
| D | 200 | New JSON/body | Body-only change also matters |
| E | 200 | Current JSON | None of the supplied values matches |
| F | 304 | None | One member matches under the helper's comparison |
| G | 304 | None | The supplied weak comparison matches the opaque value |
| H | 304 | None | An existing selected representation satisfies the wildcard condition |
| I | 404 | Error text for GET | Missing-resource handling comes before that conditional decision |
| J | 200 | None | HEAD sends the selected GET metadata without content |
| K | 304 | None | Matching conditional HEAD also omits content |
| L | 405 | Error text | This service does not support POST; it also sends Allow |
| M | 400 | Error text | Published malformed-input rejection policy |
| N | 500 | Error text | The service cannot establish a valid current representation |

The main starter fails changed-content cases C and D. HC14 verifies the same failure with non-ASCII content. Most unchanged/negative paths already work; a repair should retain them.

## EX-HTTP-11 and 12: grammar and errors

**11.** `W/"b"` parses to a tag list containing opaque value `b` and matches `"b"`. `"a,b", "b"` yields two values (`a,b` and `b`) and matches. `"B"` does not match `"b"`. `*` is a separate wildcard result; it is used only after locating a representation. `unquoted` is invalid, so the handler rejects it rather than treating it as a matching tag. A comma inside quotes belongs to an opaque value and is not a list separator.

**12.** A missing resource with wildcard remains 404. POST stays 405 with Allow because the method check precedes bulletin validation. An unconditional HEAD returns the GET metadata and no body; its Content-Length describes the selected GET content in this implementation. HC15 injects a reader exception in an isolated test harness. The handler returns a visible 500 with no-store, not a successful 304 that would hide the inability to read state. These tests do not require damaging the live fixture file.

## EX-HTTP-13 to 15: investigation reasoning

**13.** Plausible hypotheses include client-side reuse without a useful validation request and an origin decision that incorrectly confirms an obsolete copy. Compare a request carrying the saved tag with an unconditional request under the same current source/data. If the origin itself returns 304 for the stale tag while it can return changed data unconditionally, the observation weakens an exclusively client-side explanation. Alternatives that predict distinct observations are acceptable; the rubric does not demand this exact wording.

**14.** In the faulty trace, the record's body changes and the serializer emits different JSON, but `makeValidator({record})` returns the resource ID in quotes both times. The helper correctly compares the equal opaque tags. The response choice follows an incorrect representation claim supplied by the tag generator. The comparison helper is not where this defect originates.

**15.** The startup warning about optional telemetry is emitted from startup code. No data reader, selected field, validator input, or response condition depends on it. Reproducing the same failure through the explicit request sequence supplies a causal path elsewhere. New evidence of telemetry altering those inputs would justify reconsideration; deleting an unrelated log line would not show a repair.

## EX-HTTP-16 to 18: two valid main repairs

### Alternative A: hash the serialized representation

[`main-hash.mjs`](solutions/main-hash.mjs) uses Node's standard SHA-256 operation over the exact UTF-8 body and emits a quoted hexadecimal tag. Unchanged serialized content produces the same tag; the fixture's changed bodies produce different tags. It includes every selected field, punctuation, and the newline because it receives the actual serialized body.

The function hashes the already produced content; it does not avoid producing the body. For a large expensive representation, performance and transformation boundaries would need measurement. A cryptographic hash has theoretical collision possibilities; this design is an appropriate ordinary implementation choice for the fixture, not a mathematical proof that two arbitrary inputs can never collide. Do not hash only a visible title or a record ID and assume the result describes all content.

### Alternative B: use the controlled record revision

[`main-version.mjs`](solutions/main-version.mjs) combines the resource ID with its monotonic revision in a quoted tag. In this fixture every actual change to a rendered title/body passes through `setField`, and no other rendering input changes during the exercise. Those assumptions make the version valid here. Combining ID and revision avoids confusing two different records that happen to share revision 1.

This approach depends on all relevant writers and renderers respecting the version boundary. Directly editing runtime JSON without advancing revision, changing a template without including its version, or introducing different views can invalidate the assumption. The contract intentionally limits the supported writes. A reviewer needs the surrounding mutation context before rejecting or accepting a version design.

### Apply and compare without losing your investigation

The solution files are complete replacement implementations for the small function module. A learner requesting H5 may inspect one and manually replace the contents of `lab/main/validator.mjs`, then restart and test. Do not change the test expectations to fit the patch. Keep the original attempt, help event, and result. An independent transfer claim needs a different task after this exposure.

**17.** A meaningful regression looks like this. It is one possible answer, not the only allowed test:

```js
test('a body-only edit cannot validate an obsolete copy', async () => {
  await withLab('main', {}, async h => {
    const first = await h.request();
    h.set('body', 'A different closing time.');
    const next = await h.request({headers: {'If-None-Match': first.headers.etag}});
    assert.equal(next.status, 200);
    assert.equal(JSON.parse(next.body).body, 'A different closing time.');
    assert.notEqual(next.headers.etag, first.headers.etag);
  });
});
```

A second test can verify the meeting stays conditionally unchanged after editing notice, or that a new current tag yields 304 after the repair. A non-ASCII change tests a useful encoding boundary. The first regression fails on the starter because status is 304 and no changed body arrives. Tests that assert only “my validator equals the hash I computed the same way” do not protect the response behavior.

**18.** An always-200 workaround fails unchanged validation; an always-new tag fails stable unchanged reuse; a title-only hash fails body-only edits; no-store violates the required successful cache policy. Their status as near misses comes from explicit requirements, not a universal ban on those techniques in other applications.

## EX-HTTP-19 to 21: packet and review responses

**19.** A useful packet identifies baseline/final source, affected files and dependencies, exact environment, observed before/after state, request details, tests and their results, reasoning, missing context, and help events. The local collector intentionally does not infer a Git history or manufacture raw test output. Select those separately. A hash identifies the submitted bytes; the receiver still needs to interpret their origin and sufficiency. The blank note is not a completed submission just because collection succeeds.

**20.** If the learner has no body-only test, accept the finding, add one, and show the result. If a relevant test already exists, cite its setup and assertions, not just the test's name. If the uploaded packet omitted that test, the finding may be a context problem rather than an implementation defect. Clarify the missing file and revise the review accordingly.

**21.** A sound response says that the contract permits a revision design when each relevant mutation updates the revision and representation identity is complete. Point to `setField`, the representation function, and relevant cases. A SHA-256-only grading rule is unjustified here. The answer should also acknowledge the version approach's limits; a rebuttal is not a claim that all revision-based tags are safe.

## EX-HTTP-22 to 24: full transfer walkthrough

**22.** Full means `id`, `title`, `body`; summary means `id`, `title`. The selected shape should not depend on which other view was requested first. The request's `X-Bulletin-View` input matters. The supplied `Vary` header communicates that selection dimension to HTTP caches. Record whether the learner learned the diagnosis from this section before investigating.

**23.** The transfer validator already hashes its input body correctly. The defect is earlier: `lab/transfer/representation.mjs` remembers serialized output under a key containing ID and revision but not view. Summary-first populates the entry with a summary body; full then receives that body. Reversing order produces the opposite shape error. A correct hash faithfully identifies whichever body it is given, including an incorrectly selected body. Replacing it with the main hash implementation leaves this defect intact.

Two valid repairs are provided:

- [`transfer-keyed.mjs`](solutions/transfer-keyed.mjs) includes the requested view in the memo key alongside record ID and revision, keeping a bounded memo table. This preserves reuse of a correctly selected result under the fixture's controlled revisions.
- [`transfer-simple.mjs`](solutions/transfer-simple.mjs) constructs the requested small representation each time and removes the memo table. The contract does not require this internal cache. Removing an unnecessary optimization is a defensible repair.

The response cache policy, conditional helper, and `Vary` remain intact in both designs. TX01/TX02 exercise both request orders, TX03 checks that a tag from a different shape does not suppress the correct body, and the remaining tests protect changes, metadata, and ordinary boundaries. A fix that resets the entire memo table before each request might be functionally adequate here but should be reviewed for clarity; do not reject correct behavior merely because it differs from the reference source. Prefer explaining the simpler direct computation if the memo adds no value.

**24.** The main task concerned whether the supplied validator followed changing content. The transfer task concerns whether the service selected the appropriate content before validation. The stronger model separates these responsibilities. A reviewer claiming the memo table must stay needs a requirement or measurement; none exists in this fixture. A learner who needed H4/H5 can accurately explain this distinction while still needing a fresh independently observed task for an independence claim.

## Optional Heroic discussion

Hold a record constant and define two rendering functions: one returns `{id, title, body}`, another additionally returns `{id, title, body, kind: 'public'}`. These produce different bytes at the same record revision. A tag based only on ID/revision would be equal despite the different selected representation. This is a counterexample to a version scheme that omits a rendering input.

Two directions are defensible: derive a tag from each renderer's exact emitted body, or maintain a complete representation version that includes a renderer/schema version and every other relevant selection dimension. Explain how deployment changes that version and how the server handles an old client's conditional request. A vague “bump it when necessary” is weaker than identifying who owns the bump and a regression that catches a missed one.

Whitespace, encoding, content coding, weak/strong semantics, and cross-server consistency raise further questions. The unit's helper and fixtures do not implement those full mechanisms. A careful learner can research the protocol references, identify which byte stream a proposed tag describes, and present a bounded two-renderer test without claiming production proxy or compression correctness. Good partial evidence includes a precise counterexample, a researched question, and a proposed observation that would discriminate remaining designs. After the full discussion, use a different representation dimension or deployment constraint for fresh independent work.
