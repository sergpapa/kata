export function classify(minutes) {
  if (!Number.isSafeInteger(minutes) || minutes < 0) throw new Error('Use nonnegative whole minutes');
  return minutes <= 60 ? 'standard' : 'extended';
}
