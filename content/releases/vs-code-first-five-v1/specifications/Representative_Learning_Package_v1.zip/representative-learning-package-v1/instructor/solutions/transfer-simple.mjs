export function selectRepresentation(record, view) {
  const value = view === 'summary' ? {id: record.id, title: record.title} : {id: record.id, title: record.title, body: record.body};
  return JSON.stringify(value) + '\n';
}
