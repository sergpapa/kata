export function makeValidator({record}) {
  // Valid for this fixture: every rendered title/body change increments revision.
  return `"${record.id}-r${record.revision}"`;
}
