import {createHash} from 'node:crypto';

export function makeValidator({body}) {
  return `"${createHash('sha256').update(body, 'utf8').digest('hex')}"`;
}
