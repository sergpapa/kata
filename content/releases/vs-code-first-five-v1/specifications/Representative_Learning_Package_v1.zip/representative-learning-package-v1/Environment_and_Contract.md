---
document_id: ENV-HTTP-001
version: "1.0.0"
slice_ids: [SL-HTTP, SL-START]
---

# Environment and HTTP contract

## Supported rehearsal environment

The author rehearsal uses Linux x64, Node 24.19.0, Git, curl, and the browser versions listed in the [verification report](release/Verification_Report.md). The code targets Node 24.x and uses only its built-in modules. There is no package download or lockfile because there are no npm dependencies. An engine declaration is descriptive; `node tools/preflight.mjs` checks the actual major version. Node's [24.x HTTP API](https://nodejs.org/docs/latest-v24.x/api/http.html) and [test runner](https://nodejs.org/docs/latest-v24.x/api/test.html) are the runtime references; those documentation pages can advance to a later 24.x patch.

Windows and macOS are candidate paths, not rehearsed support claims. Windows learners should use an approved Bash/WSL path for these shell examples, or have a facilitator adapt quoting and confirm parity. In PowerShell, `curl.exe` avoids ambiguity with a shell alias. Do not infer that an untested platform failure is a learner competency failure. Hardware minimums and assistive-technology compatibility need measurement before advertising them.

The HTTP lab binds only to `127.0.0.1`. It reads synthetic bulletin data and offers no HTTP edit endpoint. Changes use the supplied local command. Use your own extracted project folder; do not add production files or credentials. Keep the server's terminal visible. Stop with Ctrl+C; a port conflict is a reason to select another lab port, not kill an unidentified process.

## Setup, baseline, and recovery

1. Open this extracted folder in VS Code. Run `node tools/preflight.mjs` and record its result. If a required tool is missing, use the program's approved installation/setup path; no privileged installation command is part of this lesson.
2. In a new, dedicated folder, initialize a repository with `git init`. Inspect `git status --short` before staging. Stage this teaching package and commit a baseline with `git add .` followed by `git commit -m "Record HTTP lab baseline"`. If Git needs an identity, configure an appropriate identity for this repository through your normal setup process; do not change shared/global settings just to pass an exercise. Record `git rev-parse HEAD`.
3. Run `node tools/fixture.mjs reset main`, then `node tools/start.mjs main`. The server stays in the foreground. Use a second terminal for client commands.
4. Check `http://127.0.0.1:4310/healthz` and open the viewer at `/`. Use `127.0.0.1` consistently; a different hostname or port can create a different client cache context.
5. When editing imported source, stop and restart the server. Fixture data changes are read on each request and do not require restart. Tests create their own isolated in-memory fixtures; they do not alter the running lab.

If port 4310 is occupied, choose an unused port, for example `node tools/start.mjs main 4410`, use `http://127.0.0.1:4410/` in the browser and curl, and pass it to the terminal client: `node tools/request.mjs main get full 4410`. Use that port consistently. A real port conflict can still occur; retry with another available local port.

For a clean data experiment, stop the server, run the relevant reset command, restart it, and start a new browser context or clear site data for the lab origin. The reset changes only `.work/main-state.json` or `.work/transfer-state.json` and that scenario's two named terminal-cache files. It preserves source, tests, notes, and Git history. Restart clears the transfer server's in-memory representation cache. Browser state is separate from `.work` state and must be reset separately. Avoid resetting during concurrent fixture writes.

To restore source, first save your diff and notes. Open the original archive in a **new folder** for a clean starter. Do not use a blanket destructive Git reset as the default recovery path. For cleanup, stop your lab processes and remove only your own extracted lab copy when no longer needed. No cloud resources or host service configuration are created by this HTTP package.

## Service contract

| Property | Published requirement |
| --- | --- |
| Resources | `notice` and `meeting`, addressed as `/api/bulletins/{id}` |
| Main representation | UTF-8 JSON containing `id`, `title`, and `body`, followed by a newline |
| Transfer representation | `X-Bulletin-View: full` selects those three fields; `summary` selects only `id` and `title`; absent header means full |
| State changes | Only title/body via the fixture command; each actual change increments that record's revision; setting the same value does not |
| Methods | GET and HEAD; other methods return 405 and `Allow: GET, HEAD` |
| Unconditional GET | 200 with current selected content and one valid quoted `ETag`; unchanged reads keep the same tag |
| Matching conditional GET/HEAD | 304, no representation body, current `ETag`, `Cache-Control`, and transfer `Vary` metadata |
| Nonmatching conditional GET | 200 with current selected content and tag |
| HEAD | Same selected-representation metadata as GET, including its byte length for 200, without a body |
| Cache policy | Successful bulletin responses use `Cache-Control: no-cache`; error responses and viewer resources use `no-store` |
| Transfer selection metadata | `Vary: X-Bulletin-View` on successful bulletin responses, including 304 |
| Failure behavior | Unknown resource/route: 404; query parameters or invalid view: 400; malformed supported conditional input: 400; unreadable/invalid fixture: 500 |
| Unsupported features | Authentication, writes over HTTP, range requests, compression, freshness lifetimes, `Last-Modified`, other conditional headers, content negotiation beyond the transfer view, intermediaries, and full HTTP conformance |

The lab uses `If-None-Match` weak comparison, including lists and the existence wildcard. A 304 has no representation content. Preconditions here are evaluated after resolving ordinary request errors; a missing bulletin stays 404. These choices use the relevant [HTTP conditional semantics](https://www.rfc-editor.org/rfc/rfc9110.html#section-13.1.2) and [304 definition](https://www.rfc-editor.org/rfc/rfc9110.html#section-15.4.5). The lab's malformed-input rejection and stable-tag requirements are explicit exercise constraints, not claims that every server must make identical implementation choices.

Unqualified `no-cache` permits storage but requires validation before reuse. `no-store` directs caches not to store the response; changing to it would remove a required behavior in this task. `Vary` identifies request fields used in selecting the stored response. See [HTTP caching](https://www.rfc-editor.org/rfc/rfc9111.html#section-4.1) and [response cache directives](https://www.rfc-editor.org/rfc/rfc9111.html#section-5.2.2).

## Course-supplied helper boundary

`lab/lib/conditional.mjs` parses absent values, `*`, quoted tags, `W/` weak tags, comma-separated lists, and bounded empty list members. Commas inside quotes remain inside a tag. Comparisons are case-sensitive for the opaque value. It rejects malformed syntax, inputs over 8192 characters, and lists over 128 nonempty members; the HTTP server also limits total request headers to 8192 bytes, so an oversized HTTP request may be rejected before this helper runs. It does not implement the full precondition algorithm for arbitrary methods or other conditional headers.

You can inspect the helper; implementing a header parser is not a prerequisite or required repair. The important interfaces are `parseIfNoneMatch(value)` and `isNotModified(parsed, currentTag)`. The handler supplies only the current selected representation's tag after locating the resource. Treat tag strings as opaque values; do not assume their internal format is a general API.

## Useful commands

Run commands from the package root in the client's terminal:

```sh
node tools/fixture.mjs show main
node tools/request.mjs main get
node tools/request.mjs main revalidate
node tools/fixture.mjs set main notice body "The community room closes at 20:30."
node tools/check.mjs main
node --test test/learner-regression.test.mjs
node tools/submission.mjs main
```

`get` records a 200 representation and its tag in a local terminal cache. `revalidate` sends that tag and prints the actual wire status/body alongside the content the model client selects. This tiny client handles only this fixture's normal full-response/304 cycle; it is not a general HTTP cache.

The browser viewer shows the status exposed to page JavaScript. A browser can combine a 304 network response with stored content, so the page can receive a reconstructed successful response. The [Fetch network/cache algorithm](https://fetch.spec.whatwg.org/#http-network-or-cache-fetch) describes this layer. Capture actual Network details and terminal/origin observations before concluding that two status displays contradict each other. Browser UI labels and reload behavior vary; record the version and settings.

## Published behavior checks

`node tools/check.mjs main` runs HC01–HC17 against the current local source. `node tools/check.mjs transfer` adds TX01–TX05. Case names and assertions are readable in `test/contract-cases.mjs`; they are public requirements, not hidden grading tricks. Add your own regression in `test/learner-regression.test.mjs`; its TODOs remain uncompleted work even when other tests pass.

`node --test test/support.test.mjs instructor/release.test.mjs` is the **author** check: it expects the original starters to contain the specified faults and verifies the supplied alternative solutions. A successful learner repair can make that starter assertion fail; do not undo your repair to satisfy an author-only assertion. Keep learner contract results and author release results distinct.
