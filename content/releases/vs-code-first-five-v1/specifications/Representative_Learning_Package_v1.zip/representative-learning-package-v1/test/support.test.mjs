import test from 'node:test';
import assert from 'node:assert/strict';
import {parseIfNoneMatch, isNotModified} from '../lab/lib/conditional.mjs';
import {seedState, setField, validateState} from '../lab/lib/state.mjs';

test('conditional parser preserves quoted commas, weak tags, empty opaque values and list members', () => {
  assert.deepEqual(parseIfNoneMatch(' , W/"a,b",, "", "Z" ,'), {kind: 'tags', tags: ['a,b', '', 'Z']});
  assert.equal(isNotModified(parseIfNoneMatch('W/"a,b"'), '"a,b"'), true);
  assert.equal(isNotModified(parseIfNoneMatch('"Z"'), '"z"'), false);
  assert.equal(isNotModified(parseIfNoneMatch('"Z"'), 'W/"Z"'), true);
  assert.equal(isNotModified(parseIfNoneMatch(undefined), '"z"'), false);
  assert.equal(isNotModified(parseIfNoneMatch('*'), '"z"'), true);
});
test('malformed or excessive conditional input is rejected within bounds', () => {
  for (const value of ['w/"tag"', 'W/ "tag"', '"space here"', '"x"trailing', '* , "x"',
    '"line\nbreak"', '\"bad\tchar\"', '"emoji😀"', '"x'.repeat(5000), Array(129).fill('"x"').join(',')]) {
    assert.equal(parseIfNoneMatch(value).kind, 'invalid', value.slice(0, 40));
  }
  assert.deepEqual(parseIfNoneMatch(' , , '), {kind: 'tags', tags: []});
  assert.throws(() => isNotModified(parseIfNoneMatch('"x"'), 'not-an-etag'));
});
test('a controlled fixture edit increments revision exactly when a rendered field changes', () => {
  const state = seedState(); const original = structuredClone(state);
  setField(state, 'notice', 'title', state.bulletins.notice.title);
  assert.deepEqual(state, original);
  setField(state, 'notice', 'body', 'Different'); assert.equal(state.bulletins.notice.revision, 2);
  assert.deepEqual(state.bulletins.meeting, original.bulletins.meeting);
  assert.throws(() => setField(state, 'notice', 'id', 'other'));
  assert.throws(() => setField(state, 'missing', 'title', 'other'));
  assert.throws(() => setField(state, 'notice', 'title', 'x'.repeat(2001)));
});
test('fixture validation rejects invalid state rather than silently serving it', () => {
  for (const value of [null, {}, {bulletins: []}, {bulletins: {notice: {id: 'wrong'}}}]) {
    assert.throws(() => validateState(value));
  }
  const state = seedState(); state.bulletins.notice.revision = Number.NaN;
  assert.throws(() => validateState(state));
});
