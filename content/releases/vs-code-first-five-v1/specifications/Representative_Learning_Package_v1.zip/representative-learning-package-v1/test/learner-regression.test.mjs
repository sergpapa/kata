import test from 'node:test';
import assert from 'node:assert/strict';
import {withLab} from './harness.mjs';

test('example: a matching unchanged representation has no conditional response body', async () => {
  await withLab('main', {}, async h => {
    const first = await h.request();
    const repeated = await h.request({headers: {'If-None-Match': first.headers.etag}});
    assert.equal(repeated.status, 304);
    assert.equal(repeated.body, '');
  });
});

test.todo('EX-HTTP-17: add your changed-content regression and assert the returned content');
test.todo('EX-HTTP-17: add a second discriminating boundary or resource case');
