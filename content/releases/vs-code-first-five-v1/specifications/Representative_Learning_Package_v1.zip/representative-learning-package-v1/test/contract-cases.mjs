import assert from 'node:assert/strict';
import {parseIfNoneMatch} from '../lab/lib/conditional.mjs';
import {withLab} from './harness.mjs';

const entity = response => JSON.parse(response.body);
const tagOf = response => {
  const value = response.headers.etag;
  assert.equal(typeof value, 'string', 'A successful representation needs an entity tag');
  const parsed = parseIfNoneMatch(value);
  assert.equal(parsed.kind, 'tags');
  assert.equal(parsed.tags.length, 1);
  assert.match(value, /^(W\/)?"[^"\x00-\x20\x7f]*"$/, 'Emit one quoted entity tag');
  return value;
};
const full = record => ({id: record.id, title: record.title, body: record.body});
const summary = record => ({id: record.id, title: record.title});
const conditional = tag => ({'If-None-Match': tag});
const view = (value, tag) => ({'X-Bulletin-View': value, ...(tag ? conditional(tag) : {})});

export const commonCases = [
  {id: 'HC01', name: 'GET returns the current public representation', run: async h => {
    const r = await h.request(); assert.equal(r.status, 200); assert.deepEqual(entity(r), full(h.record()));
    assert.match(r.headers['content-type'], /^application\/json/); tagOf(r);
    assert.equal(r.headers['cache-control'], 'no-cache');
  }},
  {id: 'HC02', name: 'Unconditional reads remain 200 with stable unchanged validators', run: async h => {
    const a = await h.request(); const b = await h.request(); assert.equal(b.status, 200);
    assert.equal(a.body, b.body); assert.equal(tagOf(a), tagOf(b));
  }},
  {id: 'HC03', name: 'A matching conditional read returns metadata and no wire body', run: async h => {
    const a = await h.request(); const b = await h.request({headers: conditional(tagOf(a))});
    assert.equal(b.status, 304); assert.equal(b.bytes, 0); assert.equal(tagOf(b), tagOf(a));
    assert.equal(b.headers['cache-control'], 'no-cache');
  }},
  {id: 'HC04', name: 'A title change invalidates the previous validator', run: async h => {
    const a = await h.request(); h.set('title', 'Library room: revised notice');
    const b = await h.request({headers: conditional(tagOf(a))});
    assert.equal(b.status, 200, 'Changed content must be sent, not falsely validated');
    assert.equal(entity(b).title, h.record().title); assert.notEqual(tagOf(b), tagOf(a));
  }},
  {id: 'HC05', name: 'A body change invalidates the previous validator', run: async h => {
    const a = await h.request(); h.set('body', 'The community room closes at 20:30.');
    const b = await h.request({headers: conditional(tagOf(a))});
    assert.equal(b.status, 200, 'A body-only change also changes the representation');
    assert.equal(entity(b).body, h.record().body); assert.notEqual(tagOf(b), tagOf(a));
  }},
  {id: 'HC06', name: 'Weak comparison and a list containing the current tag work', run: async h => {
    const a = await h.request(); const tag = tagOf(a).replace(/^W\//, '');
    for (const value of [`W/${tag}`, `"unrelated", W/${tag}`]) {
      const r = await h.request({headers: conditional(value)}); assert.equal(r.status, 304);
    }
  }},
  {id: 'HC07', name: 'Quoted commas and a nonmatching list are parsed as tags', run: async h => {
    const a = await h.request();
    assert.equal((await h.request({headers: conditional('"not,the,tag", "other"')})).status, 200);
    assert.equal((await h.request({headers: conditional(`"not,the,tag", ${tagOf(a)}`)})).status, 304);
  }},
  {id: 'HC08', name: 'Wildcard validation does not turn a missing resource into 304', run: async h => {
    assert.equal((await h.request({headers: conditional('*')})).status, 304);
    const r = await h.request({path: '/api/bulletins/missing', headers: conditional('*')});
    assert.equal(r.status, 404); assert.equal(r.headers['cache-control'], 'no-store');
  }},
  {id: 'HC09', name: 'Unsupported mutation methods preserve 405 and Allow', run: async h => {
    const r = await h.request({method: 'POST', headers: conditional('*')});
    assert.equal(r.status, 405); assert.equal(r.headers.allow, 'GET, HEAD');
    assert.equal(r.headers['cache-control'], 'no-store');
  }},
  {id: 'HC10', name: 'HEAD keeps GET metadata while omitting content', run: async h => {
    const a = await h.request(); const b = await h.request({method: 'HEAD'});
    assert.equal(b.status, 200); assert.equal(b.bytes, 0); assert.equal(tagOf(b), tagOf(a));
    assert.equal(Number(b.headers['content-length']), a.bytes);
    const c = await h.request({method: 'HEAD', headers: conditional(tagOf(a))});
    assert.equal(c.status, 304); assert.equal(c.bytes, 0);
  }},
  {id: 'HC11', name: 'Malformed conditional syntax gets the published 400 response', run: async h => {
    for (const value of ['unquoted', '"unterminated', '* , "mixed"', 'w/"lowercase"']) {
      const r = await h.request({headers: conditional(value)});
      assert.equal(r.status, 400, value); assert.equal(r.headers['cache-control'], 'no-store');
    }
  }},
  {id: 'HC12', name: 'Setting an identical value leaves the representation unchanged', run: async h => {
    const a = await h.request(); h.set('title', h.record().title);
    const b = await h.request({headers: conditional(tagOf(a))}); assert.equal(b.status, 304);
  }},
  {id: 'HC13', name: 'Changing one resource does not invalidate another unchanged resource', run: async h => {
    const path = '/api/bulletins/meeting'; const a = await h.request({path});
    h.set('body', 'Only the notice has changed.');
    const b = await h.request({path, headers: conditional(tagOf(a))});
    assert.equal(b.status, 304);
    const c = await h.request({headers: conditional(tagOf(a))}); assert.equal(c.status, 200);
  }},
  {id: 'HC14', name: 'Non-ASCII content has correct byte length and validation', run: async h => {
    const a = await h.request(); h.set('body', 'Café: 東京 opens at 09:00 — welcome.');
    const b = await h.request({headers: conditional(tagOf(a))}); assert.equal(b.status, 200);
    assert.equal(entity(b).body, h.record().body);
    assert.equal(Number(b.headers['content-length']), Buffer.byteLength(b.body));
  }},
  {id: 'HC15', name: 'State errors remain visible as 500 rather than a successful cache result', run: async h => {
    const a = await h.request(); h.breakState();
    const b = await h.request({headers: conditional(tagOf(a))}); assert.equal(b.status, 500);
    assert.equal(b.headers['cache-control'], 'no-store');
  }},
  {id: 'HC16', name: 'A newly fetched changed representation can itself be validated', run: async h => {
    await h.request(); h.set('title', 'A second state');
    const a = await h.request(); assert.equal(entity(a).title, h.record().title);
    const b = await h.request({headers: conditional(tagOf(a))}); assert.equal(b.status, 304);
  }},
  {id: 'HC17', name: 'Unknown routes and unsupported queries retain their errors', run: async h => {
    assert.equal((await h.request({path: '/unknown'})).status, 404);
    assert.equal((await h.request({path: '/api/bulletins/notice?ignored=yes'})).status, 400);
  }}
];

export const transferCases = [
  {id: 'TX01', name: 'Summary followed by full selects both correct shapes', run: async h => {
    const a = await h.request({headers: view('summary')}); assert.deepEqual(entity(a), summary(h.record()));
    const b = await h.request({headers: view('full')}); assert.deepEqual(entity(b), full(h.record()));
  }},
  {id: 'TX02', name: 'Full followed by summary does not leak the full shape into summary', run: async h => {
    const a = await h.request({headers: view('full')}); assert.deepEqual(entity(a), full(h.record()));
    const b = await h.request({headers: view('summary')}); assert.deepEqual(entity(b), summary(h.record()));
  }},
  {id: 'TX03', name: 'A validator from a different representation does not produce false 304', run: async h => {
    const a = await h.request({headers: view('summary')});
    const b = await h.request({headers: view('full', tagOf(a))}); assert.equal(b.status, 200);
    assert.deepEqual(entity(b), full(h.record())); assert.notEqual(tagOf(a), tagOf(b));
    const c = await h.request({headers: view('full', tagOf(b))}); assert.equal(c.status, 304);
  }},
  {id: 'TX04', name: 'Both views honor changes and expose Vary on 200 and 304', run: async h => {
    for (const chosen of ['summary', 'full']) {
      const a = await h.request({headers: view(chosen)});
      assert.equal(a.headers.vary, 'X-Bulletin-View');
      h.set('title', `Updated for ${chosen}`);
      const b = await h.request({headers: view(chosen, tagOf(a))}); assert.equal(b.status, 200);
      assert.equal(entity(b).title, h.record().title);
      const c = await h.request({headers: view(chosen, tagOf(b))}); assert.equal(c.status, 304);
      assert.equal(c.headers.vary, 'X-Bulletin-View');
    }
  }},
  {id: 'TX05', name: 'Default full view and invalid explicit views follow the contract', run: async h => {
    const a = await h.request(); const b = await h.request({headers: view('full')});
    assert.equal(a.body, b.body); assert.equal(tagOf(a), tagOf(b));
    const c = await h.request({headers: view('private')}); assert.equal(c.status, 400);
    assert.equal(c.headers['cache-control'], 'no-store');
  }}
];

export async function runContract(scenario, options = {}) {
  const cases = scenario === 'transfer' ? [...commonCases, ...transferCases] : commonCases;
  const outcomes = [];
  for (const item of cases) {
    try {
      options.reset?.();
      await withLab(scenario, options, item.run);
      outcomes.push({id: item.id, name: item.name, passed: true});
    } catch (error) {
      outcomes.push({id: item.id, name: item.name, passed: false, message: error.message});
    }
  }
  return outcomes;
}
