import http from 'node:http';
import {once} from 'node:events';
import {createScenario} from '../lab/lib/scenario.mjs';
import {seedState, setField} from '../lab/lib/state.mjs';

export async function withLab(scenario, options, run) {
  let state = seedState();
  let brokenState = false;
  const server = await createScenario(scenario, {
    readState: () => { if (brokenState) throw new Error('Injected course fixture fault'); return state; },
    ...options
  });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const port = server.address().port;
  const h = {
    scenario, port,
    set: (field, value, id = 'notice') => setField(state, id, field, value),
    record: (id = 'notice') => structuredClone(state.bulletins[id]),
    breakState: () => { brokenState = true; },
    request: ({path = '/api/bulletins/notice', method = 'GET', headers = {}} = {}) => new Promise((resolve, reject) => {
      const req = http.request({host: '127.0.0.1', port, path, method, headers, agent: false}, response => {
        const chunks = [];
        response.on('data', chunk => chunks.push(chunk));
        response.on('error', reject);
        response.on('end', () => {
          const bytes = Buffer.concat(chunks);
          resolve({status: response.statusCode, headers: response.headers, bytes: bytes.length,
            body: bytes.toString('utf8')});
        });
      });
      req.setTimeout(4000, () => req.destroy(new Error('Lab request timed out')));
      req.on('error', reject);
      req.end();
    })
  };
  try { return await run(h); }
  finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
}
