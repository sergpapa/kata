---
document_id: WB-HTTP-001
version: "1.0.0"
exercise_ids: "EX-HTTP-01 through EX-HTTP-24; optional EX-HTTP-H01"
---

# HTTP exercise workbook

Record your answers and observations in [Investigation.md](../learner/Investigation.md), using the exercise ID. These are open-resource engineering exercises. Research, questions, and experiments are welcome. Record solution-specific help using the [hint ladder](../hints/HTTP_Hints.md). Predictions should be captured before their experiment; a corrected prediction is useful learning evidence.

Difficulty and help are separate: L1 Guided, L2 Easy, L3 Normal, L4 Hard, L5 Expert, L6 Heroic. The required HTTP slice reaches L4. An optional above-target problem follows it; declining or not completing that problem does not block the slice.

## LS-HTTP-01: inspect an exchange

### EX-HTTP-01 — Label the exchange (L1, prediction and observation)

Before running curl, predict the requested resource, response content type, and whether the response body is the whole page. Run the API request from the environment guide. Annotate method, target, status, `ETag`, `Cache-Control`, and body. Which values belong to the request and which to the response? Explain what the Date header does **not** prove about a bulletin edit.

Deliver: prediction, one actual bounded response, and annotations. Indicators: NET-04.i01, ENG-07.i01.

### EX-HTTP-02 — Trace unfamiliar code (L2, code archaeology)

Find the functions responsible for listening, reading current state, selecting content, creating a tag, and deciding 200/304. For each, record its file, input, and output. Follow a request to `/unknown` and identify where normal processing stops. Do not rewrite the handler.

Deliver: a five-row responsibility table and one control-flow explanation. Indicators: NET-04.i01, PRG-05.i01.

### EX-HTTP-03 — Compare browser and terminal (L2, tool practice)

Capture the browser request to the bulletin API and a comparable curl request. Record browser/version, cache settings, selected bulletin, and any conditional request header. Explain one similarity and one potentially meaningful difference. If evidence is missing, state what observation would resolve it.

Deliver: bounded request/response evidence and comparison. Indicators: NET-08.i01, BRW-06.i01, ENG-07.i01.

## LS-HTTP-02: track identity and content

### EX-HTTP-04 — Predict a state change (L1, prediction)

Predict which of URL, resource ID, runtime revision, representation body, and Git commit will change when the fixture command changes only `notice.body`. Run the command and inspect both runtime state and the response. Do not confuse a expected tag relationship with what this faulty starter actually does.

Deliver: before/after table with predictions separated from observations. Indicators: NET-04.i02, ENG-07.i01.

### EX-HTTP-05 — Explain the selected fields (L2, code reading)

Given a record containing `id`, `revision`, `title`, and `body`, write the exact string returned by `selectRepresentation`, including its final newline. Why is the record's revision not automatically present in the response? What assumption would break if a future developer changed this function without considering validation?

Deliver: returned string and a short explanation. Indicators: NET-04.i01, PRG-05.i01.

### EX-HTTP-06 — Change nothing (L2, controlled experiment)

Set a title to the value it already has. Predict whether the revision should advance under the published fixture contract. Observe the revision, bytes, and tag before and after. Then change one character and compare. Keep the other record untouched.

Deliver: commands, observations, and one conclusion scoped to this fixture. Indicators: NET-04.i02, ENG-02.i01.

## LS-HTTP-03: observe cache layers

### EX-HTTP-07 — An empty wire body and a visible notice (L1, prediction)

Reset/restart and run terminal `get`, followed by `revalidate`. Predict wire status, wire-body length, and selected client content before each request. Explain where the displayed body comes from when the wire body is empty.

Deliver: two request records and explanation. Indicators: NET-04.i02, NET-08.i01.

### EX-HTTP-08 — Does the old copy still apply? (L3, debugging)

After recording a client body/tag, change the server's notice body. Predict and run revalidation with the old tag. Also make an unconditional request against the same state. Record the contradiction if one occurs. Do not change code yet.

Deliver: state identity, both requests, relevant raw responses, and a one-sentence symptom. Indicators: NET-04.i02, ENG-02.i01.

### EX-HTTP-09 — Separate bypass from repair (L3, diagnosis)

Compare the browser viewer's normal and bypass buttons after a data change. Record request mode, exposed page status, actual Network evidence, and server logs. Explain why clearing a cache can help diagnosis without proving the server's validation is correct. If your browser behaves differently, preserve that evidence and use the terminal model to isolate the origin.

Deliver: controlled comparison, settings, and limits. Indicators: NET-08.i01, BRW-06.i01, ENG-07.i01.

## LS-HTTP-04: conditional-request case matrix

### EX-HTTP-10 — Commit to a case matrix (L2, prediction)

Fill the expected status, wire body, and reason in this table **for a correct implementation** before running the public checks. Then annotate what the starter actually does. “Depends” needs the condition that makes it depend.

| Case | Request and state | Expected status | Wire content? | Reason |
| --- | --- | --- | --- | --- |
| A | Existing bulletin, GET, no condition | | | |
| B | Unchanged content, saved current tag | | | |
| C | Changed title, saved old tag | | | |
| D | Changed body, saved old tag | | | |
| E | Existing bulletin, nonmatching quoted tag | | | |
| F | Current tag appears in a list | | | |
| G | Weak form of current tag | | | |
| H | `*` and an existing bulletin | | | |
| I | `*` and a missing bulletin | | | |
| J | HEAD, existing bulletin, no condition | | | |
| K | HEAD with a matching current tag | | | |
| L | POST with a matching tag | | | |
| M | Malformed unquoted condition | | | |
| N | State reader fails while processing a conditional request | | | |

Deliver: completed predictions and observed differences. Indicators: NET-04.i02, PRG-05.i01.

### EX-HTTP-11 — Read a parser without replacing it (L2, code reading)

For the values below, predict `parseIfNoneMatch`'s result and whether it matches the current tag `"b"`. Use a tiny local script or Node REPL importing the supplied helper to check. Explain why splitting only on commas would be wrong.

```text
W/"b"
"a,b", "b"
"B"
*
unquoted
```

Deliver: parsed forms, comparisons where input is valid, and one parser-boundary explanation. Indicators: NET-04.i02, PRG-05.i01.

### EX-HTTP-12 — Preserve negative paths (L3, verification)

Run a missing-resource request with `If-None-Match: *`, an unsupported POST, and a HEAD. Trace why their body/status behavior differs. Inspect HC15 to understand the supplied state-failure injection without corrupting your real runtime file. Explain why “check cache first, then find the resource” could be a mistake.

Deliver: three local observations plus one source trace. Indicators: PRG-05.i01, NET-04.i03.

## LS-HTTP-05: investigate the reported defect

### EX-HTTP-13 — Two hypotheses, one useful experiment (L3, debugging)

Use the issue report in lesson 5. Write two plausible hypotheses and the outcomes that would support or weaken each. Run an experiment that changes one relevant variable. Keep a failed hypothesis if it was useful; do not rewrite history to look immediately correct.

Deliver: hypothesis/experiment record with actual ordering. Indicator: ENG-02.i01.

### EX-HTTP-14 — Follow the value (L3, archaeology)

Trace the current record, serialized body, computed tag, parsed condition, and selected status for the failing case. Mark the first boundary at which the program contradicts your intended relationship. Distinguish a directly observed value from one inferred by reading source.

Deliver: a value trace with file references and evidence provenance. Indicators: NET-04.i03, ENG-07.i01.

### EX-HTTP-15 — Assess the warning (L3, signal and noise)

Find the optional telemetry warning's source. Identify whether it changes representation data or the response decision. Explain what observation would make you reconsider its relevance. Do not “fix” the problem by deleting this warning.

Deliver: a bounded causal argument. Indicators: ENG-02.i01, ENG-07.i01.

## LS-HTTP-06: implement and defend a repair

### EX-HTTP-16 — Repair the representation relationship (L3, implementation)

Implement a focused repair. Preserve unchanged validation, current content after title/body changes, other resources, HEAD, and error behavior. Keep the published cache policy. Describe your representation identity and what future change would require revisiting it.

Deliver: source diff, rationale, and public contract results. Indicators: NET-04.i03, PRG-05.i01, GIT-02.i01.

### EX-HTTP-17 — Write a test that exposes the old defect (L3, testing)

Replace the TODOs in `test/learner-regression.test.mjs` with a changed-content regression and a distinct boundary/resource test. Assert observable status/content; do not hard-code the chosen hash. Show that the regression fails against a separate starter snapshot and passes with your repair, or clearly label any unverified comparison.

Deliver: test source, source-linked before/after report, and explanation. Indicator: TST-02.i01.

### EX-HTTP-18 — Compare defensible designs (L4, judgment)

Describe two ways to maintain an appropriate validator under this fixture's contract. Explain the change-tracking assumption and per-request work of each. Then reject two near misses using concrete counterexamples: title-only tag, always-200 response, always-new tag, or disabling storage.

Deliver: a comparison and counterexamples. Indicators: NET-04.i03, COM-04.i01.

## LS-HTTP-07: review and revise

### EX-HTTP-19 — Assemble a bounded packet (L2, engineering communication)

Fill the investigation record; inspect source status/diff; run the submission preview. Open each selected file before writing a local packet. Supply a baseline and selected raw observations separately. State exactly what is missing and what the receiver is authorized to review. Do not submit the instructor answers as your own source.

Deliver: packet manifest, source/baseline, notes, and help events. Indicators: ENG-07.i01, GIT-02.i01.

### EX-HTTP-20 — Respond to a valid finding (L3, review)

Review finding: “The submitted tests cover a title change but do not check a body-only change. A tag derived from title alone could pass your tests.” Accept, partly accept, or rebut according to your actual test source. If it applies, add a meaningful case and supply the result; if it does not, point to the relevant assertion.

Deliver: evidence-based response and any revision. Indicators: TST-02.i01, COM-04.i01.

### EX-HTTP-21 — Challenge an unjustified rule (L3, review)

Review finding: “Only a SHA-256 tag is acceptable. A revision-based implementation automatically fails.” Evaluate this claim against the published contract and the actual mutation mechanism. Explain when a version approach is valid and when it would cease to be valid. Do not change a valid design solely to match a reference diff.

Deliver: reasoned response with assumptions and a verification request if context is missing. Indicator: COM-04.i01.

## LS-HTTP-08: transfer to changed selection

### EX-HTTP-22 — Record a new baseline (L3, prediction)

After the planned interval, record actual delay, previous solution exposure, and help. Before testing, predict full/summary fields for both request orders at the same URL. Identify which request input selects the representation. Do not copy the first fix by default.

Deliver: variant context and predictions. Indicators: NET-04.i02, NET-08.i01, ENG-07.i01.

### EX-HTTP-23 — Investigate and repair the new defect (L4, transfer)

Reproduce both orders with a clean server state between them. Follow selection and validation separately. Repair the relevant code, preserve `Vary` and ordinary conditional behavior, and run HC01–HC17 plus TX01–TX05. Explain whether a correct validator can identify the wrong selected body correctly.

Deliver: hypothesis record, diff, case results, and rationale. Indicators: NET-04.i03, NET-08.i01, PRG-05.i01, TST-02.i01, GIT-02.i01.

### EX-HTTP-24 — Explain the new boundary (L4, defense and reflection)

Compare two valid repairs for the transfer defect. Explain why the main repair alone would not fix it. If you needed the walkthrough, state the missing insight and propose a different future observation that would show you can apply it. Respond to one review finding about the necessity of retaining the server's memo table.

Deliver: defense, review response, residual limits, and complete help record. Indicators: COM-04.i01, ENG-02.i01, ENG-07.i01.

## EX-HTTP-H01 — Heroic: a representation changes without a record edit

**Optional L6, above this slice's target.** Suggested investigation timebox: 90–180 minutes, adjustable. No prerequisite credit depends on completion.

Product introduces two rendering revisions during a rolling deployment. Both servers read the same record revision, but one serializes an additional public field. A reviewer proposes an identifier based only on record ID and revision. Research the distinction between representation identity, semantic equivalence, and encoding; design a course-owned two-renderer experiment that demonstrates your claim. No external server, real customer data, or deployment is needed.

Submit hypotheses, documentation consulted, a small local comparison or pseudocode with clearly stated limits, and a proposed repair. Consider how you would revise the test if one renderer also changed whitespace or content encoding. It is acceptable to stop with a precise unanswered question. The full discussion is in the walkthrough, including limitations of the experiment. A diagram or written trace is an acceptable access alternative to running an additional script.
