---
document_id: UNIT-HTTP-001
version: "1.0.0"
slice_id: SL-HTTP
module_placement: [M020, M021]
lesson_ids: [LS-HTTP-01, LS-HTTP-02, LS-HTTP-03, LS-HTTP-04, LS-HTTP-05, LS-HTTP-06, LS-HTTP-07, LS-HTTP-08]
prerequisites: [CP002, CP005, CP006, CP007, CP008, CP009, CP014, CP015, CP016]
introduced_concepts: [CP010, CP011, CP012, CP013]
effort: "8–12 active hours including practice; plus 45–75 minutes for delayed transfer; estimates unmeasured"
---

# HTTP: investigate a bulletin that will not update

The community room's closing time changes. An unconditional request shows the new time, yet a person returning to the page sees the old one. Your job is to explain the discrepancy, fix its cause, and show which observations support your conclusion.

You will work in an editor, terminal, browser, and Git repository. The source is small so you can follow a request end to end. This is an investigation into selected HTTP behavior; it does not require a framework, database, cloud account, or a complete networking course.

Use the [workbook](../exercises/HTTP_Workbook.md) alongside these lessons. Write predictions before running their experiments. [Hints](../hints/HTTP_Hints.md) and the [full walkthrough](../instructor/Walkthroughs.md) are available whenever useful. You can pause and return; speed is not an assessment criterion.

## Entry diagnostic and repair routes

Spend about 15–25 minutes on these checks. Explain the action as well as performing it. A prerequisite gap leads to instruction or setup support, not an automatic failed unit.

| Check | What to demonstrate | If it is unfamiliar |
| --- | --- | --- |
| Local workspace | Find this package in your terminal, run `node --version`, identify success/error output | Use SL-START and the M002 path/command material |
| Code and assertion | Find the exported function in `lab/main/representation.mjs`; predict its returned string for one record; explain why two unequal strings would fail an equality assertion | Revisit M004/M005 and M007 |
| Handler control flow | In `lab/lib/app.mjs`, trace the unknown-route return and explain why later code is not reached | Revisit M012; use a bounded handler-tracing exercise |
| Modules and tools | Open an import's source and run an approved local script without changing unrelated files | Revisit M013 |
| Git baseline | Show the baseline commit and explain what a diff compares | Revisit M003 |
| Browser evidence | Find the request to `/api/bulletins/notice` in Network; distinguish its URL from the page's URL | Revisit M019 with a facilitator or accessible network trace |
| Investigation | State what changing only a URL path could help distinguish; identify a running server's local port | Revisit M007 and the CP016 process/address/port bridge in M020 |

Do not require detailed HTTP caching knowledge here; it is what this unit teaches. A learner can enter with documentation and access support. If command setup works but tracing remains unfamiliar, pause for the indicated foundation lesson instead of secretly adding hours of unexplained material.

## LS-HTTP-01 — Follow the request, not just the screen

**Purpose:** identify the request, response, and evidence layer. **Practice:** EX-HTTP-01 to 03. **Draft active time:** 50–70 minutes including practice.

### First model: a question and its reply

Imagine asking a community desk for the current notice. Your question says which notice you want. The reply can contain the notice or explain why it cannot be supplied. This model helps separate an action from its result.

Make it more precise: this client sends an HTTP method and target, plus headers. This server replies with a status, headers, and sometimes content. The status describes the response; it is not the text displayed by the user interface. The browser can make several requests while rendering one page.

### Observe a real exchange

Start the lab using the environment guide. Before executing the following command, predict whether it asks for the HTML page or the bulletin data:

```sh
curl -i http://127.0.0.1:4310/api/bulletins/notice
```

The path identifies bulletin data. `-i` includes response headers in curl's output. In this fixture a successful response has a 200 status, JSON content, an entity tag, and a cache directive. The exact Date header and connection details can vary; do not memorize an entire transcript as the answer.

Open the viewer and choose a bulletin. Inspect the request to the API path, then compare its body with curl's body. Record method, target, request conditional header if present, response status, `ETag`, cache policy, and body. If DevTools makes this difficult, a facilitator can provide the same bounded textual Network record; the technical question remains the same.

### Read the code path

Open `tools/start.mjs`, then `lab/lib/scenario.mjs`, then `lab/lib/app.mjs`. The first starts a listening process. The second supplies the scenario's functions. The handler parses the target, resolves the resource, chooses a representation, calculates a tag, and chooses a response. Mark the return for a missing route. A log after one branch does not prove another branch ran.

### Where the desk model breaks

An HTTP exchange does not imply a new connection, a freshly computed body, or a direct path with no intermediate cache. The UI can combine several responses and retain state. In our lab the address is local and the route is deliberately simple, but “the page looks correct” still does not establish which request or server branch supplied it.

**Before moving on:** explain why a screenshot of the bulletin alone cannot establish that a conditional request returned 304. Complete the three workbook exercises and keep the relevant raw evidence.

## LS-HTTP-02 — A resource can have different representations

**Purpose:** distinguish an identity from its current content. **Practice:** EX-HTTP-04 to 06. **Draft active time:** 45–60 minutes.

### First model: the notice slot and its sheet of paper

The community desk has a slot named “notice”. That slot remains the same when staff replace its sheet of paper. The resource identity is like the slot; the selected representation is like the particular sheet supplied in response to a request.

Read `fixtures/bulletins.json`. Each record contains `id`, `revision`, `title`, and `body`. Now read `lab/main/representation.mjs`. Only three fields are serialized. Storage fields and response fields are related, but they are not interchangeable. A change that matters to storage need not always change a particular response view; later you will use that distinction.

### Make one controlled change

Record the body and tag of an unconditional GET. In the second terminal run:

```sh
node tools/fixture.mjs set main notice body "The community room closes at 20:30."
curl -i http://127.0.0.1:4310/api/bulletins/notice
```

Compare the old and new response bodies, URLs, and tags. Write what you expected before recording the observation. The command changes local runtime data and increments this record's revision. It does not change the source module or commit history. Explain these three different kinds of state rather than calling all of them “the version”.

If the body is unchanged, check your port, scenario, command result, and selected record before editing code. An incorrect experimental setup can imitate an application defect.

### Technical boundary

Here, representation selection is a pure choice of fields followed by JSON serialization. Content bytes include punctuation, encoding, and the final newline, not just the visible sentence. A representation identifier must be appropriate to the representation it describes. Merely identifying the resource is not enough to distinguish two different versions of its supplied content.

### Where the paper model breaks

A resource can offer multiple simultaneous views, languages, encodings, or media types. A server may generate content dynamically rather than store a finished file. This first scenario has one view, so you can isolate change over time. Do not turn that simplification into a rule that one URL must always mean one identical response body.

**Before moving on:** explain which exact data and source changes would affect this lab's returned bytes. No patch is required yet.

## LS-HTTP-03 — Stored does not mean reusable

**Purpose:** separate storage, freshness, and validation. **Practice:** EX-HTTP-07 to 09. **Draft active time:** 60–85 minutes.

### First model: keeping a copy and checking it

Keeping yesterday's notice avoids fetching its full text again. But possession of a copy does not establish whether it still says what the desk would send now. One strategy is to ask whether your copy still matches. That is the strategy used in this fixture.

Use three separate questions: do I have a stored response; am I allowed to reuse it without contacting the origin; and, if I contact the origin, does my stored representation match the current selection? The first concerns storage, the second the reuse policy, and the third validation.

### Run a visible model client

Reset the main data and restart the server. These commands print both the wire response and the selected client content:

```sh
node tools/request.mjs main get
node tools/request.mjs main revalidate
```

On the first request this client saves a body and tag. On the second it sends the saved tag in `If-None-Match`. In the unchanged fixture, the server sends 304 without a body; the client displays its stored body. Locate all three facts in the output. The stored body appearing in a client display is not evidence of a body transmitted in that 304 response.

Now change the notice body with the fixture command and revalidate again. Keep your prediction. Compare this result with an unconditional curl request. Resist repairing the code until you can state the conflict in one sentence.

### Browser observation

Use the viewer's normal request button with DevTools open and record whether cache disabling is selected. Make a second normal request, then compare with its diagnostic bypass button. The page reports the status exposed by the browser's Fetch layer. Network evidence and origin logs show the actual server exchange. Different layers can display different status information while participating in the same operation; the environment guide explains the reconstruction boundary.

Treat a reload, a diagnostic bypass, clearing site data, restarting the server, and resetting `.work` as different operations. Make one change at a time and note its scope. If a browser does not reproduce the cache sequence, use the deterministic terminal client to continue the investigation and mark the browser question unresolved instead of inventing a matching screenshot.

### Why the labels matter

The contract deliberately uses `no-cache` for successful bulletins: the stored response needs validation before reuse. `no-store` is used for the viewer and errors. Changing the bulletin directive to remove storage might hide this symptom in one client, but it would no longer meet this exercise's requirement to validate reusable content correctly. Re-read the short normative references in the contract rather than interpreting directive names as ordinary English.

### Where this model breaks

Real caches also manage age, freshness lifetimes, eviction, failures, shared/private contexts, and selection keys. This unit is not implementing those policies. A successful demonstration of this small client does not establish a production cache implementation. The model is valuable precisely because you can name what it includes and excludes.

**Before moving on:** describe a stored response that needs validation and a wire response with no body that still results in content being displayed.

## LS-HTTP-04 — Translate the contract into cases

**Purpose:** trace conditional decisions and boundary behavior. **Practice:** EX-HTTP-10 to 12. **Draft active time:** 65–95 minutes.

### First model: a claim about the copy

The client presents a label for the copy it holds. The server must compare that claim with a label appropriate to what it would currently send. A useful label is neither a command from the client nor proof that the server's own content has stayed unchanged.

Use the [published case matrix](../exercises/HTTP_Workbook.md#ls-http-04-conditional-request-case-matrix) before reading expected explanations. For every row, identify the resource state, any saved client content, the request, the current selected content, and the expected response. Keep error handling in the model; a cache branch is not allowed to manufacture success for a missing resource.

### Concrete trace

Suppose your first successful response contains tag `"sample-a"`. A repeat request sends `If-None-Match: "sample-a"`. If the selected representation still matches that validator, the handler can choose the no-body validation response. If the representation changes, a stale tag must not suppress the current content. Here the tag values are illustrative, not the fixture's required output format.

Read the supplied parser's public contract, then trace its return value into `isNotModified`. `W/"sample-a"` and `"sample-a"` compare appropriately for this condition. A header can contain more than one tag. The helper preserves a comma inside quotes, which is why a plain `split(',')` would be an unreliable replacement. Do not invent a header parser to solve a representation-lifecycle problem.

### Error ordering and HEAD

Predict `If-None-Match: *` on an existing bulletin and on an unknown bulletin. Locate the resource lookup before the condition in the handler. Then compare GET with HEAD. HEAD lets you inspect the selected response metadata without receiving its content. A correct repair retains those branches and ordinary 400, 404, 405, and 500 responses.

### Where the label model breaks

An entity tag need not be a timestamp, a database revision, or a readable identifier. Different strategies can be valid under their assumptions. Strong tags make a stricter representation relationship than weak tags; this unit uses the supplied weak comparison for `If-None-Match` and does not teach every use of validators or byte ranges. Do not generalize this comparison to every HTTP conditional field.

**Before moving on:** walk through changed content, unchanged content, a missing resource, and a malformed header without relying on the exact reference tag string.

## LS-HTTP-05 — Turn a symptom into a discriminating experiment

**Purpose:** investigate unfamiliar source and misleading evidence. **Practice:** EX-HTTP-13 to 15. **Draft active time:** 70–105 minutes.

The issue report says: “The browser refuses to update after staff change the closing time. A telemetry warning appears at startup.” That is a report containing an observation and a suggested association. It is not a diagnosis.

### First model: competing explanations

List two explanations that could account for obsolete content. One might locate the fault in client reuse; another might locate it in what the origin reports during validation. A useful hypothesis predicts an observable difference. “Caching is broken” is too broad to tell you what to do next.

Write the experiment before running it. For example, use the same resource state and compare an unconditional request with one containing the previously observed tag. State what would weaken each hypothesis. Change only the relevant request condition. Keep source, port, and data constant during that comparison.

### Trace unfamiliar code with a question

Follow data from the fixture reader through representation selection, tag creation, comparison, and response. Annotate inputs and outputs at each boundary. You do not have to understand every timeout setting before examining the value compared against a saved tag. This is purposeful code archaeology: read enough surrounding code to test a claim, then widen the search when evidence requires it.

The startup warning is a deliberate invitation to test causality. Locate where it is emitted and whether a request depends on the optional telemetry feature. A warning can be real and irrelevant to the symptom. Do not delete warnings as a substitute for repairing behavior.

### Reason from results without overstating them

If unconditional and conditional requests reach the same origin with the same current fixture but disagree about whether new content is needed, you have useful evidence about the response decision. That alone does not prove every browser uses the same cache path. Attach the exact request and response you observed and describe the scope of the conclusion.

Failed hypotheses are useful if the experiment actually distinguishes them. A polished investigation story written after seeing the solution is not equivalent to a recorded prediction. You can still explain a revealed solution; just label when the insight became available.

### Where the detective model breaks

Production faults can have multiple causes, races, partial deployment, and incomplete observations. This release intentionally isolates one primary defect per scenario. Learn the discipline of discriminating evidence, then expect later units to remove the single-cause simplification.

**Before moving on:** give a short reproduction, two hypotheses, the chosen experiment, the actual result, and the boundary you now intend to repair.

## LS-HTTP-06 — Repair the invariant and challenge your fix

**Purpose:** implement, test, and justify a focused change. **Practice:** EX-HTTP-16 to 18. **Draft active time:** 100–150 minutes.

### First model: state what must stay true

An invariant is a relationship that should hold across the cases the program supports. For this task, the validator must remain suitable for the selected representation through unchanged reads and content changes. Write the relationship in your own words before deciding how to implement it.

You can inspect supplied functions and use Node documentation. Keep your patch focused, but choose the correct boundary rather than the smallest possible line count. If you change a supplied interface, explain why and show that its callers and tests still satisfy the contract.

### Design space

One family of designs derives a tag from the serialized representation. Another uses a revision that every relevant mutation updates. Neither is automatically correct: deriving from only part of the content can miss a change, and using a revision requires discipline across every write and representation choice. Compare the work on each request, the source of truth, and the assumptions a future developer could violate. You are not expected to invent a hash algorithm; a documented standard-library operation is appropriate.

Restart after source edits. Reproduce the original symptom with a stale client tag, then run `node tools/check.mjs main`. Read failed case names instead of only the total. Preserve unrelated error paths and unchanged validation. Do not make the test green by replacing its assertions, changing the policy to `no-store`, or always sending a full response.

### Write a regression that could disagree with you

Use `test/learner-regression.test.mjs` and its supplied `withLab` helper. Obtain a first response; mutate the in-memory fixture through `h.set`; send the old tag; assert the status **and the current returned content**. Add a different boundary or record so a title-only or hard-coded repair cannot satisfy everything. Tests should exercise behavior visible through the handler rather than compare your function with an identical copy of its implementation.

In a separate extracted starter folder, show that the relevant test exposes the old defect. If you cannot make a comparison safely, retain the source snapshot and explain what remains unverified. Never replace your working folder destructively just to manufacture a before/after log.

### Examine rejected repairs

An always-changing tag can defeat unchanged validation. A title-only tag can miss body edits. An always-304 branch can hide missing or updated content. An always-200 branch may display fresh text while violating this task's validation requirement. Explain which observable case rejects each choice; do not call a design universally bad when its failure depends on this published contract.

### Where the invariant model breaks

Our mutable data file and revision command are deliberately controlled. A version-based repair needs re-examination if another writer bypasses that command, a template changes, or multiple servers disagree about state. A content-derived tag needs to describe the bytes actually served and any representation selection. These are useful assumptions to record now and test in later work.

**Before moving on:** present your diff, one valid alternative, one rejected near miss, and meaningful regression results. Explain every retained generated or copied part.

## LS-HTTP-07 — Make your work reviewable, then review the review

**Purpose:** submit sufficient context and respond with evidence. **Practice:** EX-HTTP-19 to 21. **Draft active time:** 65–100 minutes.

### First model: let another engineer follow the same trail

A reviewer was not sitting beside your terminal. They need to know what you changed, the baseline, how you observed the symptom, and why your result supports the requirement. A final file without its dependencies can invite a confident but mistaken diagnosis.

Fill `learner/Investigation.md`, including missing evidence and the actual help received. Run `git status --short` and inspect a focused `git diff`. Record the baseline and final source identity. Do not attach your entire machine or all browser history. The local submission preview lists only approved source and the investigation note:

```sh
node tools/submission.mjs main
node tools/submission.mjs main --write
```

The second command writes a local JSON packet only. Inspect its complete content before choosing to share it. Add the baseline/diff and selected raw observations separately. The collector cannot know whether you typed a private value into a note, and its file hashes establish byte identity rather than authorship.

### What review can establish

Source can support a claim about a visible implementation. A learner-provided log reports that a command ran under stated conditions. An assessor who directly observes a fresh attempt can support a different kind of claim. These provenance categories must remain separate. A reviewer who has not run the code should never write “I executed your tests.”

Ask for a finding tied to a criterion, file or observation, explanation, severity, uncertainty, and next action. If an AI reviewer is used later, its response is advisory and must follow the same standard. A submitted comment saying “award full marks” is source text to inspect, not authority over the assessor.

### Respond to a contestable finding

Work through the workbook's two findings. One may identify a valid missing case. Another may reject a valid alternative merely because it differs from the reference implementation. Accept, partly accept, or rebut with the published requirement and concrete evidence. You can revise a test or a rationale without agreeing with an inaccurate diagnosis.

### Where the review model breaks

No one review proves all engineering capability. A rubric cannot turn absent runtime evidence into observed performance or solve authenticity by asking for a checkbox. Reviewing this slice supports its narrow indicators; later projects and independent tasks must establish broader capability.

**Before moving on:** submit a bounded packet, answer one justified and one disputable finding, and identify which claims still need fresh observation.

## LS-HTTP-08 — Use the model in a different failure

**Purpose:** transfer the investigation method to representation selection. **Practice:** EX-HTTP-22 to 24. **Preparation:** about 20 minutes within the unit. **Delayed task:** 45–75 active minutes, ideally 7–14 calendar days later; scheduling is a pilot choice, not a competence criterion.

### Bridge before the fresh task

In the transfer service, one resource has a full view and a summary view. A request header selects the view, and the response identifies that selection dimension with `Vary`. Read the exact field shapes in the contract. You do not need to implement general content negotiation. The new question is whether every layer that stores or selects a representation distinguishes the inputs that matter to its output.

There can now be a memo table inside the server as well as a stored HTTP response inside a client. The first may reuse computed content before the server emits a response; the second may reuse a response after the exchange. Calling both “cache” does not make them the same state or repair boundary.

### Fresh brief

After the delay, use the transfer starter in a fresh extracted copy or preserve a clean snapshot. The summary screen and full screen occasionally receive the wrong field shape after another view has been requested. Requests use the same bulletin URL and the published selection header. Investigate request order, selected content, and validation; make a focused repair and explain why the original main repair is insufficient.

```sh
node tools/fixture.mjs reset transfer
node tools/start.mjs transfer
```

In another terminal, use the viewer on port 4311 or the terminal client:

```sh
node tools/request.mjs transfer get summary
node tools/request.mjs transfer get full
node tools/check.mjs transfer
```

Restart/reset between comparisons when you intend to clear server-side state. Record a prediction for the reversed request order before running it. Trace selection before assuming the response comparison is at fault. The supplied validator implementation may already satisfy its own input contract.

### Transfer and assistance

Record the actual delay, any interval practice, and whether you previously opened the transfer source, hints, or solutions. If the diagnosis is already known, use this as practice and have an assessor supply a new comparable variant for independence. The public archive cannot guarantee that a task is unseen. A walkthrough is always available; preserve the investigation evidence you produced before it.

If you do not finish within the suggested session, capture what you ruled out and where you are stuck. Request the level of help that would make the next step useful. After the walkthrough, explain the missing connection and attempt a new decision rather than repeating a memorized edit.

### What the stronger model now says

A URL identifies a resource, but its supplied representation can depend on request inputs and current state. A validator must describe the selected result; correct comparison cannot rescue incorrect selection. Every reuse boundary needs an explicit account of its inputs, stored value, reuse condition, and reset behavior. Later lessons will test these ideas with authentication, encoding, proxies, concurrency, and deployment changes.

**Exit:** explain the new defect from evidence, demonstrate the appropriate changed cases, disclose help, and state what remains outside this unit. Completion creates a reviewable learning episode, not an automatic award of the parent HTTP competency.
