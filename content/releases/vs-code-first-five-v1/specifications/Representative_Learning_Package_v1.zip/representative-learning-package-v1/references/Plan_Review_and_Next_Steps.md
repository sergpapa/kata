---
title: "Full-Stack Engineering Program: Plan Review and Next Steps"
document_id: "FSSE-PLAN-REVIEW-001"
version: "1.0"
date: 2026-09-10
status: "Review completed; validation and implementation remain pending"
canonical_format: "markdown"
reviewed_standard_id: "GCS-FSSE-001"
reviewed_standard_version: "1.1"
---

# Plan Review and Next Steps

## Review Outcome

The course's educational direction remains intact: deep understanding, real professional tools, continuous unit practice, progressively harder engineering work, unfamiliar code, debugging, authorized security labs, cumulative projects, and a serious capstone. The local-development and no-server-execution boundary also remains intact.

The review found substantive assessment, safety, sequencing, and completeness gaps. These have been corrected in `Graduate_Competency_Standard_v1.md`, whose internal document version is now **1.1**. The existing filename is retained for continuity. This report explains the changes and recommends the next work; the standard is authoritative if the two differ.

The document is a reviewed design baseline, not a finished course or a validated qualification. All 201 original competency IDs and performance targets were preserved. Five competencies were added, yielding 206 practical competencies across 27 domains. Core/working depth is now explicit, with 12 separately identified specialist-awareness topics.

## Findings and Changes

| Priority | Gap in the earlier plan or document | Correction in v1.1 |
| --- | --- | --- |
| Critical | Local reports and source review could be mistaken for proof of runtime behavior, authorship, or independence. | Separate static, learner-reported, corroborated, and observed evidence. Critical graduation claims need stronger verification; learning-only reports cannot silently become verified credentials. |
| Critical | Moving execution off the platform was treated too much like solving security. | Added separate submission, AI-review, privacy, and local-lab trust boundaries. The revised standard cites primary technical guidance and requires implementation tests; it does not claim these controls already exist. |
| High | The assistance scale mixed amount of help with independence and adaptation; “highest assistance” was ambiguous. | Introduced H0 to H5, where higher means more help. Difficulty and changed context are separate. Documented migration rather than silently reinterpreting old records. |
| High | “Noncompensable” requirements lacked concrete blocking behavior and closure rules. | Added six critical-rule groups mapped to specific competencies and graduation gates, with remediation, fresh verification, human judgment, and appeals. |
| High | Depth categories existed but were not assigned; many outcomes bundled several behaviors. | Assigned domain defaults and explicit exceptions. Required assessable child indicators while retaining stable parent IDs. P targets remain demanding and must be calibrated rather than treated as empirically justified. |
| High | The plan implied that specification completeness establishes mid-level readiness. | Reframed the role as a bounded capability target. Added role calibration, learner trials, evidence limitations, and qualified final sign-off for a verified graduation claim. |
| High | AI review quality was largely assumed. | Added human-adjudicated reference cases, valid alternative solutions, hidden evaluation cases, critical false-pass/false-rejection measures, uncertainty, versioned review provenance, and advisory-only operation until justified. |
| High | Product and assessment feasibility tests came too late, after large curriculum-design work. | Moved risk tests, representative learning trials, UX discovery, and review evaluation earlier. Detailed app architecture follows tested workflows; a full lesson dependency graph is not a prerequisite for the first trial. |
| Medium | Beginner entry, package management, ORM behavior, quantitative reasoning, and genuine collaboration were not explicit enough. | Added entry and recovery paths plus PRG-09, PRG-10, DAT-10, OBS-09, and COM-09. Made relevant practical evidence explicit. |
| Medium | Gate details conflicted: explanation could imply implementation competence; cloud and Kubernetes could be read as alternatives; capstone events differed between sections. | Clarified G1, required real cloud and Kubernetes evidence, aligned G9 with the capstone events, and allowed valid evidence reuse without treating a gate label as coverage. |
| Medium | Heroic work and cumulative projects could create unlimited struggle or progression dead ends. | Added effort budgets, stopping conditions, requested walkthroughs, fresh later assessment, rescue snapshots, milestone entry, and separate process/correctness judgments. |
| Medium | Content lifecycle, workload, access, cost, maintenance, and operational ownership were underspecified. | Added compatible content releases, reference-solution review, environment manifests, realistic effort accounting, accessibility workflows, data lifecycle, and named responsibilities to resolve before release. |
| Medium | Several technical formulations were overly broad. | Qualified browser versus Node.js scheduling, HTTP transport versions, authentication integration, unsafe type boundaries, environment-specific build variants, and responsibility for generated code. |
| Medium | Markdown could be overwritten from an older DOCX; repeated labels and list spacing weakened machine parsing. | Made Markdown canonical, added an overwrite guard to the legacy converter, normalized section structure, and checked IDs, tables, references, and metadata. |

The narrow technical corrections are sourced inline in the standard, including the applicable IETF, W3C, OWASP, VS Code, Docker, and AWS documentation. Those references support technical points, not the effectiveness of our proposed teaching system.

## Important Product Consequences

### Learning feedback and verified graduation are different services

An automated tutor and reviewer can provide useful educational feedback without the platform executing student code. A stronger public competence claim needs stronger evidence. The revised standard proposes qualified human judgment for critical and final graduation decisions, with local observed work or fresh verification appropriate to the claim.

This does not authorize hiring reviewers or purchasing services. It makes staffing, qualifications, cost, scheduling, consent, and accessible observation explicit decisions. The initial pilot can be learning-only while we validate that model. If we choose a fully automated product, its reports must honestly state the evidence limits instead of inheriting a stronger credential claim.

### Exhaustive course scope does not equal MVP scope

The full program still includes real version control, databases, containers, cloud infrastructure, infrastructure as code, Kubernetes, operations, security, and advanced engineering judgment. The first software release does not need every domain's finished content, every submission format, an extension, MCP, or public certification.

The proposed private MVP accepts bounded plain-text source and evidence submissions with a manifest and preview. Archive/repository ingestion and editor integrations are later decisions with separate safety and usefulness tests. This narrows the first implementation, not the eventual curriculum.

### A broad standard still needs workload calibration

The standard now assigns 177 practical competencies to core depth and 29 to working depth. There are 91 P4 targets, many with compound behaviors. These are transparent draft requirements, not evidence that the program fits a particular duration.

Before promising a schedule, we must estimate and then measure reading, setup, experiments, implementation, research, review, revisions, integration, and assessment. We should first remove duplicated demonstrations and unnecessary specialist scope, while preserving required real-tool practice. No total course length or completion guarantee has been invented in this review.

## What We Still Need

The graduate standard answers **what capability and evidence we intend to require**. It cannot replace the following artifacts.

| Artifact | Main question | Status after this review |
| --- | --- | --- |
| Graduate competency standard | What must a graduate demonstrate, under what conditions? | Reviewed v1.1 draft; empirical calibration pending. |
| Curriculum architecture and syllabus | What is taught, in what order, at what depth, with which prerequisites and milestones? | Next deliverable. The domain list is not yet the syllabus. |
| Competency registry and coverage map | How do explicit indicators connect outcomes, concepts, lessons, exercises, and evidence? | Conventions established; structured implementation and mappings pending. |
| Lesson and exercise specifications | What constitutes a complete lesson, lab, hint ladder, rubric, solution, and transfer task? | Principles defined; reusable templates and detailed schemas pending. |
| Actual instructional content | What exactly will learners read, inspect, predict, build, debug, and submit? | Must be authored and tested. Start with representative learning slices. |
| Assessment implementation and evaluation | How are evidence, review, uncertainty, resubmission, appeals, and readiness handled reliably? | Policy strengthened; working engine and calibration data do not exist yet. |
| Product specification and UX design | How do learners, authors, reviewers, and support staff complete their tasks? | Early constraints defined; requirements, flows, accessible wireframes, and usability validation pending. |
| Technical specification and operations | How will the platform implement those workflows securely and reliably within cost limits? | Trust boundaries defined; stack, domain model, APIs, jobs, controls, tests, and deployment design pending. |
| Release and maintenance plan | What ships first, how do we validate it, and who maintains content, environments, review, and support? | Revised staged approach; owners and measured budgets pending. |

## Recommended Next Steps

### 1. Produce Curriculum Architecture v1

This is the next substantial Markdown deliverable. It should contain:

- A complete module-level syllabus from preparation and first programs through independent feature ownership, delivery, operations, and capstone work.
- Coverage of all 206 practical competencies and 12 awareness topics, showing where each is introduced, practiced, integrated, and assessed; mark tentative mappings and missing detail explicitly.
- A thin prerequisite graph that distinguishes required prior knowledge from useful background, co-requisites, and later revisits.
- Several cumulative project lines with milestones, recovery points, and fresh unfamiliar-code assessments.
- Placement of real tools and environment transitions, with hardware and paid-resource assumptions visible.
- An effort-estimation method and provisional module ranges with confidence and assumptions, not a promised total duration.
- Detailed lesson dependencies and assessable indicators for the first learning slices only; expand the rest progressively.

Completion means coherent coverage and a usable next content unit, not a fully detailed dependency graph for every eventual lesson.

### 2. Define assessment contracts and early product requirements alongside it

Create a small assessment specification and risk register covering criterion-level evidence, H-level help, valid alternative solutions, critical findings, uncertain results, fresh reassessment, and human decision authority. Specify the submission manifest, review output contract, and bounded failure behavior.

In parallel, draft the learner, author, and reviewer journeys and accessible wireframes. Include setup, learning, local work, preview/submission, review, response, assistance, resubmission, progress, and appeal. Record privacy, cost, environment, and support constraints now; do not lock a platform stack yet.

### 3. Author and trial representative content

Start with a bounded HTTP request/conditional-cache investigation for learners who have its prerequisites. Deliver the full teaching loop: explanation, predictions, local experiments, a small change, seeded defect, rubric, graduated hints, worked solution, review, revision, and a fresh transfer task.

Add a short beginner onboarding/first-program trial and a bounded advanced operational or security-lab probe. The first checks accessibility and setup assumptions; the second checks containment and practical evidence. Neither requires authoring an entire additional course.

Use qualified manual review and lightweight prototypes where sufficient. Test model review against independently adjudicated cases, then test the learning experience with consenting learners. Track comprehension, fresh transfer, false findings, missed critical defects, setup friction, effort, support burden, and cost. Choose acceptance criteria before judging held-out results.

### 4. Approve the release scope and write detailed app specifications

Use those results to revise curriculum difficulty, evidence thresholds, content templates, and UX. Define separately the first content release and the private software MVP.

Then specify roles and authorization, workflow states, domain entities, APIs, upload handling, review jobs, retries/cancellation, data retention, versioned authoring, progress decisions, observability, accessibility, cost budgets, acceptance tests, and deployment/recovery. This is when technology choices should be justified against requirements.

### 5. Build a private MVP, pilot, and expand in measured increments

Implement the validated learning/review loop, test adverse inputs and operational failures, and run a limited pilot. Expand content and integrations only when learning, review quality, access, maintenance, and operational criteria are met.

Do not equate an early pilot with proof of the full graduation outcome. Validate advanced gates and role readiness as learners and assessors reach those stages.

## Decisions to Resolve at the Appropriate Gate

| Decision | Working assumption for design | Must be resolved before |
| --- | --- | --- |
| Initial learner profile | Motivated beginner with basic computer literacy; experienced learners can demonstrate prerequisites. | Pilot recruitment and syllabus effort commitments. |
| Verification offering | Learning-only pilot; stronger graduation verification is separately designed and costed. | Advertising or awarding verified graduation. |
| Human roles | Qualified review for calibration, critical findings, appeals, and final verification. | Consequential assessment and support commitments. |
| Hardware and cloud access | Supported local paths plus a controlled real environment where required. | Assigning affected labs or collecting fees. |
| Student-source data | Minimum necessary context with explicit access, retention, provider handling, and reuse limits. | Collecting real submissions. |
| Full duration and pricing | Unknown until assumptions and early measurements support estimates. | Public commitments. |
| Platform stack and integrations | Undecided; plain-text submission first. | Detailed implementation planning. |

These choices do not block the next curriculum-architecture draft. They should be recorded with owners and validation plans rather than silently decided by tooling or implementation convenience.

## Validation Performed and Limits

The revised Markdown was parsed and structurally checked for all 27 domains, 206 unique practical IDs, preservation of all 201 original IDs and P targets, 12 awareness-topic IDs, depth coverage, six critical rules, eleven gates, help and difficulty scales, ID references, table structure, and version metadata. Legacy assistance codes remain only in the explicit migration note. The old DOCX conversion path now refuses to overwrite the canonical Markdown.

This review did not build a syllabus, author the representative lessons, test learners, calibrate assessors, run labs, establish accessibility or legal conformance, implement the app, purchase infrastructure, or prove hiring readiness. Those are future deliverables and validation activities, not completed work hidden behind the word “plan.”

**Next deliverable: Curriculum Architecture v1, accompanied by the initial risk and assessment experiment plan.**
