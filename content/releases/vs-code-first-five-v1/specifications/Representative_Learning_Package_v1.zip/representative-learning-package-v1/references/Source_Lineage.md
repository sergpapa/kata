# Source lineage

The included Markdown files are unchanged snapshots of the conversation's reviewed planning artifacts:

- [Graduate_Competency_Standard_v1.md](Graduate_Competency_Standard_v1.md) is internally **v1.1**, evidence semantic schema 2.0. Its filename is retained from the original artifact; the front matter identifies its actual version.
- [Curriculum_Architecture_v1.md](Curriculum_Architecture_v1.md) is v1.0 and defines the 68-module map and initial learning slices.
- [Plan_Review_and_Next_Steps.md](Plan_Review_and_Next_Steps.md) records the preceding plan review.

Historical statements such as “ready to author” describe those documents' release state. This learning package records the subsequent implementation and its current verification limits. It does not silently edit source-standard graduation rules, parent targets, or the curriculum's other unimplemented modules.

Exact source hashes and the 24 child-indicator mappings are in [package-index.json](../metadata/package-index.json). The source standard hash is `501145c310956a46319d27649840c0e4bdf501e6a2ddd684422da51a335d78ca`. Reconcile any future source change explicitly before applying this package to a different standard/curriculum release.

Protocol/runtime sources used for this unit are linked near the supported statements in [Environment_and_Contract.md](../Environment_and_Contract.md) and the operational probe. Most lesson examples and results are original explanations of the course-owned source and its local experiments. No externally hosted learner code or private repository is included.
