---
document_id: HINT-HTTP-001
version: "1.0.0"
---

# Help for the HTTP investigations

Open the level that makes your next step useful; there is no required wait. These static sections are visible in the file, so reading ahead can reveal more help than intended. Record the actual information received, not just the link you meant to open. The lesson's taught concepts and ordinary documentation remain available at H0; a solution-specific diagnosis from any source has stronger help semantics.

For EX-HTTP-01 to 12, ask for the needed conceptual explanation or consult the keyed answers in the [walkthrough](../instructor/Walkthroughs.md). A full answer to a prediction already made can support reflection; copying it before the prediction changes the evidence claim. For testing/review exercises, the same rule applies to generated tests and supplied arguments.

## Main investigation: EX-HTTP-13 to 18

| Level | Help disclosed | Affected evidence |
| --- | --- | --- |
| H1 | Compare what a request asks the server to do with the content the client ultimately displays. | Investigation direction |
| H2 | Focus on the inputs to the conditional-response decision, keeping current data constant during the comparison. | Subsystem and concept |
| H3 | Save a first body/tag, change only the notice body, then compare unconditional GET with GET carrying the saved tag. Trace current body and tag at the origin. | Discriminating diagnostic |
| H4 | The starter's tag is derived only from resource ID. That value cannot distinguish changed content. Make the tag follow the selected representation through title and body edits while remaining stable for unchanged content. | Decisive diagnosis and partial solution |
| H5 | Read the complete main diagnosis and either alternative implementation in the walkthrough and `instructor/solutions/`. | Full solution exposure |

H4 can be decisive even without code. Do not report it as merely directional help. After H5, explain the repair, test it, and use a fresh task to evaluate independent diagnosis later.

## Transfer investigation: EX-HTTP-22 to 24

| Level | Help disclosed | Affected evidence |
| --- | --- | --- |
| H1 | Repeat the experiment with request order reversed and clean state between comparisons. | Investigation direction |
| H2 | Distinguish the server's stored computation from the client's stored HTTP response. | Subsystem and concept |
| H3 | Record the selected body before tag creation for summary-then-full and full-then-summary. Compare the inputs used to retrieve any remembered representation. | Discriminating diagnostic |
| H4 | The memo key includes ID/revision but omits the selected view. A correct hash of the body cannot repair a body selected from the wrong memo entry. Include the selection input or remove that memoization. | Decisive diagnosis and partial solution |
| H5 | Read the full transfer explanation and the keyed/direct alternative implementations. | Full solution exposure |

## Heroic investigation

H1: enumerate all inputs that determine returned content. H2: consider renderer changes separately from data changes. H3: hold the record constant and serialize it with two implementations, then compare bytes and proposed tags. H4: a record-only version can collide across renderer revisions; a representation-derived tag or complete version scheme must account for that boundary. H5: read the [Heroic discussion](../instructor/Walkthroughs.md#optional-heroic-discussion).

If you are blocked by setup, an inaccessible tool, or unfamiliar vocabulary, request access/concept support immediately. Do not silently classify unrelated assistance as a failure of HTTP reasoning.
