---
document_id: QA-RLP-001
version: "1.0.0"
date: 2026-09-10
status: "Author verification with explicit environment limits; no learner or independent calibration results"
---

# Verification report

This report distinguishes authored material, executed author checks, and remaining release gates. All executed code was course-owned source and synthetic fixtures. No learner submission was executed or externally transmitted.

## Executed author checks

| Check | Actual result | Scope |
| --- | --- | --- |
| Runtime preflight | Node 24.19.0, Linux x64; Git 2.51.1; curl 8.5.0 available | This author environment only |
| Support and author release suite | **14 tests passed, 0 failed** | Includes parser/fixture boundaries, expected faults, alternative repairs, shortcut rejection and beginner cases |
| Main starter | HC04, HC05, HC14 fail as intended; other 14 of 17 common cases pass | Confirms changed-content defect without inventing unrelated faults |
| Transfer starter | TX01, TX02, TX03 fail as intended; 19 of 22 cases pass | Confirms both request-order defects and cross-view validation failure |
| Two main reference repairs | Each passes all 17 common cases | Exact-body hash and controlled record revision both accepted |
| Two transfer reference repairs | Each passes all 22 cases | Complete memo key and direct selection both accepted |
| Main hash copied into transfer | The same three transfer cases still fail | The transfer requires a different decision from repeating the first patch |
| Shortcut counterexamples | Checks reject always-200, always-304, no-store, unstable tags, and title-only tags | Protects required behavior, not reference-diff conformity |
| Actual terminal/curl rehearsal | Three main reset/re-entry cycles reproduce the stale conditional response; unconditional curl sees changed data | Separate started server, CLI client, fixture edits, real loopback HTTP |
| Main repaired terminal cycle | Wire statuses 200, 304, 200 after change, then 304 | Confirms changed content followed by valid unchanged reuse |
| Transfer terminal cycle | Both request orders reproduce wrong shapes; keyed repair returns distinct correct views | Includes process restart/reset between original orders |
| Reset scope | Restored revision 1, removed named terminal cache, preserved source and investigation note in all three main cycles | Browser and Docker state excluded from this check |
| Submission workflow | Preview and local packet write succeed with 12 approved files; instructor solutions excluded | Local collection only; no upload service or server-side ingestion exists |
| Beginner source and CLI | Ordinary/boundary cases checked; wrong-directory command fails; corrected relative path succeeds | Tests the deliberate boundary and path faults |
| Calibration source integrity | 30 unique module texts pass syntax checks; all eight valid-alternative cases pass their applicable 17/22 behavior cases | Source behavior verification, not independent educational adjudication |
| Case inventory | 40 unique IDs; five strata of eight; each split into four development/four reserved candidates | Labels remain author drafts and exposed candidates are not held-out |

`node --test test/support.test.mjs instructor/release.test.mjs` reproduces the core author suite on the **pristine package**. `node tools/check.mjs main` and `node tools/check.mjs transfer` intentionally return a failing exit code until their respective starter is repaired. `test/learner-regression.test.mjs` contains explicit TODOs; the author did not count them as learner work completed.

The accompanying [CLI observations](cli-observations.json) and [case-source checks](case-source-checks.json) are structured summaries captured by the actual author rehearsal. They are not learner evidence and are not presented as independent human observation. See [content checks](content-checks.json) for the final link, inventory, syntax and configuration-inspection record. Checksums identify the released bytes; they do not attest authorship or competence.

## Not executed or not established

| Area | Current limitation | Required next verification |
| --- | --- | --- |
| Browser caching/viewer behavior | Playwright library is installed, but its Chromium/Firefox binaries are absent. Launch attempts failed before any page interaction | Run the documented browser/terminal comparison on an installed supported browser; record actual Network versus page status and settings |
| Viewer accessibility | Semantic labels, native controls, status text, focus styling and plain-text alternatives are authored; no browser keyboard/zoom or screen-reader session completed | Manual keyboard/zoom, assistive-technology and full-task access rehearsal; fix essential obstacles |
| Docker/Compose probe | Docker executable unavailable; YAML/source inspection does not verify runtime interpretation or isolation | Pin reviewed image digest and execute main/transfer, effective configuration/resource checks, and three cleanup/reset cycles |
| Image/runtime reproducibility | HTTP targets Node 24.x with exact tested patch recorded; Docker tag is mutable and unpinned | Record each release environment and image digest before advertising that path |
| Windows/macOS/other browsers | No rehearsal performed | Test the complete essential procedure, including shell quoting and recovery, before a supported-path claim |
| Review calibration | Forty cases exist with draft judgments; no independent annotation/adjudication or model evaluation | Execute EX04 with genuinely held-out cases and qualified reviewers |
| Learner effectiveness and duration | No learner trial, delayed transfer, workload or cost measurement | Execute EX02/EX03 after technical/access gates; retain uncertainty about overall program outcomes |
| Application systems | No submission backend, automated assessment, progression, extension, MCP, credential system or app UX trial implemented | Write the app requirements/experience specification and implement/test its boundaries separately |

## Disposition

**Authored reference package available for review.** Local Node/server/terminal checks support the bounded technical claims above. Browser/access rehearsal and independent technical/editorial review remain before a facilitated HTTP learner pilot. The operational probe is blocked for learner release until its Docker gate is complete. Remaining curriculum modules and the app are still future work. These limits are part of the release, not results to fill with assumed successes.
