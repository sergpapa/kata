import {runContract} from '../test/contract-cases.mjs';
import {checkScenario} from '../lab/lib/state.mjs';
try {
  const scenario = checkScenario(process.argv[2] ?? 'main');
  const outcomes = await runContract(scenario);
  const report = {scenario, source: 'Current local learner files', kind: 'learner-run-contract-check',
    passed: outcomes.filter(x => x.passed).length, total: outcomes.length, outcomes};
  if (process.argv.includes('--json')) console.log(JSON.stringify(report, null, 2));
  else {
    for (const item of outcomes) console.log(`${item.passed ? 'PASS' : 'FAIL'} ${item.id} ${item.name}${item.passed ? '' : `\n  ${item.message}`}`);
    console.log(`${report.passed}/${report.total} passed. A starter failure is intentional; investigate it before editing.`);
    console.log('These checks run supplied course code and your local repair on your machine. Their output is not independent proof of competence.');
  }
  process.exitCode = report.passed === report.total ? 0 : 1;
} catch (error) { console.error(error.message); process.exitCode = 1; }
