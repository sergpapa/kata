import {createScenario} from '../lab/lib/scenario.mjs';
import {ensureState, checkScenario} from '../lab/lib/state.mjs';
const scenario = checkScenario(process.argv[2] ?? 'main');
const port = Number(process.argv[3] ?? (scenario === 'main' ? 4310 : 4311));
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Port must be an integer from 1 to 65535');
ensureState(scenario);
const logger = entry => console.log(JSON.stringify(entry));
const server = await createScenario(scenario, {logger});
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE' ? `Port ${port} is occupied. Stop your other lab process or choose another port.` : error.message);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log(`Open http://127.0.0.1:${port}/ for the ${scenario} lab. Stop with Ctrl+C.`);
  logger({event: 'optional_feature', level: 'warn', detail: 'External telemetry export is disabled for this local lab.'});
});
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => {
  server.close();
  server.closeAllConnections();
});
