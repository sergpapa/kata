import {rmSync, readdirSync, existsSync} from 'node:fs';
import {join} from 'node:path';
import {root, checkScenario, seedState, saveState, ensureState, readState, setField} from '../lab/lib/state.mjs';
const [command, inputScenario = 'main', id, field, value] = process.argv.slice(2);
const scenario = checkScenario(inputScenario);
if (command === 'reset') {
  saveState(scenario, seedState());
  const directory = join(root, '.work');
  if (existsSync(directory)) for (const name of readdirSync(directory)) {
    if (new RegExp(`^client-${scenario}-(full|summary)\\.json$`).test(name)) rmSync(join(directory, name));
  }
  console.log(`Reset only ${scenario} fixture data and its terminal-client cache. Source edits are unchanged.`);
  console.log('Restart that server to clear process-local caches. Close its browser tabs or clear site data for a fully fresh observation.');
} else if (command === 'show') {
  ensureState(scenario);
  console.log(JSON.stringify(readState(scenario), null, 2));
} else if (command === 'set') {
  ensureState(scenario);
  const next = setField(readState(scenario), id, field, value);
  saveState(scenario, next);
  console.log(`Saved ${id}.${field}; revision ${next.bulletins[id].revision}. No server restart is required for a data change.`);
} else {
  throw new Error('Use: node tools/fixture.mjs reset|show main|transfer OR set main|transfer notice|meeting title|body "text"');
}
