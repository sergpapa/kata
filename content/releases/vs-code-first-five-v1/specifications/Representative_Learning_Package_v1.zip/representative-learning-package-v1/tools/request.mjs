import http from 'node:http';
import {readFileSync, writeFileSync, existsSync, mkdirSync} from 'node:fs';
import {join} from 'node:path';
import {root, checkScenario} from '../lab/lib/state.mjs';

const [inputScenario = 'main', action = 'get', view = 'full', portInput] = process.argv.slice(2);
const scenario = checkScenario(inputScenario);
if (!['get', 'revalidate'].includes(action) || !['full', 'summary'].includes(view) || (scenario === 'main' && view !== 'full')) {
  throw new Error('Use: node tools/request.mjs main|transfer get|revalidate full|summary [port]');
}
const port = Number(portInput ?? (scenario === 'main' ? 4310 : 4311));
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid port');
const path = '/api/bulletins/notice';
const cacheFile = join(root, '.work', `client-${scenario}-${view}.json`);
let previous = existsSync(cacheFile) ? JSON.parse(readFileSync(cacheFile, 'utf8')) : null;
if (previous && previous.port !== port) previous = null;
const headers = scenario === 'transfer' ? {'X-Bulletin-View': view} : {};
if (action === 'revalidate') {
  if (!previous?.etag) throw new Error('First run get for this scenario/view/port to save a response');
  headers['If-None-Match'] = previous.etag;
}
console.log(JSON.stringify({event: 'request', method: 'GET', host: '127.0.0.1', port, path, headers}));
await new Promise((resolve, reject) => {
  const request = http.get({hostname: '127.0.0.1', port, path, headers, agent: false}, response => {
    const chunks = [];
    response.on('data', chunk => chunks.push(chunk));
    response.on('end', () => {
      const body = Buffer.concat(chunks).toString('utf8');
      const selectedBody = response.statusCode === 304 ? previous?.body : body;
      console.log(JSON.stringify({event: 'response', status: response.statusCode, headers: response.headers, wireBodyBytes: Buffer.byteLength(body), wireBody: body}));
      console.log(JSON.stringify({event: 'client_selected_body', source: response.statusCode === 304 ? 'stored response' : 'response body', body: selectedBody}));
      if (response.statusCode === 200 && response.headers.etag) {
        mkdirSync(join(root, '.work'), {recursive: true});
        writeFileSync(cacheFile, JSON.stringify({port, path, view, etag: response.headers.etag, body}, null, 2) + '\n');
      }
      if (response.statusCode >= 400) process.exitCode = 1;
      resolve();
    });
    response.on('error', reject);
  });
  request.setTimeout(5000, () => request.destroy(new Error('Local request timed out')));
  request.on('error', reject);
});
