import {spawnSync} from 'node:child_process';
import {accessSync, constants, existsSync} from 'node:fs';
import {root} from '../lab/lib/state.mjs';
const major = Number(process.versions.node.split('.')[0]);
console.log(`Node ${process.versions.node}; ${process.platform}/${process.arch}`);
console.log(`Working package: ${root}`);
let failed = false;
if (major !== 24) { console.error('This release targets Node 24.x. Other major versions are not part of its tested contract.'); failed = true; }
try { accessSync(root, constants.W_OK); } catch { console.error('The extracted package is not writable. Move it to your own project directory.'); failed = true; }
for (const command of ['git', 'curl']) {
  const result = spawnSync(command, ['--version'], {encoding: 'utf8', timeout: 5000});
  console.log(result.status === 0 ? result.stdout.split(/\r?\n/)[0] : `${command} was not found; install it through your approved environment setup.`);
  if (result.status !== 0) failed = true;
}
console.log('HTTP lab: no npm install, Docker, external API, or cloud account is required.');
console.log(existsSync(new URL('../.work', import.meta.url)) ? 'Existing local state detected; use reset only when you intend to restart the scenario.' : 'No previous local lab state.');
process.exitCode = failed ? 1 : 0;
