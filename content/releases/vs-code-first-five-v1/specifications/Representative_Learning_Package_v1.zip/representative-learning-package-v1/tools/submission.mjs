// Local preview/collection only. There is no upload, subprocess, or assessment call.
import {lstatSync, readFileSync, realpathSync, mkdirSync, writeFileSync} from 'node:fs';
import {join, relative, sep} from 'node:path';
import {createHash} from 'node:crypto';
import {root, checkScenario} from '../lab/lib/state.mjs';

try {
  const scenario = checkScenario(process.argv[2] ?? 'main');
  const permitted = [
    'package.json', `lab/${scenario}/representation.mjs`, `lab/${scenario}/validator.mjs`,
    'lab/lib/app.mjs', 'lab/lib/conditional.mjs', 'lab/lib/scenario.mjs', 'lab/lib/state.mjs',
    'fixtures/bulletins.json', 'test/harness.mjs', 'test/contract-cases.mjs',
    'test/learner-regression.test.mjs', 'learner/Investigation.md'
  ];
  const files = [];
  let total = 0;
  const rootReal = realpathSync(root);
  for (const path of permitted) {
    const absolute = join(root, path);
    const stat = lstatSync(absolute);
    const resolved = realpathSync(absolute);
    const relation = relative(rootReal, resolved);
    if (!stat.isFile() || stat.isSymbolicLink() || relation === '..' || relation.startsWith(`..${sep}`)) {
      throw new Error(`Refusing an indirect or non-file source: ${path}`);
    }
    if (stat.size > 131072) throw new Error(`File exceeds 128 KiB: ${path}`);
    const bytes = readFileSync(absolute);
    total += bytes.length;
    if (total > 1048576 || bytes.includes(0)) throw new Error('Packet exceeds 1 MiB or contains non-text content');
    files.push({path, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex'),
      content: bytes.toString('utf8')});
  }
  const packet = {
    packet_schema_version: '1.0', evidence_schema_reference: '2.0',
    package_version: '1.0.0', slice: 'SL-HTTP', scenario,
    collected_at: new Date().toISOString(),
    provenance: 'Local collection supplied by the learner; hashes identify bytes and do not attest authorship or execution.',
    excluded: ['Git history/baseline (supply separately)', 'runtime state', 'raw run reports (select separately)',
      'instructor solutions', 'unrelated workspace files'],
    unresolved: ['Review the note for accidental private text.', 'Identify baseline and final commit/diff.',
      'Attach chosen raw observations with environment and help records.'], files
  };
  console.log(JSON.stringify({scenario, files: files.map(({content, ...entry}) => entry), totalBytes: total,
    unresolved: packet.unresolved}, null, 2));
  if (process.argv.includes('--write')) {
    const directory = join(root, '.work'); mkdirSync(directory, {recursive: true});
    const destination = join(directory, `submission-${scenario}-${Date.now()}.json`);
    writeFileSync(destination, JSON.stringify(packet, null, 2) + '\n', {flag: 'wx', mode: 0o600});
    console.log(`Local packet written: ${destination}`);
    console.log('Open and inspect the entire packet before choosing to share it. Nothing was uploaded.');
  } else console.log('Preview only. To write a local packet after inspection, add --write. Nothing was uploaded.');
} catch (error) { console.error(error.message); process.exitCode = 1; }
