const form = document.querySelector('#request-form');
const status = document.querySelector('#status');
const metadata = document.querySelector('#metadata');
const body = document.querySelector('#body');
const controls = [...form.querySelectorAll('button, select')];
let scenario;
try {
  ({scenario} = await (await fetch('/lab-info', {cache: 'no-store'})).json());
  document.querySelector('#view-field').hidden = scenario !== 'transfer';
} catch {
  status.textContent = 'Could not read lab information. Check that the server is running and reload.';
  for (const control of controls) control.disabled = true;
}
async function load(cache = 'default') {
  for (const control of controls) control.disabled = true;
  status.textContent = 'Loading bulletin…';
  try {
    const path = `/api/bulletins/${document.querySelector('#bulletin').value}`;
    const headers = scenario === 'transfer' ? {'X-Bulletin-View': document.querySelector('#view').value} : {};
    const response = await fetch(path, {cache, headers});
    const text = await response.text();
    metadata.textContent = JSON.stringify({path, requestCacheMode: cache, requestHeaders: headers,
      pageResponseStatus: response.status, etag: response.headers.get('etag'),
      cacheControl: response.headers.get('cache-control'), vary: response.headers.get('vary')}, null, 2);
    body.textContent = text || '(empty body)';
    status.textContent = response.ok ? 'Bulletin loaded. Compare the request evidence.' : `Request returned status ${response.status}.`;
  } catch (error) {
    metadata.textContent = 'No HTTP response was available to the page.';
    body.textContent = '';
    status.textContent = `Request failed: ${error.message}. Check the server and Network panel.`;
  } finally {
    for (const control of controls) control.disabled = false;
  }
}
form.addEventListener('submit', event => { event.preventDefault(); void load(); });
document.querySelector('#bypass').addEventListener('click', () => { void load('no-store'); });
