const representations = new Map();

export function selectRepresentation(record, view) {
  const key = `${record.id}:${record.revision}`;
  if (representations.has(key)) return representations.get(key);

  const value = view === 'summary'
    ? {id: record.id, title: record.title}
    : {id: record.id, title: record.title, body: record.body};
  const body = JSON.stringify(value) + '\n';
  if (representations.size >= 64) representations.clear();
  representations.set(key, body);
  return body;
}

export function resetRepresentationCache() { representations.clear(); }
