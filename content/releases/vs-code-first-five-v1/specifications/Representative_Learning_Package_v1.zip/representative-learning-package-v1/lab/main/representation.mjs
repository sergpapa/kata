export function selectRepresentation(record) {
  return JSON.stringify({id: record.id, title: record.title, body: record.body}) + '\n';
}
