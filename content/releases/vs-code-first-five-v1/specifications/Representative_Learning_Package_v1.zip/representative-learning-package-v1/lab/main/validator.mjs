export function makeValidator({record}) {
  return `"${record.id}"`;
}
