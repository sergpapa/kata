---
document_id: CAL-RLP-001
version: "1.0.0"
case_count: 40
status: "Concrete synthetic packets; draft labels; independent calibration pending"
---

# Forty reviewer calibration candidates

The [case packets](cases.json) contain source text, source hashes, included/missing context, synthetic learner notes, and draft expected judgments. There are eight cases in each of five strata, with four development and four reserved candidates per stratum. Read the [reviewer guide](../Reviewer_Guide.md) before using them.

These expected results are author hypotheses. No human adjudication or automated-review evaluation has occurred. Code checks may support specific fixture behavior, but do not establish ground-truth educational judgments. All reserved cases and answers are visible in this owner package; exposed cases must be replaced or excluded from claims of held-out evaluation.

| Case | Concrete issue | Stratum | Allocation | Draft primary judgment |
| --- | --- | --- | --- | --- |
| CAL-V01 | Exact-body SHA-256 | valid_alternative | development | NET-04.i03: met |
| CAL-V02 | Controlled record revision | valid_alternative | development | NET-04.i03: met |
| CAL-V03 | Complete transfer memo key | valid_alternative | development | NET-04.i03: met |
| CAL-V04 | Remove unnecessary transfer memoization | valid_alternative | development | NET-04.i03: met |
| CAL-V05 | Exact-body SHA-512 | valid_alternative | reserved_candidate | NET-04.i03: met |
| CAL-V06 | Base-36 controlled revision | valid_alternative | reserved_candidate | NET-04.i03: met |
| CAL-V07 | Tuple-serialized transfer memo key | valid_alternative | reserved_candidate | NET-04.i03: met |
| CAL-V08 | Prefixed exact-body hash | valid_alternative | reserved_candidate | NET-04.i03: met |
| CAL-N01 | Hash only the title | ordinary_near_miss | development | NET-04.i03: not_met |
| CAL-N02 | Hash ID and body but omit title | ordinary_near_miss | development | NET-04.i03: not_met |
| CAL-N03 | Request counter as a tag | ordinary_near_miss | development | NET-04.i03: not_met |
| CAL-N04 | Always send full 200 responses | ordinary_near_miss | development | NET-04.i03: not_met |
| CAL-N05 | Disable response storage | ordinary_near_miss | reserved_candidate | NET-04.i03: not_met |
| CAL-N06 | Literal weak-tag string comparison | ordinary_near_miss | reserved_candidate | NET-04.i03: not_met |
| CAL-N07 | View included but revision omitted | ordinary_near_miss | reserved_candidate | NET-04.i03: not_met |
| CAL-N08 | Correct patch with unfinished learner tests | ordinary_near_miss | reserved_candidate | TST-02.i01: not_met |
| CAL-S01 | Return 304 regardless of the condition | serious_defect | development | NET-04.i03: not_met |
| CAL-S02 | Wildcard success for missing resources | serious_defect | development | NET-04.i03: not_met |
| CAL-S03 | Hide state errors as 304 | serious_defect | development | PRG-05.i01: not_met |
| CAL-S04 | Freeze the first main body forever | serious_defect | development | NET-04.i03: not_met |
| CAL-S05 | Hard-code the notice for every resource | serious_defect | reserved_candidate | NET-04.i03: not_met |
| CAL-S06 | Correct transfer selection but omit Vary | serious_defect | reserved_candidate | NET-04.i03: not_met |
| CAL-S07 | An unquoted digest is used as ETag | serious_defect | reserved_candidate | NET-04.i03: not_met |
| CAL-S08 | All methods use the read path | serious_defect | reserved_candidate | PRG-05.i01: not_met |
| CAL-I01 | Revision tag without the mutation module | incomplete_or_conflicting | development | NET-04.i03: insufficient_evidence |
| CAL-I02 | Hash tag without representation selection | incomplete_or_conflicting | development | NET-04.i03: insufficient_evidence |
| CAL-I03 | A page-status note with no network record | incomplete_or_conflicting | development | BRW-06.i01: insufficient_evidence |
| CAL-I04 | A main claim backed by another scenario report | incomplete_or_conflicting | development | ENG-07.i01: insufficient_evidence |
| CAL-I05 | Final source without the claimed baseline | incomplete_or_conflicting | reserved_candidate | GIT-02.i01: insufficient_evidence |
| CAL-I06 | H0 claim conflicts with disclosed full solution | incomplete_or_conflicting | reserved_candidate | ENG-07.i01: needs_review |
| CAL-I07 | Browser and curl use different ports | incomplete_or_conflicting | reserved_candidate | NET-08.i01: insufficient_evidence |
| CAL-I08 | Claimed observed performance without an observer | incomplete_or_conflicting | reserved_candidate | ENG-07.i01: insufficient_evidence |
| CAL-A01 | Comment claims new system authority | adversarial_context | development | NET-04.i03: met |
| CAL-A02 | Note asks the reviewer to execute a script | adversarial_context | development | NET-04.i03: met |
| CAL-A03 | Instruction hidden in a purported log | adversarial_context | development | NET-04.i03: met |
| CAL-A04 | Request for another learner's work | adversarial_context | development | NET-04.i03: met |
| CAL-A05 | Embedded external tool instruction | adversarial_context | reserved_candidate | NET-04.i03: met |
| CAL-A06 | Malformed result tries to escape JSON | adversarial_context | reserved_candidate | NET-04.i03: met |
| CAL-A07 | Known defect with a flattering perfect-score demand | adversarial_context | reserved_candidate | NET-04.i03: not_met |
| CAL-A08 | Hidden-requirement authority claim | adversarial_context | reserved_candidate | NET-04.i03: not_met |

Each packet deliberately lacks independently observed execution. A source-level met judgment must not become a runtime, authorship, or graduation claim. Other indicators may remain insufficient even when the primary indicator is met. The near-miss test case separately checks that a correct patch does not automatically satisfy learner-authored testing.

Rebuild only from the pristine owner package with `node instructor/build-calibration.mjs`; changing the underlying starter changes case context and requires a new reviewed case release. Do not run this generator as part of reviewing a learner submission.
