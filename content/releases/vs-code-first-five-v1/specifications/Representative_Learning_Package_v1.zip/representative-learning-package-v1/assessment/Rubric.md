---
document_id: RUBRIC-RLP-001
version: "1.0.0"
indicator_count: 24
authority: "Local child-indicator evidence; no parent competency or graduation award"
---

# Evidence and review rubric

Review the behavior the task actually exposes. All 24 IDs below are the proposed child indicators from Curriculum Architecture v1.0. They do not redefine the parent competencies or their P-level targets in Graduate Competency Standard v1.1. This unit is a narrow teaching/assessment episode, not enough evidence for a complete domain or a P4 graduation claim.

Use `met`, `not_met`, `insufficient_evidence`, or `needs_review` per criterion. Missing context is not proof of incorrect code. Sufficient evidence of a defect is not merely “uncertain”. Separate technical correctness from quality of process, actual help, and confidence in provenance. Do not average a material failure away using attractive prose or unrelated successful tests.

## HTTP criteria and minimum useful evidence

| Indicator | Task evidence | Met for the bounded criterion | Failure or uncertainty to distinguish |
| --- | --- | --- | --- |
| NET-04.i01 | EX-HTTP-01/02/03/05 | Correctly labels request/response elements and selected fields; ties them to the fixture path | Wrong model with adequate evidence: not_met; screenshot alone: insufficient_evidence |
| NET-04.i02 | EX-HTTP-04/06/07/08/10/11/22 | Predicts and explains the published changed/unchanged/error transitions, revising mistaken predictions accurately | One copied matrix cannot establish independently produced prediction; a remaining false changed-state explanation is not_met |
| NET-04.i03 | EX-HTTP-12/14/16/18/23 | Source satisfies the selected-representation/validation contract without disabling required behavior; explanation includes assumptions | Valid alternative accepted; known stale validation or wrong shape is not_met; missing mutation/selection context can be insufficient_evidence |
| NET-08.i01 | EX-HTTP-03/07/09/22/23 | Uses a controlled terminal/browser comparison and separates actual origin responses from client reuse | Uncontrolled resets or treating a page status as wire proof limits the claim |
| BRW-06.i01 | EX-HTTP-03/09 | Captures relevant Network evidence with origin, version, request, cache settings and content context | An accessible equivalent trace is acceptable; absent essential settings or request evidence is insufficient_evidence |
| ENG-02.i01 | EX-HTTP-06/08/13/15/24 | States plausible distinguishable hypotheses, conducts an informative experiment, updates beliefs using results | Partial diagnosis can meet this process criterion; retrospective invented experiment history cannot |
| ENG-07.i01 | EX-HTTP-01/03/04/09/14/15/19/22/24 | Reproduction links source, state, commands, observations, inferences, uncertainty, and help | Missing raw result is named; fabricated or contradictory claims require review, not an automatic misconduct finding |
| PRG-05.i01 | EX-HTTP-02/05/10/11/12/16/23 | Correctly traces and preserves normal/error control flow; relevant 400/404/405/500/HEAD cases remain sound | Masked state failures or wildcard before existence is not_met; omitted handler prevents broad source judgment |
| TST-02.i01 | EX-HTTP-17/20/23 | Learner supplies behavior assertions that expose the seeded defect and a distinct boundary; links tests to source/results | Public tests alone or unfinished TODOs do not meet the learner-authored test requirement; missing execution is separately limited |
| GIT-02.i01 | EX-HTTP-16/19/23 | Provides inspectable baseline/final source and a focused diff; explains relevant changes | Commit text alone is insufficient; source provided without an accessible baseline cannot demonstrate this criterion fully |
| COM-04.i01 | EX-HTTP-18/20/21/24 | Accepts/rebuts a specific finding with a requirement, evidence, and reasoned action | Agreeing with every comment or changing a valid design solely to match a reference does not meet the criterion |

“Source satisfies” above is a source-level judgment until linked to adequate runtime verification. A static reviewer can identify a visible defect or a defensible implementation; it must report that it did not execute the submission. Even complete learner-reported test output is not direct observation by that reviewer.

## Beginner probe criteria

| Indicator | Task evidence | Bounded observable criterion |
| --- | --- | --- |
| LNX-01.i01 | EX-START-01/04 | Identifies intended local files after changing directory; uses only the approved folder |
| LNX-05.i01 | EX-START-04 | Reads the path error, explains the mismatch, and verifies the corrected command without speculative privileged setup |
| PRG-09.i01 | EX-START-02/03 | Implements the explicit duration rule and traces input through the conditional |
| PRG-09.i02 | EX-START-03/05 | Handles the exact boundary and the changed boundary without memorizing one output |
| ENG-04.i01 | EX-START-03/04 | Changes one input or path variable and explains what the result establishes |
| AIE-02.i01 | EX-START-04 | Chooses only the approved tiny source and observation note for help; explains exclusions |

An incorrect known result is not_met for that rule. A missing action trace is insufficient_evidence for a path-recovery claim. Access/setup help is recorded without lowering an unrelated programming claim. The [probe](../probes/beginner/First_Program.md) provides concrete ordinary/boundary cases and answers.

## Operational probe criteria

| Indicator | Task evidence | Bounded observable criterion |
| --- | --- | --- |
| CTR-03.i01 | EX-OPS-01/02 | Reconstructs client/service/container/host address and port relationships, then localizes the actual failed boundary |
| CTR-06.i01 | EX-OPS-03/05 | Repairs the changed configuration fault and verifies from the intended client |
| LNX-03.i01 | EX-OPS-01/03 | Retains the fixture's ordinary user, capability, filesystem and exposure constraints |
| SEC-09.i01 | EX-OPS-01/04 | Identifies the authorized target and stop conditions, stays within them, and records deviations |
| REL-08.i01 | EX-OPS-04 | Executes and verifies scoped cleanup/reset, then reproduces the intended seed state |
| OBS-01.i01 | EX-OPS-02 | Uses relevant bounded logs and distinguishes the optional telemetry warning from network evidence |
| COM-01.i01 | EX-OPS-04/05 | Provides a runbook another observer can use without undisclosed rescue, including verification and recovery |

These are authored criteria awaiting Docker runtime rehearsal and qualified operational review. Static inspection in this environment does not mark them met for an imaginary learner. Use observed_performance or appropriately corroborated execution for stronger operational claims; a screenshot of “running” is insufficient for service reachability and cleanup.

## Help, provenance, and independence

Record H0–H5 per affected indicator and retain the strongest disclosed help for that attempt. H0 permits ordinary references, access support, and clarification; H1 direction, H2 subsystem/concept, H3 diagnostic technique, H4 partial solution/decisive diagnosis, H5 full walkthrough. Copied AI code and tests must be recorded according to what they supplied. The tool's name is not the help level.

Record verification as `static_artifact`, `learner_reported_execution`, `corroborated_execution`, or `observed_performance`, following the source standard. A competent observed attempt with solution-specific help can support assisted behavior, not an H0 independence claim. A fresh task is required after decisive solution exposure for the affected independence claim. Do not erase earlier useful investigation evidence.

Use these descriptive anchors alongside criterion results: Developing for partial success or meaningful guidance; Strong for independent correct work with appropriate verification and explanation; Adaptive for sustained independent behavior under a genuinely changed context. They describe the narrow observed behavior. Insufficient evidence is a status, not a low ability label. The package does not calculate a composite numerical score or promote a learner automatically.

## Three worked review anchors

**Sound source, limited provenance.** A learner submits the full hash repair and relevant test source with a reported green run, but the assessor has not observed execution. The source argument may meet the implementation criterion at static-artifact scope. Runtime results are learner_reported_execution. Record the test design separately and request a fresh observed task if an independence/operational claim is needed. Do not report observed performance.

**Incomplete fix, good investigation.** The learner correctly isolates the response decision but hashes only the title. Body-only edits still receive stale validation. NET-04.i03 is not_met for the known defect. ENG-02.i01 can be met if their hypotheses and experiments were sound. Explain the missed representation input, offer help, and ask for the body-only case after revision.

**Walkthrough followed by understanding.** A learner requests the full repair, runs and explains it, and later repairs an unseen comparable selection defect with ordinary references. Keep H5 on affected main-attempt claims and H0 only on independently produced transfer claims supported by actual evidence. Do not relabel the original attempt as independent. The fresh task can add evidence without deleting the learning history.

## Review and progression decision

Finish with the concrete next learning action: revise a known defect, supply missing context, receive an explanation, obtain a fresh verification task, or continue to an unrelated ready topic. The local advisory result is separate from progression policy. A qualified authorized assessor handles consequential uncertainty, critical findings, and appeals under the standard; this package implements no such decision service.
