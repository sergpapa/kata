import { createHash } from 'node:crypto';

export function makeRepresentation(state, view) {
  const value = view === 'short'
    ? { closingTime: state.closingTime }
    : { title: 'Cafe notice', message: `Today we close at ${state.closingTime}.` };
  const body = JSON.stringify(value, null, 2) + '\n';
  const etag = '"' + createHash('sha256').update(body).digest('hex') + '"';
  return { body, etag };
}

export function cachePolicy(state) {
  if (state.policy === 'fresh') return 'private, max-age=300, must-revalidate';
  if (state.policy === 'validate') return 'private, no-cache';
  if (state.policy === 'no-store') return 'no-store';
  throw new Error('Unknown lab policy');
}
