import { createServer } from 'node:http';
import { handleRequest } from './handler.mjs';

const rawPort = process.argv[2] ?? '4319';
const port = Number(rawPort);
if (process.argv.length > 3 || !/^\d+$/.test(rawPort) || port < 1024 || port > 65535) {
  console.error('Choose one whole-number port from 1024 to 65535. Example: node server.mjs 4320');
  process.exitCode = 1;
} else {
  let count = 0;
  const server = createServer((request, response) => {
    const id = ++count;
    response.on('finish', () => console.log(JSON.stringify({ request: id, method: request.method, target: request.url, ifNoneMatch: request.headers['if-none-match'] ?? null, status: response.statusCode })));
    try { handleRequest(request, response); }
    catch (error) {
      console.error(`Lab handler error: ${error.name}. Check data/cafe.json or restore baseline.`);
      if (response.headersSent) response.destroy();
      else {
        response.writeHead(500, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' });
        response.end('The lab could not build its response. Check the server terminal.\n');
      }
    }
  });
  server.on('error', (error) => {
    console.error(error.code === 'EADDRINUSE' ? `Port ${port} is occupied. Stop your recognized lab or use 4320.` : `Startup failed: ${error.code ?? error.name}`);
    process.exitCode = 1;
  });
  server.listen(port, '127.0.0.1', () => {
    console.log(`Caching lab is listening on http://127.0.0.1:${port}`);
    console.log(`Data: ${new URL('./data/cafe.json', import.meta.url).href}`);
    console.log(`Lesson 9: /api/notice. Browser experiments: /lab. Stop with Ctrl+C.`);
  });
  let stopping = false;
  const stop = () => {
    if (stopping) return;
    stopping = true;
    server.close(() => console.log('Caching lab stopped.'));
    server.closeAllConnections();
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
