# Your local observations

The lesson's curl commands save their ETag, headers, and body here. Running a command again can replace its named output file. Keep a separate copy if you want to preserve multiple attempts. These files are your observations, not an automatic browser cache and not verified evidence of independent work.
