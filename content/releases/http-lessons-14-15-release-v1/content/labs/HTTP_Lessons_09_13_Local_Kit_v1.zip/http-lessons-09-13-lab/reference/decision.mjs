// Worked Lesson 12 solution. Copy this function into practice/decision.mjs
// if you choose the walkthrough, then explain why the checks have this order.
export function decideResponse(method, exists, condition) {
  if (!exists) return 404;
  if (method !== 'GET' && method !== 'HEAD') return 405;
  if (condition === 'invalid') return 400;
  if (condition === 'match') return 304;
  return 200;
}
