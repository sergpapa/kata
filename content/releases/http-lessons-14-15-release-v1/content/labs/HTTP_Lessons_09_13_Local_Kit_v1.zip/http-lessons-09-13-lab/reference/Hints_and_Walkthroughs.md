# Hints and worked explanations

Use as much help as you need. The student lessons also contain immediate worked explanations; this file collects the main diagnostic decisions.

## Lesson 9: decide which change matters

**Direction:** Compare the body selected for the exact same target before and after one source edit.

**Closer hint:** Follow the fields used by `makeRepresentation`. Does it read `editorNote` when making the body?

**Explanation:** Both full and short views read `closingTime`; neither includes `editorNote`. An internal-note edit can leave the selected bytes and their ETag unchanged. A closing-time edit changes both. A policy edit changes response metadata without changing these body bytes. The full and short URLs select different representations and have separate tags in this fixture.

## Lesson 10: explain an older but fresh copy

**Direction:** Ask what information the browser has actually received, not what the origin currently knows.

**Closer hint:** A five-minute reuse permission was attached to the stored response. Editing a file on the server does not reach into the browser.

**Explanation:** While that response is fresh and eligible for reuse, a normal browser read can use it without a new origin exchange. A plain curl request can independently retrieve newer source data. The two observations are compatible. Record the actual operation and elapsed time; a browser can evict entries or be configured to bypass them.

## Lesson 11: explain 304 without pretending it contains a body

**Direction:** Locate the retained body and the validator associated with it.

**Closer hint:** `--etag-compare` supplies a condition; it does not make curl merge a response with your saved JSON.

**Explanation:** A matching retrieval receives 304 and no new body. Your earlier JSON remains the content available for reuse. A visible source change gives a different tag and a 200 response. The compare-only command does not update the tag file, so repeating it can keep producing 200 until you deliberately save the new response and tag. A validator without the corresponding body is insufficient to reconstruct the content.

## Lesson 12: implement the decision, then challenge it

**Direction:** Establish whether the ordinary request can succeed before acting on the condition.

**Closer hint:** The wildcard and the presence of a header cannot create a missing resource or authorize an unsupported method.

**Worked solution:** `decision.mjs` checks existence, supported retrieval method, the fixture's invalid-field policy, and match, in that order. Absent and different conditions reach ordinary 200. A 304 response is then emitted without content. HEAD also has no content on 200, so absence of a body is not a sufficient status rule.

Tempting shortcuts fail for different reasons:

- Returning 304 whenever a conditional field is present confuses presence with matching.
- Returning 304 for a match before checking existence hides a missing resource.
- Returning 304 for every HEAD confuses method semantics with validation.
- Treating `W/"edition"` as different from `"edition"` uses the wrong comparison for If-None-Match.
- Splitting blindly on every comma damages a quoted opaque tag that contains a comma.

The last two are handled by the supplied parser. Writing a complete HTTP parser is outside this small exercise.

## Lesson 13: compare the observation points

**Direction:** Label each observation: origin exchange, browser processing, or page display.

**Closer hint:** The browser can validate an earlier 200 response with a 304 exchange, then expose the retained response to page code.

**Explanation:** Origin 304 and page 200 can describe a single successful validation sequence. A no-store fetch bypass can fetch the newest notice without updating the older HTTP-cache entry. A subsequent normal read can therefore return the older still-fresh response. In this correct fixture, an explicit validation after a visible edit produces a new 200 response and allows the ordinary path to update. Observe that next ordinary path before claiming a repair.

If your actual browser sequence differs, check cache settings, freshness, response policy, whether the warm-up occurred, and the exact URL. Preserve the differing evidence. These expected explanations are not a substitute for an actual browser rehearsal.
