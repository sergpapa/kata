# Instructor and coder notes

## Teaching purpose

These five lessons complete M021-01 through M021-05: identity and representations; stored-response freshness; validators; conditional retrieval cases; browser observation layers. They supply mechanisms before the later M021-06/07 seeded validator investigation. This kit's live server is intentionally correct. The only incomplete implementation is the clearly isolated Lesson 12 practice function.

Require an explanation of why an observation follows. Do not award independent debugging mastery for following the worked sequence or opening a solution. The app may record study, learner-reported observations, and help used separately.

## Browser rehearsal: still required

The author verified the Node/HTTP/curl paths, not an actual browser cache run. A browser binary was unavailable in the author environment and its download timed out. Before treating browser behavior as rehearsed, run the following on an actual Chrome/Chromium installation and keep the browser version, settings, origin log, and observations. Native Windows/macOS setup and course-app integration also remain unverified.

1. Start this exact kit, use one fixed origin, and open `/lab`. Turn off the Network **Disable cache** option. Filter for `api/notice`. Ensure this origin has no pre-existing service worker from unrelated local work; choose a fresh permitted port if needed before starting the sequence.
2. Set `baseline`, then `fresh`. Press **Start with a current copy**. Expect origin 200 and displayed 17:00. Press **Read normally** promptly. If the cache retained the eligible response, expect displayed 17:00 without a new origin notice request.
3. Run `later`. Before the five-minute freshness window ends, press **Read normally** again. Expect the retained 17:00 response under those conditions. Direct curl should retrieve 18:00. Record actual results if caching did not occur.
4. Press **Bypass storage for this read**. Expect origin 200 and page 18:00. Press **Read normally** promptly. The earlier cache entry can still produce 17:00; the bypass did not overwrite it.
5. Press **Validate the stored copy**. The old validator should not match the current body: expect origin 200/page 200 with 18:00. Press it again: expect a conditional origin 304 and the browser to expose the retained successful response/body to page code.
6. Separately set `baseline`, then `validate`. Press **Start with a current copy**, then **Validate the stored copy**. Expect origin 200 followed by conditional 304, while page code receives usable content. Inspect request headers and distinguish DevTools' version-dependent display from the server's actual status.
7. Press **Read normally** under `private, no-cache`; confirm it also validates a retained response. Change only the internal note and repeat; its body/tag should remain unchanged.
8. Stop the server, attempt another validation, and check that the page reports a failed read rather than claiming its previous displayed result is new evidence. Restart to continue. Do not generalize this step to every stale-serving policy.

Use a table with action, policy, source closing time, elapsed time, request If-None-Match, origin status, page status, and displayed body. “Expected” entries must remain distinct from recorded entries. There is no mandatory claim that DevTools always displays a particular cache label or status presentation.

## Author checks and their limits

`checks/protocol.test.mjs` uses a real loopback HTTP server with controlled source state. It verifies source/representation/tag relationships, cache metadata, GET/HEAD body rules, weak/list/wildcard comparisons, normal failure precedence, and the lab-specific malformed-field behavior. It does not emulate a browser and makes no assertion that a user completed the lessons.

`checks/practice.test.mjs` verifies the isolated decision case matrix. The incomplete starter must fail ten cases. A complete worked function passes all fourteen. Deliberately wrong decision ordering is used in author verification to confirm that the exercise distinguishes a plausible error.

The origin log reports the method, target, incoming condition, and outgoing status after a response finishes. It is not a packet capture or proof of browser storage. Source hashes establish which supplied files were packaged; they do not verify a learner's work.

## Deliberate simplifications

- A single local origin, one data file, no authentication, and no shared intermediary.
- Complete URL variation through a query parameter; no request-header representation negotiation yet.
- Strong tags calculated from the full selected JSON bytes; no compression or negotiated encoding.
- Three explicit cache policies; the complete RFC age algorithm is deferred.
- A bounded supplied parser; invalid conditional fields are rejected only after normal target/method checks for this fixture.
- The browser HTTP cache is real; the page itself implements no substitute cache.

Do not upgrade a candidate's status to independent mid-level competence based on these guided exercises. The coming investigation removes scaffolding and asks the learner to establish and repair a defect with evidence.
