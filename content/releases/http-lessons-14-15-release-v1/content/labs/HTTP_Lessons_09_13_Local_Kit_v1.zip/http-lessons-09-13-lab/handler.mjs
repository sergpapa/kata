import { readFileSync } from 'node:fs';
import { makeRepresentation, cachePolicy } from './support/representation.mjs';
import { compareCondition } from './support/if-none-match.mjs';
import { decideResponse } from './support/decision.mjs';

const pages = new Map([
  ['/lab', ['text/html; charset=utf-8', readFileSync(new URL('./public/lab.html', import.meta.url))]],
  ['/lab.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./public/lab.js', import.meta.url))]],
]);
const defaultReadState = () => JSON.parse(readFileSync(new URL('./data/cafe.json', import.meta.url), 'utf8'));

function send(request, response, status, body, contentType, extraHeaders = {}) {
  response.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
    ...extraHeaders,
  });
  response.end(request.method === 'HEAD' ? undefined : body);
}

export function createHandler(readState = defaultReadState) {
  return function handleRequest(request, response) {
    let target;
    try { target = new URL(request.url, 'http://127.0.0.1'); }
    catch { send(request, response, 400, 'Invalid target\n', 'text/plain'); return; }
    if (pages.has(target.pathname)) {
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        send(request, response, 405, 'Method not allowed\n', 'text/plain', { Allow: 'GET, HEAD' });
        return;
      }
      const [contentType, body] = pages.get(target.pathname);
      send(request, response, 200, body, contentType);
      return;
    }
    const exists = target.pathname === '/api/notice';
    const view = target.searchParams.get('view') ?? 'full';
    const retrieval = request.method === 'GET' || request.method === 'HEAD';
    // Normal failures take precedence over conditional retrieval decisions.
    if (exists && retrieval && !['full', 'short'].includes(view)) {
      send(request, response, 400, '{"error":"Unknown view"}\n', 'application/json');
      return;
    }
    let representation;
    let policy;
    let condition = 'absent';
    if (exists && retrieval) {
      const state = readState();
      representation = makeRepresentation(state, view);
      policy = cachePolicy(state);
      condition = compareCondition(request.headers['if-none-match'], representation.etag);
    }
    const status = decideResponse(request.method, exists, condition);
    if (status === 304) {
      response.writeHead(304, { ETag: representation.etag, 'Cache-Control': policy });
      response.end();
      return;
    }
    if (status === 200) {
      send(request, response, 200, representation.body, 'application/json', {
        ETag: representation.etag, 'Cache-Control': policy,
      });
      return;
    }
    const messages = { 400: 'Malformed If-None-Match', 404: 'Not found', 405: 'Method not allowed' };
    send(request, response, status, JSON.stringify({ error: messages[status] }) + '\n', 'application/json', status === 405 ? { Allow: 'GET, HEAD' } : {});
  };
}

export const handleRequest = createHandler();
