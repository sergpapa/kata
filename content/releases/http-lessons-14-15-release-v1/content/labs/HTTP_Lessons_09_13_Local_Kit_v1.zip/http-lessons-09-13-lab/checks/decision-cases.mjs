import test from 'node:test';
import assert from 'node:assert/strict';

export function checkDecision(decideResponse) {
  const cases = [
    ['GET', true, 'absent', 200], ['GET', true, 'different', 200],
    ['GET', true, 'match', 304], ['HEAD', true, 'absent', 200],
    ['HEAD', true, 'different', 200], ['HEAD', true, 'match', 304],
    ['GET', false, 'match', 404], ['HEAD', false, 'match', 404],
    ['POST', true, 'match', 405], ['POST', false, 'match', 404],
    ['GET', true, 'invalid', 400], ['HEAD', true, 'invalid', 400],
    ['GET', false, 'invalid', 404], ['POST', true, 'invalid', 405],
  ];
  for (const [method, exists, condition, expected] of cases) {
    test(`${method}, exists=${exists}, condition=${condition} -> ${expected}`, () => {
      assert.equal(decideResponse(method, exists, condition), expected);
    });
  }
}
