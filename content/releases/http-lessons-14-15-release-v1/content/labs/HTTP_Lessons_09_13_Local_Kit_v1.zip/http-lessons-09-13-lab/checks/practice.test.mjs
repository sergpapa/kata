import { decideResponse } from '../practice/decision.mjs';
import { checkDecision } from './decision-cases.mjs';

checkDecision(decideResponse);
