import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler } from '../handler.mjs';
import { withApp } from './http-client.mjs';

function fixture(action) {
  const state = { closingTime: '17:00', editorNote: 'Original', policy: 'validate' };
  return withApp(createHandler(() => state), (send) => action(send, state));
}

test('GET returns the selected JSON and a quoted strong tag', () => fixture(async (send) => {
  const result = await send('GET', '/api/notice');
  assert.equal(result.status, 200);
  assert.deepEqual(JSON.parse(result.body), { title: 'Cafe notice', message: 'Today we close at 17:00.' });
  assert.match(result.headers.etag, /^"[0-9a-f]{64}"$/);
}));
test('internal note does not change the representation or validator', () => fixture(async (send, state) => {
  const a = await send('GET', '/api/notice');
  state.editorNote = 'Changed only inside the source';
  const b = await send('GET', '/api/notice');
  assert.equal(a.body, b.body); assert.equal(a.headers.etag, b.headers.etag);
}));
test('closing time changes both content and validator', () => fixture(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.closingTime = '18:00';
  const b = await send('GET', '/api/notice');
  assert.notEqual(a.body, b.body); assert.notEqual(a.headers.etag, b.headers.etag);
}));
test('view query participates in selection', () => fixture(async (send) => {
  const full = await send('GET', '/api/notice');
  const short = await send('GET', '/api/notice?view=short');
  assert.deepEqual(JSON.parse(short.body), { closingTime: '17:00' });
  assert.notEqual(short.headers.etag, full.headers.etag);
}));
test('fresh policy does not change selected content or tag', () => fixture(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.policy = 'fresh';
  const b = await send('GET', '/api/notice');
  assert.equal(a.body, b.body); assert.equal(a.headers.etag, b.headers.etag);
  assert.equal(b.headers['cache-control'], 'private, max-age=300, must-revalidate');
}));

for (const method of ['GET', 'HEAD']) {
  for (const form of ['exact', 'weak', 'list', 'wildcard', 'quoted-comma', 'empty-members']) {
    test(`${method} recognizes a ${form} matching condition`, () => fixture(async (send) => {
      const initial = await send('GET', '/api/notice');
      const tag = initial.headers.etag;
      const values = { exact: tag, weak: 'W/' + tag, list: '"old", ' + tag, wildcard: '*', 'quoted-comma': '"comma,inside", W/' + tag, 'empty-members': ', , ' + tag + ', ' };
      const result = await send(method, '/api/notice', { 'If-None-Match': values[form] });
      assert.equal(result.status, 304); assert.equal(result.body, '');
      assert.equal(result.headers.etag, tag); assert.equal(result.headers['cache-control'], 'private, no-cache');
      assert.ok(result.headers.date); assert.equal(result.headers['content-length'], undefined);
    }));
  }
}
test('a different valid condition receives 200 and current content', () => fixture(async (send) => {
  const result = await send('GET', '/api/notice', { 'If-None-Match': '"other"' });
  assert.equal(result.status, 200); assert.match(result.body, /17:00/);
}));
test('an old validator after a visible edit receives new content', () => fixture(async (send, state) => {
  const old = await send('GET', '/api/notice'); state.closingTime = '18:00';
  const changed = await send('GET', '/api/notice', { 'If-None-Match': old.headers.etag });
  assert.equal(changed.status, 200); assert.match(changed.body, /18:00/);
}));
test('an old validator after an internal edit remains valid', () => fixture(async (send, state) => {
  const old = await send('GET', '/api/notice'); state.editorNote = 'New note';
  assert.equal((await send('GET', '/api/notice', { 'If-None-Match': old.headers.etag })).status, 304);
}));
test('conditional selection compares the chosen view, not just the path', () => fixture(async (send) => {
  const full = await send('GET', '/api/notice');
  const short = await send('GET', '/api/notice?view=short', { 'If-None-Match': full.headers.etag });
  assert.equal(short.status, 200); assert.deepEqual(JSON.parse(short.body), { closingTime: '17:00' });
}));
test('ordinary HEAD gives representation metadata without content', () => fixture(async (send) => {
  const get = await send('GET', '/api/notice'); const head = await send('HEAD', '/api/notice');
  assert.equal(head.status, 200); assert.equal(head.body, '');
  assert.equal(Number(head.headers['content-length']), Buffer.byteLength(get.body));
  assert.equal(head.headers.etag, get.headers.etag);
}));
for (const condition of ['*', 'not-a-tag']) {
  test(`missing target stays 404 with condition ${condition}`, () => fixture(async (send) => {
    assert.equal((await send('GET', '/api/missing', { 'If-None-Match': condition })).status, 404);
  }));
  test(`unsupported POST stays 405 with condition ${condition}`, () => fixture(async (send) => {
    const result = await send('POST', '/api/notice', { 'If-None-Match': condition });
    assert.equal(result.status, 405); assert.equal(result.headers.allow, 'GET, HEAD');
  }));
}
for (const value of ['not-a-tag', '"unterminated', '*, "mixed"', '"one" "two"', 'w/"wrong-prefix"']) {
  test(`malformed field follows explicit lab 400 policy: ${value}`, () => fixture(async (send) => {
    const result = await send('GET', '/api/notice', { 'If-None-Match': value });
    assert.equal(result.status, 400); assert.equal(result.headers['cache-control'], 'no-store');
  }));
}
test('invalid view is rejected before a conditional response', () => fixture(async (send) => {
  assert.equal((await send('GET', '/api/notice?view=unknown', { 'If-None-Match': '*' })).status, 400);
}));
test('no-store policy is explicit', () => fixture(async (send, state) => {
  state.policy = 'no-store';
  assert.equal((await send('GET', '/api/notice')).headers['cache-control'], 'no-store');
}));
test('the browser page and script are available without caching', () => fixture(async (send) => {
  for (const path of ['/lab', '/lab.js']) {
    const result = await send('GET', path);
    assert.equal(result.status, 200); assert.equal(result.headers['cache-control'], 'no-store');
  }
}));
