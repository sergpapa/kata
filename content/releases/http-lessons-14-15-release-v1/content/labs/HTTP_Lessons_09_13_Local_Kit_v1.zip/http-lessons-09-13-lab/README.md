# HTTP Lessons 9–13: a notice, its copies, and its validators

Work through the student Markdown lessons in order. This kit supplies a small, correct HTTP server and a browser page that uses the browser's real HTTP cache. Lesson 12 adds an isolated coding exercise. No package installation is required.

## Start here

1. Extract this ZIP into a new folder and open that folder in VS Code.
2. In its terminal, check `node --version`. The author-verified runtime is Node.js 24.x on Linux.
3. Run `node state.mjs baseline` to set the fictional café back to its starting data.
4. Run `node server.mjs` and leave that terminal open.
5. Use a second terminal in the same folder for state changes and curl commands.

The service listens only on `127.0.0.1:4319`. If the port is busy, use `node server.mjs 4320` and substitute `4320` in every URL, including browser URLs. Press **Ctrl+C** in the server terminal to stop it. Changing ports also changes the origin and cache identity; do not switch ports halfway through a cache comparison.

Open `http://127.0.0.1:4319/lab` for browser experiments. Lessons 9 and 11 also use `http://127.0.0.1:4319/api/notice` directly. Keep Chrome/Chromium's Network **Disable cache** checkbox unchecked during the caching experiments. Clearing the visible Network rows does not clear stored responses.

On Windows PowerShell, use `curl.exe` in place of `curl` to select the actual curl program. Run commands on separate lines. curl's `--etag-save` and `--etag-compare` options require version 7.68 or newer; Lesson 11 supplies a header-file alternative for curl 7.55 or newer. Check with `curl --version` or `curl.exe --version`.

## Change one thing at a time

Each command below modifies only `data/cafe.json`, except `show`, which is read only. The live server reads that file again for every notice request. Code changes require stopping and restarting the server.

| Command | Effect |
| --- | --- |
| `node state.mjs baseline` | Restore closing time 17:00, the initial internal note, and `no-store` policy |
| `node state.mjs early` | Set closing time to 17:00 |
| `node state.mjs later` | Set closing time to 18:00 |
| `node state.mjs note` | Change the internal note, which is excluded from the selected representation |
| `node state.mjs fresh` | Select `private, max-age=300, must-revalidate` |
| `node state.mjs validate` | Select `private, no-cache` |
| `node state.mjs no-store` | Select `no-store` |
| `node state.mjs show` | Print current source state without changing it |

These commands do not erase the browser cache, rewrite your notes, or restart the server. To establish a controlled starting response after setting the required policy, use the lab's **Start with a current copy** button. Keep old observations if you want to compare attempts; curl's output commands replace files with the same names.

## What each file does

| File or folder | Responsibility |
| --- | --- |
| `server.mjs` | Bind a loopback HTTP server and print numbered request summaries |
| `handler.mjs` | Route requests and send responses |
| `data/cafe.json` | Fictional mutable source data and the selected response policy |
| `state.mjs` | Make the lesson's controlled source changes |
| `support/representation.mjs` | Select full/short JSON, build its strong ETag, and choose policy |
| `support/if-none-match.mjs` | Parse the supplied conditional field and compare opaque tags |
| `support/decision.mjs` | Correct decision function used by the live server |
| `public/lab.html`, `public/lab.js` | Local observation page and native fetch calls |
| `practice/decision.mjs` | Intentionally incomplete Lesson 12 exercise |
| `checks/practice.test.mjs` | Fourteen cases for the isolated exercise |
| `checks/protocol.test.mjs` | Author checks over actual loopback HTTP exchanges |
| `reference/` | Worked solution and explanations, available whenever helpful |
| `observations/` | A place for your captured responses and notes |
| `Practice_Notes.md` | Optional record of predictions, observations, and reasoning |
| `Instructor_Notes.md` | Fixture boundaries and browser rehearsal procedure |
| `author-verification.json` | Recorded checks and explicit unverified environments |

The browser page is a local lab instrument, separate from the course application UI. It does not load the course, mark lessons complete, upload your work, or implement a custom response cache.

## Routes and boundaries

`GET /api/notice` returns the full JSON notice; `GET /api/notice?view=short` selects a shorter JSON representation. Their complete URLs differ. The server also supports `HEAD` for these targets. A missing path yields 404; an unsupported method on a known route yields 405 with `Allow: GET, HEAD`. An unsupported view yields 400.

The ETag is a quoted SHA-256 hash of the selected JSON body's bytes. It deliberately excludes the internal note and response policy. This is one implementation strategy, not a claim that every ETag must be a hash. The fixture emits strong validators, uses weak comparison for If-None-Match, and handles quoted lists and `*`. A matching conditional GET or HEAD produces 304 without content; an eligible nonmatching retrieval produces 200.

The helper accepts bounded HTTP list syntax. It limits the field to 8,192 characters, 64 tags, and 64 comma separators/empty-element encounters. For an otherwise supported notice retrieval, malformed input becomes a lab-specific 400 response. Node's own parser/header-size limits can reject a request before the application sees it. Missing resources and unsupported methods take precedence in this fixture. This is a retrieval-only teaching service, not a complete conditional-write implementation.

There is no authentication, CDN, service worker, database, compression, range handling, Last-Modified validation, or rate limiter here. Their mechanisms belong to later lessons. No learner-supplied code is executed by the course platform: you run this kit yourself on your machine.

## Run the appropriate checks

Run this to check the supplied live protocol behavior:

```sh
node --test checks/protocol.test.mjs
```

Run this for the Lesson 12 practice function:

```sh
node --test checks/practice.test.mjs
```

The unchanged practice starter intentionally gives **4 passes and 10 failures**. That does not mean the correct browser lab is broken. Implement the function using the lesson's case matrix, or read `reference/decision.mjs`. The worked implementation should pass all 14 practice cases. Avoid running every `*.test.mjs` and mistaking the deliberate practice failures for installation errors.

Server/CLI checks do not establish browser behavior. Browser cache experiments are documented expectations awaiting an owner rehearsal; record what actually happens in your browser. See `Instructor_Notes.md` for a concise verification procedure.

## Troubleshooting

| Observation | First useful check |
| --- | --- |
| Address already in use | Stop your earlier lab process or select another allowed port consistently |
| Browser cannot connect | Is the correct server terminal still running? Does its printed URL match? |
| curl sees 18:00 but the normal browser read sees 17:00 | Inspect the stored policy, elapsed age, button used, and origin log before calling it a defect |
| Every button reaches the origin | Check Disable cache, current response policy, elapsed time, and whether a cache entry was retained |
| Data was reset but the browser still has an older copy | A file reset does not send an invalidation message; establish a current copy under the desired policy |
| 304 has no JSON body | Use the previously retained body; the validation response is not a new representation |
| Repeated comparison keeps returning 200 after an edit | `--etag-compare` alone does not replace your saved validator with the new one |
| Server reports an invalid data file | Inspect `data/cafe.json`, or restore it with `node state.mjs baseline` |

## References

The teaching contract follows [HTTP semantics, RFC 9110](https://www.rfc-editor.org/rfc/rfc9110.html) and [HTTP caching, RFC 9111](https://www.rfc-editor.org/rfc/rfc9111.html). Browser controls are described in [Request.cache](https://developer.mozilla.org/en-US/docs/Web/API/Request/cache) and the [Chrome Network reference](https://developer.chrome.com/docs/devtools/network/reference#disable-browser-cache). See the [curl manual](https://curl.se/docs/manpage.html) and [curl 7.55 header-file change](https://curl.se/ch/7.55.0.html) for command options.
