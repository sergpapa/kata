// Lesson 12: complete this function against the supplied contract.
// method: request method; exists: whether the requested API resource exists.
// condition: 'absent', 'different', 'match', or 'invalid'.
export function decideResponse(method, exists, condition) {
  return 200;
}
