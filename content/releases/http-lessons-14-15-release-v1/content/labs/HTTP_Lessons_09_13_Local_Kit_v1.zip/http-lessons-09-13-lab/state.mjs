import { readFileSync, writeFileSync } from 'node:fs';

const file = new URL('./data/cafe.json', import.meta.url);
const baseline = { closingTime: '17:00', editorNote: 'Opening draft checked', policy: 'no-store' };
const command = process.argv[2];
const allowed = ['baseline', 'early', 'later', 'note', 'fresh', 'validate', 'no-store', 'show'];
if (process.argv.length !== 3 || !allowed.includes(command)) {
  console.error('Choose one: baseline, early, later, note, fresh, validate, no-store, show');
  process.exitCode = 1;
} else {
  const state = command === 'baseline' ? baseline : JSON.parse(readFileSync(file, 'utf8'));
  if (command === 'early') state.closingTime = '17:00';
  if (command === 'later') state.closingTime = '18:00';
  if (command === 'note') state.editorNote = 'Internal wording review completed';
  if (['fresh', 'validate', 'no-store'].includes(command)) state.policy = command;
  if (command !== 'show') writeFileSync(file, JSON.stringify(state, null, 2) + '\n');
  console.log(JSON.stringify(state, null, 2));
  console.log(command === 'show' ? 'Read only. The browser may still hold an earlier response.' : 'Only this kit\'s data/cafe.json was changed. The running server reads it for each API request.');
}
