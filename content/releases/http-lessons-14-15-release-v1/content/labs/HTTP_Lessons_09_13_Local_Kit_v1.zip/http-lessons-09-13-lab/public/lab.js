const buttons = [...document.querySelectorAll('button[data-mode]')];
for (const button of buttons) {
  button.addEventListener('click', async () => {
    for (const item of buttons) item.disabled = true;
    document.querySelector('#message').textContent = 'Reading the notice…';
    try {
      const response = await fetch('/api/notice', { cache: button.dataset.mode });
      const text = await response.text();
      document.querySelector('#mode').textContent = button.textContent;
      document.querySelector('#status').textContent = String(response.status);
      document.querySelector('#policy').textContent = response.headers.get('cache-control') ?? '(absent)';
      document.querySelector('#etag').textContent = response.headers.get('etag') ?? '(absent)';
      document.querySelector('#body').textContent = text || '(no body exposed to the page)';
      document.querySelector('#message').textContent = 'Finished. Compare the content with the origin request log.';
    } catch (error) {
      document.querySelector('#message').textContent = `The request failed (${error.name}). The panel below still shows the previous completed result.`;
    } finally {
      for (const item of buttons) item.disabled = false;
    }
  });
}
