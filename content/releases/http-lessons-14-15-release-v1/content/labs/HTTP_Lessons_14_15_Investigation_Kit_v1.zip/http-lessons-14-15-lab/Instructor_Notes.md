# Instructor notes and browser rehearsal

## Pedagogical roles

Lesson 14 develops diagnosis under a stated contract. Lesson 15 develops a failing regression, repair, alternative evaluation, and a bounded supported transfer case. The transfer is included in M021-07 practice; it does not mark the later M021-09 independent task complete.

The incident omits a body dependency when constructing the validator. The transfer's validator already describes its returned body, but an in-process result lookup collapses distinct edition selections. Ask the learner to explain where information is lost in each case.

Keep the correct helper implementation separate from the deliberate case defects. The browser is real if used; no browser cache is emulated by the page or tests. The platform does not execute arbitrary learner submissions.

## Interpreting failures

The original incident has five failing cases out of 22. Four concern changed selected content; one enforces stable reuse for a title edit excluded from the short view. The original transfer has five failing cases out of eight. The reference repairs pass all 30 cases. The completed learner regression fails on the original incident and passes after repair; the distributed worksheet remains explicitly skipped.

Author verification also checks attractive alternatives: always-200 fails nine incident checks; hashing the entire source fails three selected-content stability/selection checks. The latter is not automatically the same HTTP correctness defect as false validation. Explain which local requirement is unmet rather than calling every suboptimal tag strategy invalid HTTP.

## Browser rehearsal: not yet performed by the author

A current browser binary was unavailable in the author environment. The earlier release's download attempt timed out; this release does not claim a new successful installation or any browser observations. Use these acceptance steps on a real browser and preserve the actual results.

1. Use the original incident code, baseline data, one fixed origin, and the `/lab` page. Confirm no unrelated service worker controls that origin; choose a fresh allowed port before the sequence if needed. Keep Network Disable cache unchecked.
2. Press Start with a current copy. Record origin 200, body 17:00, ETag, and `private, no-cache`.
3. Change only the closing time. Press Read normally. With the earlier response retained, expect the origin to log a matching condition and false 304 while the page continues to receive the retained 17:00 content.
4. Bypass storage for this read. Expect a current 18:00 body. Return to the normal path and record its behavior; the bypass did not repair the validator.
5. Apply the incident repair and restart the origin. Reset data, seed a new baseline response, change only the time, and use the normal path. Expect a new 200 body/tag after the edit, followed by a valid 304 on another unchanged validation. Distinguish origin status from the response exposed to fetch.
6. For the transfer, start a fresh process and request morning then evening through explicit target values. Use the bypass button if isolating origin selection from HTTP-cache handling. Reverse the order after a restart. Repeat both orders after repair.

No specific DevTools colour, cache label, or status presentation is required. The useful record is action, source state, incoming condition, origin status, page status, and body. If a cache entry was not retained, record that difference and inspect the preconditions.

## Review rubric without automatic grading

Assess reproduction, discriminating experiments, source trace, causal explanation, repair, regression quality, preserved cases, tradeoff reasoning, communication, and help used. An unfinished attempt can still show disciplined investigation. A solution studied beforehand cannot be counted as a fresh independent solution merely because its tests pass.

Setup help is distinct from conceptual help. Do not penalize someone for looking up syntax or using the supplied parser contract. Do require that they explain why an experiment or code change addresses the stated requirement.

## Deliberate limits

Single-process local HTTP; no CDN, proxy, TLS, database, authentication, negotiated compression, service worker, or rate limiter. Transfer data is immutable for the process lifetime. Hashing builds and reads the body, so this fixture demonstrates correctness and transfer behavior, not a production CPU-saving claim. Broader mutable/shared caches and their update rules remain later curriculum work.
