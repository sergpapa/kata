import { createServer } from 'node:http';
import { createHandler } from './handler.mjs';

const scenario = process.argv[2] ?? 'incident';
const rawPort = process.argv[3] ?? (scenario === 'transfer' ? '4323' : '4321');
const port = Number(rawPort);
if (process.argv.length > 4 || !['incident', 'transfer'].includes(scenario) || !/^\d+$/.test(rawPort) || port < 1024 || port > 65535) {
  console.error('Usage: node server.mjs [incident|transfer] [port 1024..65535]');
  process.exitCode = 1;
} else {
  const handler = createHandler(scenario);
  let count = 0;
  const server = createServer((request, response) => {
    const id = ++count;
    response.on('finish', () => console.log(JSON.stringify({ request: id, scenario, method: request.method,
      target: request.url, ifNoneMatch: request.headers['if-none-match'] ?? null, status: response.statusCode })));
    try { handler(request, response); }
    catch (error) {
      console.error(`Handler error: ${error.name}. Check the source data and your code edit.`);
      if (response.headersSent) response.destroy();
      else { response.writeHead(500, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' }); response.end('The lab could not build its response.\n'); }
    }
  });
  server.on('error', (error) => { console.error(`Startup failed: ${error.code ?? error.name}. Check the selected port.`); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => {
    console.log(`${scenario} listening on http://127.0.0.1:${port}`);
    console.log('Browser observation page: /lab. Stop with Ctrl+C. Restart after code changes.');
    console.log(scenario === 'incident' ? 'Incident source data is read for each request.' : 'Transfer source data is fixed at startup; restarting also clears process memory.');
  });
  let stopping = false;
  const stop = () => { if (stopping) return; stopping = true; server.close(() => console.log('Lab stopped.')); server.closeAllConnections(); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
