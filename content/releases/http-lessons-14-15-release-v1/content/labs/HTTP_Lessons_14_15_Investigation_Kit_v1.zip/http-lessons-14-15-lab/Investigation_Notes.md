# My investigation record

Use this as optional scaffolding. Preserve the original hypothesis or prediction when adding a later explanation. Complete walkthroughs are available whenever needed.

## Setup

- Case, attempt, and source state:
- OS, Node/curl versions, browser/version if used:
- Exact origin and target:
- Original supplied implementation or current code changes:
- Assistance used:

## Hypotheses and comparisons

| Possible explanation | Comparison that would distinguish it | Prediction | Actual observation |
| --- | --- | --- | --- |
| | | | |

## Evidence

Keep the before body/tag, controlled change, ordinary after response, and response to the preserved old tag. Separate scenario statements, author-supplied examples, and your actual observations. Browser observations should identify cache settings and the exact button or request path.

## Diagnosis

Which source values select the body? Which values affect the tag or saved-result key? Where does a required distinction disappear? Which competing explanation was ruled out, and by what observation?

## Repair and regression

- Stated behavior:
- Meaningful failure before repair:
- Source change and reason:
- Same case after repair:
- Unchanged, variant, HEAD, and normal failure cases preserved:
- Alternative considered and tradeoff:
- Evidence limits:

## Transfer

Record each request order on a fresh transfer process. Does the wrong body arrive before conditional validation? Why does a body fingerprint fail to repair a selection error? Under what source-lifetime assumption is your repair sufficient?

## If the investigation is unfinished

State your strongest supported finding, what remains uncertain, and the next experiment that would distinguish possibilities. Good investigation evidence is useful even when the final cause is not yet found.
