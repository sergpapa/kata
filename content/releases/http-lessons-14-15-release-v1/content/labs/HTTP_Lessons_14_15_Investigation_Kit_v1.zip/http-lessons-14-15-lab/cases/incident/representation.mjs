import { encode, tagFor } from '../../support/encoding.mjs';

export function createReader() {
  return (state, view) => {
    const value = view === 'short'
      ? { closingTime: state.closingTime }
      : { title: state.title, message: `Today we close at ${state.closingTime}.` };
    const body = encode(value);
    const etag = tagFor(encode({ title: state.title, view }));
    return { body, etag };
  };
}
