# HTTP Lessons 14–15: investigate, repair, and defend

This kit contains two intentionally faulty local services, a small browser observation page, HTTP tests, and separate worked repairs. Read Lesson 14 first. The incident packet does not assume that the proposed cause in a user report is correct.

## Setup

Extract into a new folder and open it in VS Code. Use Node.js 24.x and curl; no package installation is needed. The author checked Linux with Node v24.19.0 and curl 8.5.0. Native Windows/macOS and the browser-cache sequence remain unverified; PowerShell examples should invoke `curl.exe` rather than an alias.

In the kit's root folder, run these separately:

```sh
node state.mjs baseline
node server.mjs incident
```

Leave the server in Terminal A. Use Terminal B for curl and state commands. Default incident URL: `http://127.0.0.1:4321/api/notice`. Browser page: `http://127.0.0.1:4321/lab`. If needed, start `node server.mjs incident 4322` and use that port consistently. The server binds only to loopback. Ctrl+C stops it.

The transfer case starts with `node server.mjs transfer` on port 4323; an alternative such as 4324 may be supplied as the next argument. Use the matching host, port, and target in every comparison. The browser page is a local exercise instrument, separate from the course app.

## State and reset

| Command or action | What changes |
| --- | --- |
| `node state.mjs baseline` | Incident data resets to supplied title, 17:00, and initial internal note |
| `node state.mjs later` | Incident closing time becomes 18:00 |
| `node state.mjs title` | Incident public title changes |
| `node state.mjs note` | Incident internal note changes |
| `node state.mjs show` | Read-only display of current incident source |
| Restart incident server | Loads code edits; incident data still comes from its current file |
| Restart transfer server | Loads code and the fixed source snapshot; clears that process's saved results |
| Fresh extraction into a different folder | Restores the original faulty source and all supplied files without overwriting your investigation |

`baseline` does not restore code, modify the transfer case, erase observations, or clear browser storage. There is deliberately no reset command that silently discards learner code changes. Save an observation under a new name if you want to preserve an earlier curl capture.

## Files to explore

| Location | Role |
| --- | --- |
| `incident-packet/Report.md` | Fictional support report and possible distractions |
| `incident-packet/Contract.md` | Required behavior and fixture boundaries |
| `server.mjs` | Process startup, loopback server, numbered request logs |
| `handler.mjs` | Target/method selection and normal/conditional responses |
| `cases/incident/` | Incident source data and representation reader |
| `cases/transfer/` | Separate edition-selection source and representation reader |
| `support/` | Supplied JSON encoding, fingerprint, parser, and decision helpers |
| `checks/` | HTTP suites and the learner's regression worksheet |
| `reference/` | Complete repairs and the completed regression example |
| `observations/` | A place for preserved captures and notes |
| `Investigation_Notes.md` | Optional evidence template |
| `Instructor_Notes.md` | Expected outcomes, verification limits, and browser rehearsal |

The recent style patch is authored scenario evidence, not a claim that this ZIP contains real production Git history. If you already use Git, you may create a repository in this extracted kit and commit the baseline, failing test, and repair as separate steps. Git proficiency is not a hidden prerequisite for this HTTP investigation.

## Tests: expect the starter failures

Run the suites separately from the kit root:

```sh
node --test checks/incident.test.mjs
node --test checks/transfer.test.mjs
node --test checks/learner-regression.test.mjs
```

| Supplied state | Expected result |
| --- | --- |
| Original incident implementation | 17 pass, 5 fail |
| Worked incident repair | 22 pass, 0 fail |
| Original transfer implementation | 3 pass, 5 fail |
| Worked transfer repair | 8 pass, 0 fail |
| Untouched learner worksheet | 1 skipped, not a successful regression |
| Completed example regression on original incident | 1 requirement failure |
| Completed example regression after repair | 1 pass |

The tests start temporary local servers using your current source. They do not rely on the manually running process and do not change the on-disk case data. Code changes in the manually running server require a restart.

Worked files in `reference/` contain imports appropriate for their destination. Copy `incident-representation.mjs` to `cases/incident/representation.mjs`, `transfer-representation.mjs` to `cases/transfer/representation.mjs`, and the example regression to `checks/learner-regression.test.mjs` if choosing the walkthrough. Do not run reference files from their original folder. The lessons explain the changes before asking you to apply them.

## curl and browser observations

curl's `--etag-save` and `--etag-compare` require 7.68+. Lesson 11's `-H "@file"` alternative requires 7.55+. Keep the old tag/body files when capturing a changed response. A 304 carries no body; an output file left from an earlier command is not proof that one arrived.

The observation page uses native fetch with the same four cache modes as Lesson 13. Keep Chrome/Chromium's Network Disable cache option unchecked when studying browser-cache behavior. Source edits, code restarts, clearing displayed Network rows, and clearing an HTTP cache affect different states. Record exact actions.

No browser binary is available in the author environment, so actual browser-cache behavior remains a rehearsal task. The CLI and server tests establish origin behavior only. The instructor notes provide browser steps without presenting their expected results as actual captures.

## References

Protocol meanings are grounded in [RFC 9110](https://www.rfc-editor.org/rfc/rfc9110.html) and [RFC 9111](https://www.rfc-editor.org/rfc/rfc9111.html). The page's request modes follow [Request.cache](https://developer.mozilla.org/en-US/docs/Web/API/Request/cache). The transfer reading bridge uses ordinary [JavaScript Map operations](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map). References reviewed 2026-09-21.
