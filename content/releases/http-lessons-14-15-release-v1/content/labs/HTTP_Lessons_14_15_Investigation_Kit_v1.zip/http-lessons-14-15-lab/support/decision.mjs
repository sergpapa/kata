export function decideResponse(method, exists, condition) {
  if (!exists) return 404;
  if (method !== 'GET' && method !== 'HEAD') return 405;
  if (condition === 'invalid') return 400;
  if (condition === 'match') return 304;
  return 200;
}
