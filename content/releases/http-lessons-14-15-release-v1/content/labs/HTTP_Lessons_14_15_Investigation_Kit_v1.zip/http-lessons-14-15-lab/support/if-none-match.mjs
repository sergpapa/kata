// A bounded supplied parser, not a task for the introductory learner.
// Preserve commas inside quoted opaque tags. Empty list elements are ignored.
export function parseIfNoneMatch(raw) {
  if (raw === undefined) return { kind: 'absent' };
  if (typeof raw !== 'string' || raw.length > 8192) return { kind: 'invalid' };
  if (raw.replace(/^[ \t]*|[ \t]*$/g, '') === '*') return { kind: 'any' };
  const tags = [];
  let offset = 0;
  let emptyMembers = 0;
  while (offset < raw.length) {
    while (raw[offset] === ' ' || raw[offset] === '\t') offset++;
    if (offset === raw.length) break;
    if (raw[offset] === ',') {
      if (++emptyMembers > 64) return { kind: 'invalid' };
      offset++;
      continue;
    }
    const token = /^(?:W\/)?"([\x21\x23-\x7e\x80-\xff]*)"/.exec(raw.slice(offset));
    if (!token || tags.length >= 64) return { kind: 'invalid' };
    tags.push(token[1]);
    offset += token[0].length;
    while (raw[offset] === ' ' || raw[offset] === '\t') offset++;
    if (offset < raw.length && raw[offset] !== ',') return { kind: 'invalid' };
  }
  return { kind: 'tags', tags };
}

export function compareCondition(raw, currentTag) {
  const parsed = parseIfNoneMatch(raw);
  if (parsed.kind === 'absent' || parsed.kind === 'invalid') return parsed.kind;
  if (parsed.kind === 'any') return 'match'; // Caller has established existence.
  return parsed.tags.includes(currentTag.slice(1, -1)) ? 'match' : 'different';
}
