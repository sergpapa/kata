import { createHash } from 'node:crypto';

export const encode = (value) => JSON.stringify(value, null, 2) + '\n';
export const tagFor = (text) => '"' + createHash('sha256').update(text).digest('hex') + '"';
