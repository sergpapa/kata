import { encode, tagFor } from '../../support/encoding.mjs';

export function createReader() {
  const saved = new Map();
  return (state, edition) => {
    const key = edition;
    if (saved.has(key)) return saved.get(key);
    const body = encode(state[edition]);
    const result = { body, etag: tagFor(body) };
    saved.set(key, result);
    return result;
  };
}
