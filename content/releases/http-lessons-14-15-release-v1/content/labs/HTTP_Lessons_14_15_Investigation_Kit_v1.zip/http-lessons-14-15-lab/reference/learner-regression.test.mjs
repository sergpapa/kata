import test from 'node:test';
import assert from 'node:assert/strict';
import { incident } from './fixtures.mjs';

test('changed closing time supplies a replacement for the old copy', () => incident(async (send, state) => {
  const before = await send('GET', '/api/notice');
  state.closingTime = '18:00';
  const after = await send('GET', '/api/notice', { 'If-None-Match': before.headers.etag });
  assert.equal(after.status, 200);
  assert.equal(JSON.parse(after.body).message, 'Today we close at 18:00.');
  assert.notEqual(after.headers.etag, before.headers.etag);
}));
