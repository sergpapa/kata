import { readFileSync } from 'node:fs';
import { createReader as incidentReader } from './cases/incident/representation.mjs';
import { createReader as transferReader } from './cases/transfer/representation.mjs';
import { compareCondition } from './support/if-none-match.mjs';
import { decideResponse } from './support/decision.mjs';

const pages = new Map([
  ['/lab', ['text/html; charset=utf-8', readFileSync(new URL('./public/lab.html', import.meta.url))]],
  ['/lab.js', ['text/javascript; charset=utf-8', readFileSync(new URL('./public/lab.js', import.meta.url))]],
]);
const policy = 'private, no-cache';

function send(request, response, status, body, contentType, headers = {}) {
  response.writeHead(status, { 'Content-Type': contentType, 'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
  response.end(request.method === 'HEAD' ? undefined : body);
}

export function createHandler(scenario, suppliedSource) {
  if (!['incident', 'transfer'].includes(scenario)) throw new Error('Unknown scenario');
  const readFile = () => JSON.parse(readFileSync(new URL(`./cases/${scenario}/data.json`, import.meta.url), 'utf8'));
  // Incident data is live. Transfer data is a fixed snapshot for this process.
  const snapshot = scenario === 'transfer' && !suppliedSource ? readFile() : undefined;
  const readState = suppliedSource ?? (scenario === 'incident' ? readFile : () => snapshot);
  const readRepresentation = scenario === 'incident' ? incidentReader() : transferReader();
  return function handleRequest(request, response) {
    let target;
    try { target = new URL(request.url, 'http://127.0.0.1'); }
    catch { send(request, response, 400, 'Invalid target\n', 'text/plain'); return; }
    if (pages.has(target.pathname)) {
      if (!['GET', 'HEAD'].includes(request.method)) {
        send(request, response, 405, 'Method not allowed\n', 'text/plain', { Allow: 'GET, HEAD' }); return;
      }
      const [type, body] = pages.get(target.pathname);
      send(request, response, 200, body, type); return;
    }
    const exists = target.pathname === '/api/notice';
    const retrieval = request.method === 'GET' || request.method === 'HEAD';
    const parameter = scenario === 'incident' ? 'view' : 'edition';
    const choices = scenario === 'incident' ? ['full', 'short'] : ['morning', 'evening'];
    const selection = target.searchParams.get(parameter) ?? choices[0];
    if (exists && retrieval && !choices.includes(selection)) {
      send(request, response, 400, '{"error":"Unknown selection"}\n', 'application/json'); return;
    }
    let representation;
    let condition = 'absent';
    if (exists && retrieval) {
      representation = readRepresentation(readState(), selection);
      condition = compareCondition(request.headers['if-none-match'], representation.etag);
    }
    const status = decideResponse(request.method, exists, condition);
    if (status === 304) {
      response.writeHead(304, { ETag: representation.etag, 'Cache-Control': policy }); response.end(); return;
    }
    if (status === 200) {
      send(request, response, 200, representation.body, 'application/json', { ETag: representation.etag, 'Cache-Control': policy }); return;
    }
    const messages = { 400: 'Malformed If-None-Match', 404: 'Not found', 405: 'Method not allowed' };
    send(request, response, status, JSON.stringify({ error: messages[status] }) + '\n', 'application/json', status === 405 ? { Allow: 'GET, HEAD' } : {});
  };
}
