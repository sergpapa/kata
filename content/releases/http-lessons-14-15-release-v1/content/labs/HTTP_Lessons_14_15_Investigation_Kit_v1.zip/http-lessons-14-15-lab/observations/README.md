# Keep your own evidence here

Save initial and changed bodies, headers, and validators under different names. The lessons name files explicitly; re-running a save command replaces that named capture. `state.mjs baseline` does not erase these files or your code edits.

An actual 304 carries no body. Some curl output combinations leave an existing output file untouched; do not treat leftover file contents as the body of a later response. The conditional examples use `curl -i` so you can inspect that exchange directly.

Record the command, exact target, source state, expected result, observed result, and help used. An author's supplied trace is not a recording of your run.
