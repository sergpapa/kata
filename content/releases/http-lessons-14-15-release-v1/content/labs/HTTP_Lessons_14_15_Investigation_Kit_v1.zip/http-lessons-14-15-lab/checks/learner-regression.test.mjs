import test from 'node:test';
import assert from 'node:assert/strict';
import { incident } from './fixtures.mjs';

// This is a worksheet, not a passed test. Lesson 15 explains how to activate it.
test.skip('my regression: a changed notice must not validate the old copy', () => incident(async (send, state) => {
  // Retrieve the original response, change a selected source field,
  // then send the original validator and assert the required outcome.
}));
