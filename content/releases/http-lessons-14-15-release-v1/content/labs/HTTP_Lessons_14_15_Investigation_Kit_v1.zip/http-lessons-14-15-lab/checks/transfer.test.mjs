import test from 'node:test';
import assert from 'node:assert/strict';
import { transfer } from './fixtures.mjs';

for (const [first, second] of [['morning', 'evening'], ['evening', 'morning']]) {
  test(`selection stays correct in order ${first} then ${second}`, () => transfer(async (send) => {
    const a = await send('GET', '/api/notice?edition=' + first);
    const b = await send('GET', '/api/notice?edition=' + second);
    assert.equal(a.status, 200); assert.equal(b.status, 200);
    assert.equal(JSON.parse(a.body).edition, first); assert.equal(JSON.parse(b.body).edition, second);
    assert.notEqual(a.headers.etag, b.headers.etag);
  }));
  test(`tag for ${first} does not validate ${second}`, () => transfer(async (send) => {
    const a = await send('GET', '/api/notice?edition=' + first);
    const b = await send('GET', '/api/notice?edition=' + second, { 'If-None-Match': a.headers.etag });
    assert.equal(b.status, 200); assert.equal(JSON.parse(b.body).edition, second);
  }));
}
test('repeat same edition supports conditional reuse', () => transfer(async (send) => {
  const a = await send('GET', '/api/notice?edition=morning');
  const b = await send('GET', '/api/notice?edition=morning', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 304); assert.equal(b.body, '');
}));
test('HEAD selects the intended edition after a different request', () => transfer(async (send) => {
  const a = await send('GET', '/api/notice?edition=morning');
  const b = await send('HEAD', '/api/notice?edition=evening', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.equal(b.body, ''); assert.notEqual(a.headers.etag, b.headers.etag);
}));
test('unknown edition is 400', () => transfer(async (send) => {
  assert.equal((await send('GET', '/api/notice?edition=night')).status, 400);
}));
test('missing target and unsupported method retain normal failures', () => transfer(async (send) => {
  assert.equal((await send('GET', '/missing', { 'If-None-Match': '*' })).status, 404);
  assert.equal((await send('POST', '/api/notice', { 'If-None-Match': '*' })).status, 405);
}));
