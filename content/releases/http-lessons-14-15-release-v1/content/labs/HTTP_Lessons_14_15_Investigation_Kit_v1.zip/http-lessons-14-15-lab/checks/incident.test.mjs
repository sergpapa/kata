import test from 'node:test';
import assert from 'node:assert/strict';
import { incident } from './fixtures.mjs';

test('initial full body follows the product contract', () => incident(async (send) => {
  const a = await send('GET', '/api/notice');
  assert.equal(a.status, 200);
  assert.deepEqual(JSON.parse(a.body), { title: 'Riverside cafe notice', message: 'Today we close at 17:00.' });
  assert.match(a.headers.etag, /^"[^"\r\n]*"$/);
  assert.equal(a.headers['cache-control'], 'private, no-cache');
}));
test('unchanged selected body supports conditional 304', () => incident(async (send) => {
  const a = await send('GET', '/api/notice');
  const b = await send('GET', '/api/notice', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 304); assert.equal(b.body, '');
}));
test('a visible closing-time edit changes the body and validator', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.closingTime = '18:00';
  const b = await send('GET', '/api/notice');
  assert.notEqual(a.body, b.body); assert.notEqual(a.headers.etag, b.headers.etag);
}));
test('old tag after closing-time edit receives new 200 body', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.closingTime = '18:00';
  const b = await send('GET', '/api/notice', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.match(b.body, /18:00/);
}));
test('conditional HEAD after visible edit is 200 without a body', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.closingTime = '18:00';
  const b = await send('HEAD', '/api/notice', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.equal(b.body, ''); assert.notEqual(b.headers.etag, a.headers.etag);
}));
test('internal-note edit leaves selected body and validator stable', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.editorNote = 'Changed privately';
  const b = await send('GET', '/api/notice');
  assert.equal(b.body, a.body); assert.equal(b.headers.etag, a.headers.etag);
  assert.equal((await send('GET', '/api/notice', { 'If-None-Match': a.headers.etag })).status, 304);
}));
test('title edit changes the full selected representation', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice'); state.title = 'A changed public title';
  const b = await send('GET', '/api/notice', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.match(b.body, /changed public title/);
}));
test('title edit leaves the short selected representation reusable', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice?view=short'); state.title = 'A changed public title';
  const b = await send('GET', '/api/notice?view=short', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 304); assert.equal(b.body, '');
}));
test('closing-time edit changes the short selected representation', () => incident(async (send, state) => {
  const a = await send('GET', '/api/notice?view=short'); state.closingTime = '18:00';
  const b = await send('GET', '/api/notice?view=short', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.deepEqual(JSON.parse(b.body), { closingTime: '18:00' });
}));
test('full validator does not validate the short view', () => incident(async (send) => {
  const a = await send('GET', '/api/notice');
  const b = await send('GET', '/api/notice?view=short', { 'If-None-Match': a.headers.etag });
  assert.equal(b.status, 200); assert.deepEqual(JSON.parse(b.body), { closingTime: '17:00' });
}));
for (const method of ['GET', 'HEAD']) {
  for (const form of ['weak', 'list', 'wildcard']) {
    test(`${method}: ${form} condition preserves valid unchanged behavior`, () => incident(async (send) => {
      const a = await send('GET', '/api/notice');
      const condition = { weak: 'W/' + a.headers.etag, list: '"other,edition", ' + a.headers.etag, wildcard: '*' }[form];
      const b = await send(method, '/api/notice', { 'If-None-Match': condition });
      assert.equal(b.status, 304); assert.equal(b.body, '');
      assert.equal(b.headers.etag, a.headers.etag); assert.equal(b.headers['cache-control'], 'private, no-cache');
      assert.ok(b.headers.date); assert.equal(b.headers['content-length'], undefined);
    }));
  }
}
test('ordinary HEAD describes the GET representation without content', () => incident(async (send) => {
  const a = await send('GET', '/api/notice'); const b = await send('HEAD', '/api/notice');
  assert.equal(b.status, 200); assert.equal(b.body, '');
  assert.equal(b.headers.etag, a.headers.etag); assert.equal(Number(b.headers['content-length']), Buffer.byteLength(a.body));
}));
test('missing target is 404 even with a wildcard', () => incident(async (send) => {
  const b = await send('GET', '/missing', { 'If-None-Match': '*' });
  assert.equal(b.status, 404); assert.equal(b.headers['cache-control'], 'no-store');
}));
test('unsupported method is 405 even with a wildcard', () => incident(async (send) => {
  const b = await send('POST', '/api/notice', { 'If-None-Match': '*' });
  assert.equal(b.status, 405); assert.equal(b.headers.allow, 'GET, HEAD');
}));
test('invalid field follows this fixture\'s 400 policy', () => incident(async (send) => {
  assert.equal((await send('GET', '/api/notice', { 'If-None-Match': 'not-a-tag' })).status, 400);
}));
test('unknown view fails before conditional evaluation', () => incident(async (send) => {
  assert.equal((await send('GET', '/api/notice?view=missing', { 'If-None-Match': '*' })).status, 400);
}));
test('repeated ordinary reads keep stable selected bytes and validator', () => incident(async (send) => {
  const a = await send('GET', '/api/notice'); const b = await send('GET', '/api/notice');
  assert.equal(a.body, b.body); assert.equal(a.headers.etag, b.headers.etag);
}));
