import { createHandler } from '../handler.mjs';
import { withApp } from './http-client.mjs';

export function incident(action) {
  const state = { title: 'Riverside cafe notice', closingTime: '17:00', editorNote: 'Opening draft checked' };
  return withApp(createHandler('incident', () => state), (send) => action(send, state));
}
export function transfer(action) {
  const state = {
    morning: { edition: 'morning', message: 'Breakfast is served until 11:00.' },
    evening: { edition: 'evening', message: 'Dinner is served until 21:00.' },
  };
  return withApp(createHandler('transfer', () => state), (send) => action(send));
}
