import { createServer, request } from 'node:http';
import { once } from 'node:events';

export async function withApp(handler, action) {
  const server = createServer(handler);
  const ready = once(server, 'listening');
  server.listen(0, '127.0.0.1');
  await ready;
  const send = (method, path, headers = {}) => new Promise((resolve, reject) => {
    const call = request({ hostname: '127.0.0.1', port: server.address().port, method, path, headers, agent: false }, (response) => {
      const chunks = [];
      response.on('data', (part) => chunks.push(part));
      response.on('error', reject);
      response.on('end', () => resolve({ status: response.statusCode, headers: response.headers, body: Buffer.concat(chunks).toString('utf8') }));
    });
    call.on('error', reject);
    call.setTimeout(3000, () => call.destroy(new Error('Local request timed out')));
    call.end();
  });
  try { return await action(send); }
  finally {
    await new Promise((resolve, reject) => {
      server.close((error) => error ? reject(error) : resolve());
      server.closeAllConnections();
    });
  }
}
