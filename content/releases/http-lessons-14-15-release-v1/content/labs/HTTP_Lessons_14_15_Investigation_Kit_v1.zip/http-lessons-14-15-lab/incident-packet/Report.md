# Product report: returning visitors see an older notice

This is a fictional incident packet written for the exercise. These messages are supplied scenario material, not actual user reports or your own observations.

**Editor:** “I changed the closing time from 17:00 to 18:00. It looked saved.”

**Support:** “Some returning visitors still see 17:00. One person says refreshing helped; another still sees the earlier time.”

**Colleague A:** “Could the database write have failed?”

**Colleague B:** “I got the new time after a hard refresh, so perhaps the problem is fixed.”

**Recent change note:** “The observation page's background colour was updated. See `recent-style-change.patch`.”

Your task is to reproduce the symptom, distinguish the claims, and identify the causal path with evidence. There is no database in this supplied service; inspect the actual source storage rather than treating the report's terminology as authoritative.

Start with the contract and the observable request paths. You do not need to guess a hidden business rule, identify a real person, or contact an external system.
