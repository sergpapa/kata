# Retrieval contract

## Incident case

The source has a public title, closing time, and internal editor note. It is read for each supported notice request.

| Target | Selected JSON content |
| --- | --- |
| `/api/notice` or `?view=full` | `title` plus `message` built as “Today we close at TIME.” |
| `/api/notice?view=short` | `closingTime` only |

The editor note is excluded from both views. The public title is excluded from the short view. Changing a selected field must produce the required current content; changing only an excluded field should retain the selected bytes and stable validator under this assignment's reuse requirement.

## HTTP behavior for both cases

- GET returns the selected representation with 200 when no matching condition applies.
- Strong validators describe these uncompressed JSON representations. Different selected bytes must not be falsely validated by the earlier representation's tag.
- Successful notice responses use `Cache-Control: private, no-cache`.
- An unchanged eligible GET/HEAD with a matching If-None-Match receives 304 with ETag, cache policy, and Date, without content.
- HEAD uses the appropriate retrieval status and metadata but sends no content, including on 200.
- Missing paths remain 404 and unsupported methods on known routes remain 405 with `Allow: GET, HEAD`, before conditional handling.
- Unknown view/edition selections yield 400. Other query parameters do not change selection in this fixture.
- The supplied parser handles strong/weak tag syntax, lists including commas inside quoted opaque values, and a standalone wildcard. If-None-Match uses weak comparison. For an otherwise supported notice retrieval, malformed fields follow the fixture's explicit 400 policy.
- The parser has the same documented size bounds as the previous kit: 8,192 characters, 64 tags, and 64 comma/empty-element encounters. Node can reject malformed or oversized requests before the application runs.

These normal and conditional behaviors are part of the repair contract. “Always send 200” does not satisfy the unchanged-case requirement. Stable tags for byte-identical selected content are an explicit requirement here; extra invalidation is not equivalent to the original false-validation defect.

## Transfer case

`/api/notice?edition=morning` selects the morning source object; `?edition=evening` selects the evening source object. Default selection is morning. Both request orders must work. Repeated requests for an unchanged edition retain useful conditional reuse.

The source is a fixed snapshot loaded at process startup. Restarting reloads it and clears in-process saved results. There is no live source edit in this task. Any repair must state this boundary; it is not a complete mutable-cache design.

Keeping an internal Map is optional. Returning correct selected content and stable validators is required; a simpler implementation without the optimization can be defended on cost and clarity grounds.

## Scope of evidence

The course uses local, fictional data. Actual HTTP tests establish the corresponding origin behavior. Browser observations require a real browser run with its conditions recorded. Studying a supplied explanation, or exporting a transcript, does not independently establish authorship or execution.
