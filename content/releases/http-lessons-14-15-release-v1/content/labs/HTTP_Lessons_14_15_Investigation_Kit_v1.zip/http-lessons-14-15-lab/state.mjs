import { readFileSync, writeFileSync } from 'node:fs';
const file = new URL('./cases/incident/data.json', import.meta.url);
const baseline = { title: 'Riverside cafe notice', closingTime: '17:00', editorNote: 'Opening draft checked' };
const command = process.argv[2];
if (process.argv.length !== 3 || !['baseline', 'later', 'title', 'note', 'show'].includes(command)) {
  console.error('Choose one incident data command: baseline, later, title, note, show');
  process.exitCode = 1;
} else {
  const state = command === 'baseline' ? baseline : JSON.parse(readFileSync(file, 'utf8'));
  if (command === 'later') state.closingTime = '18:00';
  if (command === 'title') state.title = 'Riverside cafe update';
  if (command === 'note') state.editorNote = 'Internal wording review completed';
  if (command !== 'show') writeFileSync(file, JSON.stringify(state, null, 2) + '\n');
  console.log(JSON.stringify(state, null, 2));
  console.log('This affects incident source data only. Code, observations, and browser state are untouched.');
}
