const buttons = [...document.querySelectorAll('button[data-mode]')];
for (const button of buttons) {
  button.addEventListener('click', async () => {
    for (const item of buttons) item.disabled = true;
    document.querySelector('#message').textContent = 'Reading…';
    try {
      const target = new URL(document.querySelector('#target').value, location.origin);
      if (target.origin !== location.origin || target.pathname !== '/api/notice') throw new Error('Use /api/notice on this local origin.');
      const response = await fetch(target, { cache: button.dataset.mode });
      const text = await response.text();
      document.querySelector('#action').textContent = `${button.textContent}: ${target.pathname}${target.search}`;
      document.querySelector('#status').textContent = String(response.status);
      document.querySelector('#policy').textContent = response.headers.get('cache-control') ?? '(absent)';
      document.querySelector('#etag').textContent = response.headers.get('etag') ?? '(absent)';
      document.querySelector('#body').textContent = text || '(no body exposed to page code)';
      document.querySelector('#message').textContent = 'Finished. Compare this with the origin log.';
    } catch (error) {
      document.querySelector('#message').textContent = `Read failed: ${error.message}. The previous completed result remains below.`;
    } finally { for (const item of buttons) item.disabled = false; }
  });
}
