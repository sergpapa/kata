---
lesson_id: LS-M020-02
kit_version: "1.0.0-draft"
purpose: "Learner-owned notes for guided practice"
---

# My local café investigation

Use words, pasted output, or another format that lets you explain what happened. The sample output in the lesson is an example; record your own observations here. If setup is blocked, describe the obstacle rather than filling in an expected result as though you observed it.

## My setup

- Operating system:
- Output of `node --version`:
- Port chosen:
- Startup message:
- Help I used, if any:

## 1. Ask for the menu

Before opening the address, I predict:

The URL I actually opened:

The browser displayed:

The matching terminal log entry:

I think these observations are connected because:

## 2. Change only the path

My prediction for `/opening-hours`:

My prediction for `/opening-times`:

| Request I made | What the browser displayed | Matching log entry |
| --- | --- | --- |
| Opening hours | | |
| Opening times | | |

What stayed the same in the address, and why that matters:

## 3. Stop and restart the program

Before stopping, I predict what will happen to the already-visible menu:

Before stopping, I predict what will happen when I make a fresh request:

How I stopped the program and what the terminal reported:

What I observed before reloading:

What I observed after reloading or navigating afresh:

How I restarted it:

What restarting changed:

## 4. Use another port

New start command:

New successful startup message:

New browser URL:

Observed response and matching log entry:

Why changing the path and changing the port have different meanings:

How I stopped this instance when finished:

## 5. Explain it without the walkthrough

Why opening `server.mjs` in an editor is different from running it:

Why Nora's and Sam's identical loopback URLs can reach different processes:

One thing I can now explain:

One thing I still want help understanding:
