# HTTP Lesson 2: the local café

Start with [the student lesson](HTTP_Lesson_02_Student_Edition_v1.md). It explains the addresses, commands, observations, and recovery steps in order.

This folder contains a small working HTTP server. You will run it on your computer and ask it for a menu using a browser. Node.js supplies all the software libraries it needs; there are no project packages to install.

## Files

| File | Purpose |
| --- | --- |
| `HTTP_Lesson_02_Student_Edition_v1.md` | Full lesson, guided practice, answers, and setup help |
| `server.mjs` | The supplied JavaScript program |
| `Practice_Notes.md` | A place to record predictions and actual observations |
| `Instructor_Notes.md` | Teaching boundaries, exercise review guidance, and verification limits |
| `author-verification.json` | Machine-readable results from the author's local runtime checks |
| `manifest.json` | Version and file identities for authors and course tooling |

## Command reminder after reading the lesson

Use Node.js 24.x and a terminal opened in this extracted folder.

To check the installed runtime:

```sh
node --version
```

To start the café on its default local port:

```sh
node server.mjs
```

After the listening message appears, open this URL in your browser:

```text
http://127.0.0.1:4312/menu
```

Keep the terminal open while the server is running. Focus that terminal and press **Ctrl+C** to stop it. The source file remains available for your next start.

To use the alternative port from the lesson, first stop the earlier café, then run:

```sh
node server.mjs 4313
```

Use `http://127.0.0.1:4313/menu` in the browser after that successful start. If a port is already occupied, follow the explanation printed by the program and the lesson's setup help.

## Scope

The program listens only at `127.0.0.1` in the environment where you run Node.js. The lesson expects the browser to run directly in that same operating system environment. The program serves fixed text; it does not save submissions, change your files, fetch other websites, or require a cloud account.

Author verification exercised the program on Linux with Node.js v24.19.0. Native Windows/macOS use, the GUI browser workflow, and learner usability still need rehearsal before this draft becomes a published course lesson.
