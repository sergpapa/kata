// Lesson 2: a small cafe that answers requests on your own computer.
// Run: node server.mjs
// Or choose the port: node server.mjs 4313
import { createServer } from 'node:http';

// 1. Choose the local address and port before starting the server.
const HOST = '127.0.0.1';
const portText = process.argv[2] ?? '4312';
const port = Number(portText);

if (process.argv.length > 3 || !/^\d+$/.test(portText) || port < 1024 || port > 65535) {
  console.error('Choose one whole-number port from 1024 to 65535.');
  console.error('Example: node server.mjs 4313');
  process.exit(1);
}

// 2. Describe the content available at each path.
// This example supplies text directly; it does not read files from URL paths.
const pages = new Map([
  ['/', 'The local cafe is open.\nVisit /menu or /opening-hours.\n'],
  ['/menu', 'Tea\nCoffee\nHot chocolate\n'],
  ['/opening-hours', 'Monday-Friday: 08:00-17:00\nSaturday-Sunday: Closed\n'],
]);

// 3. Choose an answer each time a request arrives.
const server = createServer((request, response) => {
  let path;
  let status;
  let body;

  try {
    path = new URL(request.url, `http://${HOST}:${port}`).pathname;
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      status = 405;
      body = 'This cafe accepts GET and HEAD requests.\n';
      response.setHeader('Allow', 'GET, HEAD');
    } else if (pages.has(path)) {
      status = 200;
      body = pages.get(path);
    } else {
      status = 404;
      body = '404 Not Found\nThis cafe does not have that page.\nTry /menu or /opening-hours.\n';
    }
  } catch {
    path = '(invalid target)';
    status = 400;
    body = '400 Bad Request\nThe cafe could not read that request target.\n';
  }

  response.writeHead(status, {
    'Content-Type': 'text/plain; charset=utf-8',
    // Keep the first local exercise focused on contacting the running server.
    // Stored responses and this header are explained in the caching module.
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(body),
  });
  response.end(request.method === 'HEAD' ? undefined : body);
  console.log(`${request.method} ${path} -> ${status}`);
});

// 4. Make startup success or failure visible in the terminal.
server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`The cafe could not start: ${HOST}:${port} is already in use.`);
    console.error('If another cafe lesson is running, stop it in its terminal with Ctrl+C.');
    console.error('Otherwise choose a different port, for example: node server.mjs 4314');
    console.error('Use the port printed by the successful start in your browser address.');
  } else {
    console.error(`The cafe could not start (${error.code ?? 'unknown error'}).`);
    console.error('Keep this message and use the lesson setup help.');
  }
  process.exitCode = 1;
});

server.listen(port, HOST, () => {
  console.log(`Cafe server is listening on http://${HOST}:${port}`);
  console.log(`Open in your browser: http://${HOST}:${port}/menu`);
  console.log('Leave this terminal open while you use the cafe.');
  console.log('To stop: focus this terminal and press Ctrl+C.');
});

// 5. Release this server's listening port when the learner stops the program.
let stopping = false;
function stopServer() {
  if (stopping) return;
  stopping = true;
  server.close(() => {
    console.log('Cafe server stopped. The server.mjs file is still on your computer.');
  });
  server.closeAllConnections();
}
process.on('SIGINT', stopServer);
process.on('SIGTERM', stopServer);
