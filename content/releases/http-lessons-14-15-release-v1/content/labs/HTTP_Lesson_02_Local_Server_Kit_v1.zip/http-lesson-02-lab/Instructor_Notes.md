---
document_id: FSSE-HTTP-LAB-02-INSTRUCTOR
version: "1.0.0-draft"
date: "2026-09-11"
lesson_id: LS-M020-02
runtime_target: "Node.js 24.x"
status: "Author-verified local fixture; learner and platform rehearsal pending"
---

# Instructor notes: addresses and a local server

## Placement and purpose

This kit accompanies the rewritten Lesson 2 after the conceptual request/response introduction. It teaches how an address, a running service, a source file, and a terminal command relate. It is a new introductory fixture, separate from the earlier conditional-caching investigation.

The default course entrant is a nondeveloper. In the main course sequence, M020 follows basic programming, editor, and terminal preparation. This lesson refreshes the relevant tool use and provides setup-repair routes. It does not require a beginner to understand asynchronous Node.js handlers before operating the supplied example.

The learner should already be able to explain browser/client/server roles, a request and its response, a method and path in a supplied message, and the introductory `200` versus `404` distinction. The lesson introduces the port and running-process concepts rather than using them as unexplained entry tests.

## Learning sequence and boundaries

The lesson develops one setting: the café from Lesson 1, now inside a building containing several services. It uses that setting to distinguish destination, service selection, and requested content, then replaces the comparison with the actual local URL and listening-process explanation.

The practical sequence is start, observe the menu, change the path, request an unknown path, stop, make a fresh request, restart, and move to a different port. Demonstration and supported interpretation precede the shorter independent task. Complete answers remain available in the student lesson.

Keep these qualifications in the author's model:

- A host name is not generally a one-to-one identifier of a physical computer. The direct numeric loopback case is intentionally narrow.
- A port is part of a network endpoint, not a global program ID. Service binding can depend on address, transport, and configuration. The lesson only needs the behavior of this ordinary single listener.
- Loopback is relative to a network environment. Native desktop, WSL, containers, virtual machines, and remote development can introduce distinct boundaries. Do not silently assume a remote terminal and a local browser share one.
- `localhost` can resolve to IPv4 or IPv6 loopback. The fixture binds explicitly to `127.0.0.1`, and the main exercise consistently uses that literal address.
- A browser retaining a drawn document is different from receiving a new response. Ask for a fresh request after the process stops.
- A log line states what this server handled and chose to send. It is not a full traffic capture, proof of client receipt, or a proof that the user interface rendered correctly.
- The beginner `404` case is explicitly an unavailable path in this fixture. It is not a general assertion that every `404` proves the resource does not exist.

Full URL grammar, DNS, certificate setup, browser caching internals, parser design, and formal origin policy are later topics. The supplied source is open for inspection, but this lesson does not assess every line of it.

## Fixture contract

| Property | Contract |
| --- | --- |
| Runtime | Node.js 24.x; built-in `node:http` only; no package installation |
| Start command | `node server.mjs`, or one optional numeric port argument |
| Listener | IPv4 loopback `127.0.0.1`; explicit port, default `4312` |
| Port input | Decimal whole-number text from `1024` to `65535`; invalid or extra arguments produce explanatory output and a nonzero exit |
| Successful startup | Prints the actual listening address and the `/menu` URL after binding succeeds |
| Occupied port | Reports the conflict, suggests stopping a known earlier lesson or selecting another port, and exits nonzero; does not kill the existing listener or silently switch ports |
| `/` | `200`, a short introduction and the two available paths |
| `/menu` | `200`, the three-drink text from Lesson 1 |
| `/opening-hours` | `200`, weekday hours and weekend closure |
| Other ordinary paths | `404`, a short explanation |
| Methods | GET supplies content; HEAD supplies corresponding metadata with no body; other methods reach an explanatory `405` with `Allow: GET, HEAD` |
| Content | `text/plain; charset=utf-8`; explicit byte length; predetermined text |
| Cache behavior | Responses include `Cache-Control: no-store` to keep this initial experiment focused on contacting the service; teaching its semantics is deferred |
| Queries | Route selection uses the parsed pathname; query parameters do not customize content in this fixture |
| Logs | One application summary per handled request, showing method, parsed path, and chosen status; browser-generated requests can add lines |
| Stop | Ctrl+C/SIGINT or SIGTERM stops this server, closes its HTTP connections, and prints the stopped message |
| Persistence and networking | No file reads from URL paths, file writes, database, outbound fetches, dependency downloads, or dynamic evaluation of submitted code |

The route handler is a small educational example rather than a complete production server. Node's own HTTP parser can reject malformed traffic before the application handler runs. The URL parser can normalize paths; the lesson uses simple literal paths and does not define raw-byte routing guarantees.

The shutdown closes active HTTP connections as well as the listener so the beginner can stop the small fixture promptly. A later production-service lesson must teach graceful draining rather than generalizing this behavior to all applications.

## Evidence to review

| Target understanding | Useful evidence | Feedback if missing |
| --- | --- | --- |
| File versus running process | Learner explains why the source survives a stop and why reopening it does not serve requests | Revisit the start/stop observations and ask which program is currently executing the file |
| Destination components | Learner identifies scheme, host, port, and path in their actual URL | Change one component in a supplied comparison and ask what destination or request choice changes |
| One service, several paths | Menu and hours observations with the same host/port and distinct matching logs | Return to the two requests without starting another process |
| HTTP response versus no response | Distinguishes the unknown-path response from a fresh attempt after stopping | Compare what the running café logged with the stopped-process situation; separate browser-generated wording from server content |
| Evidence versus appearance | Explains why an old visible menu does not establish current service availability | Ask what new action would test whether the service still answers |
| Transfer of local meaning | Explains Nora's and Sam's separate loopback destinations | Revisit which environment the requesting browser occupies |

The notes are self-reported practice evidence. Assisted setup, supplied transcripts, and explanation-only completion should remain distinguishable from personally operating the tools. Do not fail an HTTP concept check because software installation is blocked. Equally, do not infer independent tool competence from copied expected output.

This kit does not replace or complete the original LS-HTTP-01 source/cache exercises. Their obligations remain mapped to later lessons in the curriculum-refinement document. The new candidate lesson and kit versions must retain their own identity when the app imports them.

## Verification performed

Author checks ran on Linux in the available execution environment using Node.js **v24.19.0**. They started real child processes, made local HTTP requests, sent a stop signal, and checked behavior afterward.

| Check | Observed result |
| --- | --- |
| Default startup and menu | Successful bind/start message on `127.0.0.1:4312`; `200` and the exact expected menu body; declared text content type and no-store header |
| Same service, different paths | `/opening-hours` and `/` succeeded; `/opening-times` returned `404` |
| Occupied port | A second instance failed with the intended explanation; the first remained available |
| Declared method/query behavior | HEAD returned no body with the matching menu length; POST returned `405` and the Allow header; a menu query retained the expected menu content |
| Stop and source survival | SIGINT stopped the process successfully; a subsequent connection attempt was refused; `server.mjs` remained present |
| Alternative and original port | Successful operation on `4313`, shutdown, and successful restart at the original port |
| Invalid port arguments | `0`, `80`, `65536`, `abc`, and `4312.5` were rejected before listening |

These checks establish the program's exercised behavior in this environment. They do not establish Windows/macOS operation, VS Code menu and keyboard behavior on each platform, browser rendering or policy behavior, screen-reader usability, learner comprehension, or full platform integration.

Before learner release, rehearse the native GUI path on the supported operating systems and browsers, including the stopped-server observation and occupied-port recovery. Trial the lesson with people meeting its entry assumptions, observe vocabulary and setup gaps, and calibrate duration from actual activity. A passing code check does not validate a lesson.

## Content integration

Import the lesson as ordered sections with the diagram and prose equivalent together. Bind prompts to this lesson's start/stop and address observations; do not reuse the advanced entity-tag prediction from the old prototype reader. Keep the runtime exercise local and preserve the distinction between marked-studied progress and submitted evidence.

For the next lesson, reuse these observed text responses while explaining HTML and structured data. Add new fixture behavior only with a versioned contract and updated instructions. Keep working examples separate from the later deliberately faulty caching scenarios so the learner first knows what correct behavior means.

## Reference checks

- [MDN: URL components](https://developer.mozilla.org/en-US/docs/Learn_web_development/Howto/Web_mechanics/What_is_a_URL) for naming the parts used in this bounded example.
- [RFC 6761: localhost](https://www.rfc-editor.org/rfc/rfc6761.html#section-6.3) for the special loopback name.
- [IANA: special-purpose IPv4 addresses](https://www.iana.org/assignments/iana-ipv4-special-registry/iana-ipv4-special-registry.xhtml) for loopback designation.
- [Node.js release information](https://nodejs.org/en/about/previous-releases) for the supported release-line choice, checked on 2026-09-11.
- [Node.js 24 HTTP server API](https://nodejs.org/docs/latest-v24.x/api/http.html#serverclosecallback) for server lifecycle behavior and the distinction between closing the listener and active connections.
- [VS Code terminal documentation](https://code.visualstudio.com/docs/terminal/basics) for workspace terminal behavior and configured interaction differences.

