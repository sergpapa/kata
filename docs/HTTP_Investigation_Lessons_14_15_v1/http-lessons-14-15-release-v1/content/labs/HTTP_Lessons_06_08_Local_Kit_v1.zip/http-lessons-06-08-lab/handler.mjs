import { sendJson } from './support/send-json.mjs';

export function handleRequest(request, response) {
  const path = new URL(request.url, 'http://127.0.0.1').pathname;

  if (path === '/api/menu') {
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      response.setHeader('Allow', 'GET, HEAD');
      sendJson(request, response, 405, { error: 'Method not allowed' });
      return;
    }

    sendJson(request, response, 200, {
      title: 'Cafe menu',
      drinks: ['Tea', 'Coffee', 'Hot chocolate'],
    });
    return;
  }

  sendJson(request, response, 404, { error: 'Not found' });
}
