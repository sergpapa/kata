# Café lab for HTTP Lessons 6–8

Read Lesson 6 for the guided explanation. Extract the whole ZIP and open `http-lessons-06-08-lab` in VS Code. Use Node.js 24.x and curl on your ordinary desktop. In Windows PowerShell use `curl.exe` explicitly. No package installation, cloud account, database, or container is needed.

## Start and inspect

From the lab folder:

```sh
node --version
node server.mjs
```

Run each command separately. Leave the server running in Terminal A. In Terminal B:

```sh
curl -i "http://127.0.0.1:4317/api/menu"
```

Default port: **4317**. An alternative is `node server.mjs 4318`; substitute the printed port in every manual request. Stop your recognized previous copy with Ctrl+C or choose the alternative. Do not stop an unfamiliar process.

The listener binds only to `127.0.0.1`. Browser/client and Node should run on the same native desktop. Remote workspaces, containers, and WSL networking need separate setup and are not part of this rehearsal.

## Choose the right activity

All commands below run from the lab root. Stop the preceding manual server before starting another on the same port.

| Activity | Manual start | File to read/edit | Automated checks |
| --- | --- | --- | --- |
| Lesson 6 | `node server.mjs` | `handler.mjs` | No test run required yet |
| Lesson 7 | `node server.mjs` | `handler.mjs` | `node --test checks/lesson-07.test.mjs` |
| Lesson 8 first incident | `node incidents/hours/server.mjs` | `incidents/hours/handler.mjs` | `node --test checks/lesson-08.test.mjs` |
| Lesson 8 changed case | `node incidents/transfer/server.mjs` | `incidents/transfer/handler.mjs` | `node --test checks/transfer.test.mjs` |

The starter lacks hours. The incident copies deliberately violate the agreement in different ways. Their checks are **expected to fail before the lesson's implementation or repair**. The Lesson 7 fresh starter has four passing and four failing tests. A syntax error or missing file is not the intended failure.

Each test command imports the corresponding saved file and starts short-lived HTTP servers on temporary local ports. It does not contact the process on 4317. Tests and manual requests answer related but different questions. Save, restart the manual server, and repeat the relevant curl requests after an edit.

## Files and contracts

- `handler.mjs` is the small starter you will change.
- `support/send-json.mjs` writes JSON responses and implements HEAD without a body.
- `support/start-server.mjs` runs the chosen handler and prints its identity and request summaries.
- `checks` contains supplied assertions and a local HTTP client helper.
- `incidents` contains separate faulty implementations so you can retain your successful Lesson 7 work.
- `reference` contains optional hints and complete worked replacements. These files are written for their intended destination's relative imports; read or copy them to that destination rather than running them in the reference folder.
- `Practice_Notes.md` is an optional place to record your actual observations.

GET menu must return `{ "title": "Cafe menu", "drinks": ["Tea", "Coffee", "Hot chocolate"] }`. The new GET hours response must contain `{ "weekdays": "08:00-17:00", "weekend": "Closed" }`. The same query-free pathname selects the same data even with `?source=lesson`. Known paths accept GET and HEAD; other methods receive 405 and Allow. Unknown paths receive 404 under this lab's path-first policy. HEAD never includes a body. The lesson tables specify the tested cases.

This is a bounded teaching service. It does not parse request bodies, write business data, authenticate users, or implement rate limiting. Cache/security headers are fixed helper settings with later teaching destinations. There are no external dependencies or outbound application requests.

## Reset without losing your work

Stop your manual server. Save your notes and edited files elsewhere if you want to retain them. Extract the original ZIP into a **new folder** and open that folder for a fresh attempt. The startup message prints the handler location so you can confirm which copy is active. Do not overwrite a folder containing work you want to keep.

To compare with a complete answer, the intended replacements are:

| Reference file | Destination within the lab |
| --- | --- |
| `reference/lesson-07-handler.mjs` | `handler.mjs` |
| `reference/lesson-08-handler.mjs` | `incidents/hours/handler.mjs` |
| `reference/transfer-handler.mjs` | `incidents/transfer/handler.mjs` |

## If something differs

| Symptom | Useful first check |
| --- | --- |
| `node` not found | Return to the Node setup instructions from Lesson 2 and reopen the terminal after installation |
| Cannot find a module/file | Open the whole extracted lab; check the terminal's folder and the exact command |
| Address already in use | Stop the previous recognized lab process or choose 4318 |
| curl cannot connect | Confirm a successful startup, same computer, and matching host/port |
| `/` returns 404 | This kit offers API paths, not a home page; request `/api/menu` |
| Tests pass but curl disagrees | Save/restart, check process label/source location, and compare the exact request address |
| Test runner reports an assertion | Compare expected and actual values against the lesson's current stage |
| Tests report syntax or import errors | Repair the file structure or edit; this is different from the intended missing-feature failure |

Author verification and limits are in `Instructor_Notes.md` and `author-verification.json`. Supplied descriptions are not evidence that you executed the lab yourself.
