import { handleRequest } from './handler.mjs';
import { startServer } from '../../support/start-server.mjs';

startServer(handleRequest, 'Lesson 8 hours investigation', new URL('./handler.mjs', import.meta.url));
