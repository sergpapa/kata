import test from 'node:test';
import assert from 'node:assert/strict';
import { requestOnce } from './http-client.mjs';

const hours = { weekdays: '08:00-17:00', weekend: 'Closed' };

export function checkHoursContract(handleRequest) {
  test('GET menu preserves the original content', async () => {
    const result = await requestOnce(handleRequest, 'GET', '/api/menu');
    assert.equal(result.status, 200);
    assert.equal(result.headers['content-type'], 'application/json');
    assert.deepEqual(JSON.parse(result.body), { title: 'Cafe menu', drinks: ['Tea', 'Coffee', 'Hot chocolate'] });
  });
  test('GET hours supplies the agreed opening hours', async () => {
    const result = await requestOnce(handleRequest, 'GET', '/api/hours');
    assert.equal(result.status, 200);
    assert.equal(result.headers['content-type'], 'application/json');
    assert.deepEqual(JSON.parse(result.body), hours);
  });
  test('GET hours with a query still selects the hours path', async () => {
    const result = await requestOnce(handleRequest, 'GET', '/api/hours?source=lesson');
    assert.equal(result.status, 200);
    assert.deepEqual(JSON.parse(result.body), hours);
  });
  test('HEAD hours has metadata for the JSON and no body', async () => {
    const result = await requestOnce(handleRequest, 'HEAD', '/api/hours');
    const getResult = await requestOnce(handleRequest, 'GET', '/api/hours');
    assert.equal(result.status, 200);
    assert.equal(result.body, '');
    assert.equal(result.headers['content-type'], 'application/json');
    assert.equal(Number(result.headers['content-length']), Buffer.byteLength(getResult.body));
  });
  test('POST hours is refused with the declared allowed methods', async () => {
    const result = await requestOnce(handleRequest, 'POST', '/api/hours');
    assert.equal(result.status, 405);
    assert.deepEqual(result.headers.allow.split(',').map((item) => item.trim()).sort(), ['GET', 'HEAD']);
    assert.deepEqual(JSON.parse(result.body), { error: 'Method not allowed' });
  });
  test('GET unknown path remains missing', async () => {
    const result = await requestOnce(handleRequest, 'GET', '/api/unknown');
    assert.equal(result.status, 404);
    assert.deepEqual(JSON.parse(result.body), { error: 'Not found' });
  });
  test('POST unknown path follows this lab contract and remains missing', async () => {
    const result = await requestOnce(handleRequest, 'POST', '/api/unknown');
    assert.equal(result.status, 404);
  });
  test('HEAD unknown path remains missing and has no body', async () => {
    const result = await requestOnce(handleRequest, 'HEAD', '/api/unknown');
    assert.equal(result.status, 404);
    assert.equal(result.body, '');
  });
}
