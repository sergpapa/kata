import { handleRequest } from '../handler.mjs';
import { checkHoursContract } from './contract-cases.mjs';

checkHoursContract(handleRequest);
