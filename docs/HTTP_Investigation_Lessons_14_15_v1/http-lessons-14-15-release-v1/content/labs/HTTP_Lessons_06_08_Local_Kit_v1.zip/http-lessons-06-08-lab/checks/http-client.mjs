// Author-supplied harness: one real local HTTP exchange, isolated from port 4317.
import { createServer, request } from 'node:http';
import { once } from 'node:events';

export async function requestOnce(handler, method, path) {
  const server = createServer(handler);
  const ready = once(server, 'listening');
  server.listen(0, '127.0.0.1');
  await ready;
  try {
    return await new Promise((resolve, reject) => {
      const outgoing = request({ hostname: '127.0.0.1', port: server.address().port, method, path, agent: false }, (incoming) => {
        const chunks = [];
        incoming.on('data', (chunk) => chunks.push(chunk));
        incoming.on('error', reject);
        incoming.on('end', () => resolve({
          status: incoming.statusCode,
          headers: incoming.headers,
          body: Buffer.concat(chunks).toString('utf8'),
        }));
      });
      outgoing.on('error', reject);
      outgoing.setTimeout(3000, () => outgoing.destroy(new Error('Local test request timed out')));
      outgoing.end();
    });
  } finally {
    await new Promise((resolve, reject) => {
      server.close((error) => error ? reject(error) : resolve());
      server.closeAllConnections();
    });
  }
}
