import { handleRequest } from '../incidents/hours/handler.mjs';
import { checkHoursContract } from './contract-cases.mjs';

checkHoursContract(handleRequest);
