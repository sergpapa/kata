import { handleRequest } from '../incidents/transfer/handler.mjs';
import { checkHoursContract } from './contract-cases.mjs';

checkHoursContract(handleRequest);
