# My HTTP Lessons 6–8 notes

Use this file or your preferred notes tool. Preserve an initial prediction separately from the result and revised explanation. Omit unrelated local paths or personal data when sharing.

## Environment

- Date and lesson:
- Node version / operating system:
- Kit and running activity label:
- Port used:
- Setup help needed:

## Lesson 6: one request through the code

- Prediction:
- Method and target actually requested:
- Status / content observed:
- Path value and decision taken:
- Selected data and helper behavior:
- What I changed in my explanation:
- Help used / open questions:

## Lesson 7: one contract change

- Requested behavior:
- Baseline failure:
- Implementation change:
- Positive and negative cases checked:
- Result of the deliberately wrong weekend value:
- How I restored the correct value:
- How I checked the manual process after testing saved source:
- Help used / evidence limits:

## Lesson 8: first investigation

- Reported symptom:
- Exact failing request and control request:
- Observations:
- Hypotheses and discriminating checks:
- Cause supported by source and response:
- Repair and failing-before/passing-after evidence:
- Why an incomplete alternative fails:
- Help used / remaining uncertainty:

## Later changed case

- Observations before looking at the solution:
- How this cause differs:
- Repair and checks:
- Help used / next question:
