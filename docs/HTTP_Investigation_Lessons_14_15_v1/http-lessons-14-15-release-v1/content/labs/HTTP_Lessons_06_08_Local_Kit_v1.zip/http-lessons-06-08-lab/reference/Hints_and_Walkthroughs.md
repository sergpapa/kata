# Hints and complete walkthroughs

These explanations are available whenever you need them. There is no waiting requirement. Record which insight came from help if you later discuss independence. A supplied walkthrough is not a report of your execution.

## Lesson 7: adding hours

**Direction:** Compare the requested behavior with the existing menu branch. Which path is not handled yet?

**Diagnostic:** Follow GET hours through the starter. It skips the menu block and reaches the fallback. The new branch needs to run before that fallback and return after answering.

**Complete explanation:** Add a branch for `/api/hours`. Keep its method decision consistent with the known menu resource, then send the agreed hours data with 200. Reuse the JSON helper so HEAD remains body-free. Retain the menu and unknown-path behavior. Save, run the eight checks, restart the manual server, and inspect its responses. `lesson-07-handler.mjs` is a complete replacement for the main `handler.mjs`.

## Lesson 8: wrong content under 200

**Direction:** Separate receiving a reply from receiving the required information.

**Subsystem hint:** Compare the incident's selected response data with the data defined in the source.

**Diagnostic:** For `/api/hours`, write down the result of `routes[path]`. Is it the same object the hours contract describes?

**Complete explanation:** The hours key exists, so it reaches the successful branch. However, the route table maps that key to `menu`. The JSON helper serializes the supplied object correctly, producing a valid but wrong reply. Change the association to `hours`, preserve the menu entry, and rerun the contract checks. An unconditional final response containing hours would break the menu case. `lesson-08-handler.mjs` is a complete replacement for `incidents/hours/handler.mjs`.

## Changed case: the documented path is missing

**Direction:** The original incident had a known path with wrong content. Does this response show the same situation?

**Diagnostic:** Compare the requested pathname with the keys actually defined in the transfer route table. Read their spelling character by character.

**Complete explanation:** The table contains `/api/hour`, while the contract and client use `/api/hours`. The membership check for the documented path fails, so the fallback returns 404 before content selection. Change the key to `/api/hours`. Sending clients to the accidental singular path would not restore the agreed interface. The existing known-path, method, and missing-path rules should continue to hold. `transfer-handler.mjs` is a complete replacement for `incidents/transfer/handler.mjs`.

## If no hint matches your observation

Stop assuming the seeded defect explains everything. Check the running activity, saved file, port, and request. An additional edit, syntax error, or wrong process can create a different symptom. Preserve the evidence and explain what remains unresolved; that is more useful than reporting the expected answer without reproducing it.
