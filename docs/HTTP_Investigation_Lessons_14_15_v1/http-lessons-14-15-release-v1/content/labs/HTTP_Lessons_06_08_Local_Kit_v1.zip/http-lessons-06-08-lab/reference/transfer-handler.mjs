import { sendJson } from '../../support/send-json.mjs';

export function handleRequest(request, response) {
  const path = new URL(request.url, 'http://127.0.0.1').pathname;
  const routes = {
    '/api/menu': { title: 'Cafe menu', drinks: ['Tea', 'Coffee', 'Hot chocolate'] },
    '/api/hours': { weekdays: '08:00-17:00', weekend: 'Closed' },
  };
  if (!Object.hasOwn(routes, path)) {
    sendJson(request, response, 404, { error: 'Not found' });
    return;
  }
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.setHeader('Allow', 'GET, HEAD');
    sendJson(request, response, 405, { error: 'Method not allowed' });
    return;
  }
  sendJson(request, response, 200, routes[path]);
}
