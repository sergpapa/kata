# Instructor notes

This is a new local kit for LS-M020-06 through LS-M020-08, not an update to the previous kit. Preserve the main starter's missing hours feature and the two seeded defects in distribution. Reference implementations belong in their declared destinations when testing or studying complete replacements.

## Teaching intent

Lesson 6 develops causal source tracing and includes a narrow JavaScript reading bridge. Lesson 7 teaches a behavior contract, positive/negative cases, an expected failing baseline, a bounded implementation, and the distinction between testing saved source and contacting a long-running process. Lesson 8 introduces hypothesis/evidence discipline and a different source organization before the investigation depends on it.

The first defect maps a known hours path to menu data. The transfer defect spells the hours key incorrectly, producing 404 rather than wrong content under 200. These are bounded foundation tasks, not the promised advanced caching or security work. Their purpose is to make later mechanism-rich investigations teachable.

Do not penalize a learner for unknown syntax that the bridge fails to explain. Record the missing explanation and repair the lesson or prerequisite route. Expected test failures are part of the exercise; infrastructure failures are not grading evidence.

## Verification policy

Run only course-authored fixtures and reference implementations for author verification. Learner submissions are reviewed as source/evidence and are not executed by the learning platform. All runtime verification reported for this kit refers to the environment and cases in `author-verification.json`.

Author rehearsal must check original baselines, fixed versions, the wrong-weekend perturbation, an incomplete repair that breaks menu behavior, HEAD without a body, and the manual startup/stop path. Checks compare observable content and protocol fields, not variable names. The reference solutions are not a mandatory code structure.

Native Windows/macOS GUI interactions, VS Code UI, and integration into the user's separate app require their own checks. Do not infer those from a Linux CLI rehearsal. Lesson content and reference solutions can be visible together when requested; full help remains available.
