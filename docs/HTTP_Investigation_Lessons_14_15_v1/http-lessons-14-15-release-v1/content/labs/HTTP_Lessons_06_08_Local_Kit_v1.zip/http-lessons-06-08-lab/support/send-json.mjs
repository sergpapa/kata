// This helper translates an application value into a JSON HTTP response.
export function sendJson(request, response, status, data) {
  const body = JSON.stringify(data, null, 2) + '\n';
  response.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });

  if (request.method === 'HEAD') {
    response.end();
    return;
  }

  response.end(body);
}
