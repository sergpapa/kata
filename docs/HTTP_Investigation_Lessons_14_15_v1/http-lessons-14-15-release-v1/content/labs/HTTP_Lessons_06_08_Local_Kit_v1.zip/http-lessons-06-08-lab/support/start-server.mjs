import { createServer } from 'node:http';

export function startServer(handler, label, sourceUrl) {
  const portText = process.argv[2] ?? '4317';
  const port = Number(portText);
  if (process.argv.length > 3 || !/^\d+$/.test(portText) || port < 1024 || port > 65535) {
    console.error('Use one whole-number port from 1024 to 65535, for example: node server.mjs 4318');
    process.exitCode = 1;
    return;
  }
  const server = createServer((request, response) => {
    // Register before dispatch so each completed response can be observed.
    response.on('finish', () => console.log(`${request.method} ${JSON.stringify(request.url)} -> ${response.statusCode}`));
    try {
      handler(request, response);
    } catch (error) {
      console.error(`Request handler failed: ${error.name}`);
      if (!response.headersSent) {
        response.writeHead(500, { 'Content-Type': 'text/plain', 'Cache-Control': 'no-store' });
        response.end('The local handler failed. Inspect the handler and restart after saving.\n');
      } else {
        response.destroy();
      }
    }
  });
  server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
      console.error(`127.0.0.1:${port} is already in use. Stop your previous lab in its own terminal, or select 4318.`);
    } else {
      console.error(`The lab could not start: ${error.code ?? error.name}`);
    }
    process.exitCode = 1;
  });
  server.listen(port, '127.0.0.1', () => {
    console.log(`${label} is listening on http://127.0.0.1:${port}`);
    console.log(`Handler source: ${sourceUrl.href}`);
    console.log('Use a second terminal for curl. After editing, save, stop with Ctrl+C, and restart this command.');
  });
  let stopping = false;
  const stop = () => {
    if (stopping) return;
    stopping = true;
    server.close(() => console.log('Local cafe stopped. Your files remain on disk.'));
    server.closeAllConnections();
  };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
