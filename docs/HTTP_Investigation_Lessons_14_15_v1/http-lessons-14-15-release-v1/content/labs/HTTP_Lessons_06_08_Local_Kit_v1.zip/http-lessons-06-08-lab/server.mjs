import { handleRequest } from './handler.mjs';
import { startServer } from './support/start-server.mjs';

startServer(handleRequest, 'Lessons 6-7 starter', new URL('./handler.mjs', import.meta.url));
