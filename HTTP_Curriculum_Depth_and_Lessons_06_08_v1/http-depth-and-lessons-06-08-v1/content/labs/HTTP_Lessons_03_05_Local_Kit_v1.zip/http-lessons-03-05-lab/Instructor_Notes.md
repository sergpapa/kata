# Instructor notes: shared cafe lab, Lessons 3–5

Lab ID: `FSSE-HTTP-LAB-03-05`. Version: `1.0.0-draft`. Authored 2026-09-11.

## Teaching contract

The learner has met client/server, GET, 200/404, URL parts, and a running local process in Lessons 1–2. Lesson 3 develops representation formats. Lesson 4 introduces curl response inspection and HEAD. Lesson 5 introduces browser request inspection and separate document/resource/data requests.

The server is supplied material. Reading its complete implementation, writing async JavaScript, editing a handler, diagnosing caching, and fixing a production application are not prerequisites or graded outcomes here. Source is available to an interested learner. Later lessons should revisit it after their prerequisites are taught.

Use the authored full explanations whenever the learner requests them. These introductory activities offer guided evidence of a narrow task, not independent HTTP mastery. Preserve the actual assistance used; no numeric grade or artificial hint level is defined by this kit.

## Observable contract

The three menu representations contain the same title and drink names. `/menu-as-text` returns the same bytes as `/menu.html`, with a different Content-Type. All supplied routes use `Cache-Control: no-store`; `X-Content-Type-Options: nosniff` makes the declared type important in supported browser contexts. These headers are fixture choices, not newly assessed curriculum knowledge.

The `/cafe` HTML references the script and image. It does **not** request `/api/menu` automatically. The script registers two button handlers; a click triggers the corresponding fetch. Successful data fills the list using textContent and DOM creation. An HTTP error clears the old menu and displays the JSON error explanation. A connection or parsing failure displays a generic investigation message. The script checks response.ok because fetch receiving a 404 response does not itself reject its promise.

Lesson 5's success path has four relevant requests: document, script, image, then JSON after the click. Browser timing and incidental requests can vary. Do not grade the total row count or assert a strict ordering between the image and script. The tab icon is embedded so it normally causes no additional HTTP request. Inline styles add no stylesheet request. Repeated button clicks legitimately create repeated API rows.

The missing-menu case remains within this local fixture. It demonstrates a scoped HTTP response failure; it is not a security exploitation exercise.

## Runtime and containment

Node.js 24.x, standard library only. Default `127.0.0.1:4315`; optional port argument from 1024 through 65535. No persistence, outbound fetch, shell execution, dynamic evaluation, third-party scripts, package installation, or serving arbitrary filesystem paths. Assets are loaded once from explicit paths relative to the module. Restart after an intentional asset edit; editing source is outside the first-five trial.

The lab is designed for the learner's native desktop environment. Do not start it on the teaching platform on the learner's behalf or treat arbitrary learner submissions as trusted fixtures.

## Verification and review limits

The accompanying `author-verification.json` records checks actually run against this kit. Use its result and scope rather than inferring tests from the presence of source code. Browser-tool instructions are grounded in official documentation; a real owner session remains needed to assess readability, setup friction, DevTools labels, and application rendering.

Windows and macOS native execution are not established by a Linux check. The shared lab and lesson prose are owner-review drafts, not independently reviewed public releases.
