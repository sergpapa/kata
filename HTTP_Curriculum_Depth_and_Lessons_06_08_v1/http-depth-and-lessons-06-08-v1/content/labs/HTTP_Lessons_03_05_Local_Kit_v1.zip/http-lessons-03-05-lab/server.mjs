// Local teaching fixture for Lessons 3–5. Run with Node.js 24.x.
// Start: node server.mjs     Alternate port: node server.mjs 4316
import { createServer } from 'node:http';
import { readFileSync } from 'node:fs';

const HOST = '127.0.0.1';
const portText = process.argv[2] ?? '4315';
const port = Number(portText);
if (process.argv.length > 3 || !/^\d+$/.test(portText) || port < 1024 || port > 65535) {
  console.error('Choose one whole-number port from 1024 to 65535.');
  console.error('Example: node server.mjs 4316');
  process.exit(1);
}

// These paths are an explicit list. A request cannot choose a filesystem file.
const readAsset = (name) => readFileSync(new URL(name, import.meta.url));
let menuHtml;
let cafeHtml;
let menuScript;
let cupSvg;
try {
  menuHtml = readAsset('./public/menu.html');
  cafeHtml = readAsset('./public/cafe.html');
  menuScript = readAsset('./public/menu-page.js');
  cupSvg = readAsset('./public/cup.svg');
} catch (error) {
  console.error(`The cafe could not read a supplied lab file (${error.code ?? 'unknown error'}).`);
  console.error('Extract the whole kit and keep the public folder beside server.mjs.');
  process.exit(1);
}

const menu = { title: 'Cafe menu', drinks: ['Tea', 'Coffee', 'Hot chocolate'] };
const json = (value) => JSON.stringify(value, null, 2) + '\n';
const pages = new Map([
  ['/', ['text/plain; charset=utf-8', 'Cafe lab for Lessons 3-5.\nLesson 3: /menu.txt, /menu.html, /api/menu, /menu-as-text\nLesson 4: use curl to inspect these responses.\nLesson 5: /cafe\n']],
  ['/menu.txt', ['text/plain; charset=utf-8', 'Cafe menu\nTea\nCoffee\nHot chocolate\n']],
  ['/menu.html', ['text/html; charset=utf-8', menuHtml]],
  ['/menu-as-text', ['text/plain; charset=utf-8', menuHtml]],
  ['/api/menu', ['application/json', json(menu)]],
  ['/cafe', ['text/html; charset=utf-8', cafeHtml]],
  ['/assets/menu-page.js', ['text/javascript; charset=utf-8', menuScript]],
  ['/assets/cup.svg', ['image/svg+xml', cupSvg]],
]);

const server = createServer((request, response) => {
  let path;
  let status = 200;
  let contentType = 'text/plain; charset=utf-8';
  let body;
  try {
    path = new URL(request.url, `http://${HOST}:${port}`).pathname;
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      status = 405;
      body = 'This cafe accepts GET and HEAD requests.\n';
      response.setHeader('Allow', 'GET, HEAD');
    } else if (pages.has(path)) {
      [contentType, body] = pages.get(path);
    } else if (path.startsWith('/api/')) {
      status = 404;
      contentType = 'application/json';
      body = json({ error: 'Menu not found' });
    } else {
      status = 404;
      body = '404 Not Found\nThis cafe does not have that page.\nTry /menu.txt, /menu.html, /api/menu, or /cafe.\n';
    }
  } catch {
    path = '(invalid target)';
    status = 400;
    body = '400 Bad Request\nThe cafe could not read that request target.\n';
  }

  response.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': Buffer.byteLength(body),
    // Later lessons teach these headers. They keep this fixture predictable.
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  response.end(request.method === 'HEAD' ? undefined : body);
  console.log(`${request.method} ${path} -> ${status}`);
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`The cafe could not start: ${HOST}:${port} is already in use.`);
    console.error('Stop your previous copy in its terminal with Ctrl+C, or use: node server.mjs 4316');
    console.error('Use the port printed by the successful start in every browser URL and curl command.');
  } else {
    console.error(`The cafe could not start (${error.code ?? 'unknown error'}).`);
  }
  process.exitCode = 1;
});
server.listen(port, HOST, () => {
  console.log(`Cafe lab for Lessons 3-5 is listening on http://${HOST}:${port}`);
  console.log(`Lesson 3 starts at http://${HOST}:${port}/menu.txt`);
  console.log(`Lesson 5 uses http://${HOST}:${port}/cafe`);
  console.log('Leave this terminal open. To stop: focus it and press Ctrl+C.');
});

let stopping = false;
function stopServer() {
  if (stopping) return;
  stopping = true;
  server.close(() => console.log('Cafe server stopped. The lab files are still on your computer.'));
  server.closeAllConnections();
}
process.on('SIGINT', stopServer);
process.on('SIGTERM', stopServer);
