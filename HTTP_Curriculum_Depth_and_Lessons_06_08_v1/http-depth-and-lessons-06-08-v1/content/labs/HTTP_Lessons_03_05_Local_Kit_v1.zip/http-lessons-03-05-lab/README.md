# Cafe lab for HTTP Lessons 3–5

This is the small local practice server used by the three accompanying lessons. It is separate from the learning application your coder is building and from the Lesson 2 kit.

Read Lesson 3 for the guided setup and explanations. Extract the whole ZIP, open the `http-lessons-03-05-lab` folder in VS Code, and check that `server.mjs` and the `public` folder appear together.

Use Node.js 24.x. In VS Code choose **Terminal → New Terminal**, then run:

```sh
node --version
```

When Node is available, start this lab:

```sh
node server.mjs
```

Wait for the listening message and leave that terminal open. The default address is `http://127.0.0.1:4315`. This differs from Lesson 2's default port, `4312`.

| Lesson | Starting point |
| --- | --- |
| 3: Formats | Open `http://127.0.0.1:4315/menu.txt` in your browser |
| 4: curl | Keep the server running and open a second terminal |
| 5: Network panel | Open `http://127.0.0.1:4315/cafe` in your browser |

Stop this server with **Ctrl+C** in its own terminal. On macOS this is Control+C. If text is selected, clear the selection first. The source files remain available to restart later.

If the port is occupied, stop your previous copy if you recognize it. Alternatively run:

```sh
node server.mjs 4316
```

Use the printed port in **every** URL and curl command. Do not stop an unfamiliar program to free a port.

This kit needs no `npm install`, package download, account, database, container, or cloud deployment. It binds only to IPv4 loopback. The lessons assume the browser, terminal, and Node run on the same computer in its ordinary desktop environment. A remote workspace, a container, and WSL networking need separate setup; use the native desktop terminal for this first trial.

## Routes

| Path | Successful GET response |
| --- | --- |
| `/menu.txt` | Plain text menu |
| `/menu.html` | HTML menu |
| `/api/menu` | JSON menu data |
| `/menu-as-text` | The exact HTML-menu body, labelled as plain text |
| `/cafe` | The Lesson 5 board, with menu buttons |
| `/assets/menu-page.js` | The board's JavaScript |
| `/assets/cup.svg` | The board's cup image |

`/api/missing-menu` deliberately returns an HTTP 404 response containing a JSON explanation. An unknown path outside `/api/` returns a plain text 404 response. HEAD requests have response headers but no body. Other methods receive 405; no request changes stored data.

`Practice_Notes.md` is an optional local place to write predictions and observations. Supplied lesson explanations are not evidence that you ran a command. Record what happened on your machine separately.

See `Instructor_Notes.md` and `author-verification.json` for the exact verification scope and known limits of this draft.
