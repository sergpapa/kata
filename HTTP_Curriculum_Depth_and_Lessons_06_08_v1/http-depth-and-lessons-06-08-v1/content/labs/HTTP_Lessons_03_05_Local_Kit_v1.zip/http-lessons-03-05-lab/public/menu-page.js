// Supplied behavior for Lesson 5. Reading or editing it is optional at this stage.
const loadButton = document.querySelector('#load-menu');
const missingButton = document.querySelector('#load-missing-menu');
const statusText = document.querySelector('#status');
const title = document.querySelector('#menu-title');
const list = document.querySelector('#drinks');

async function loadMenu(path) {
  loadButton.disabled = true;
  missingButton.disabled = true;
  statusText.textContent = 'Asking the cafe...';
  title.textContent = 'Drinks';
  list.replaceChildren();

  try {
    const response = await fetch(path);
    const data = await response.json();
    if (!response.ok) {
      statusText.textContent = `Menu unavailable: ${data.error ?? 'the cafe could not supply it'}.`;
      return;
    }
    title.textContent = data.title;
    for (const drink of data.drinks) {
      const item = document.createElement('li');
      item.textContent = drink;
      list.append(item);
    }
    statusText.textContent = 'Menu loaded.';
  } catch {
    statusText.textContent = 'The page could not load the menu. Check the request in the Network panel.';
  } finally {
    loadButton.disabled = false;
    missingButton.disabled = false;
  }
}

loadButton.addEventListener('click', () => loadMenu('/api/menu'));
missingButton.addEventListener('click', () => loadMenu('/api/missing-menu'));
