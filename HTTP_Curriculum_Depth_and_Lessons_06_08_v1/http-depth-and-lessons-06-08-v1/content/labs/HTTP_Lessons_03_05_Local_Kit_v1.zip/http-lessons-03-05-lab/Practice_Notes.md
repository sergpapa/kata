# My practice notes: HTTP Lessons 3–5

Keep the original prediction. Add the later observation below it, even when they disagree. If you study a supplied example without running it, label it “supplied example.”

## Environment

- Operating system and browser:
- Node version:
- Lab version and actual port:
- Setup help I used:

## Lesson 3: One menu in several forms

- Prediction before opening `/menu.html` and `/api/menu`:
- What I actually saw:
- What stayed the same across the three menu responses:
- What the JSON property `drinks` names:
- What happened at `/menu-as-text`:
- My explanation of a body versus its Content-Type header:
- A term or passage I still cannot explain:

## Lesson 4: Ask, inspect, compare

- Exact command and prediction before the first `-i` request:
- Actual status, Content-Type, and one body detail:
- Actual result for `/api/missing-menu`:
- Actual result while the server was stopped:
- Why these last two results are different:
- Actual method in the server log after `-I`:
- Help or a walkthrough I used:

## Lesson 5: A page's requests

- Prediction before opening the Network panel:
- Requests I found before pressing a menu button:
- Request URL, method, status, Content-Type, and one body detail after **Load menu**:
- What changed on the page:
- Evidence after **Try a missing menu**:
- My explanation of a successful document response alongside a failed menu request:
- One thing the panel does not let me conclude:
- Content or application friction to include in my review:

## Reflection after checking the explanations

- My earlier belief:
- Evidence that changed or strengthened it:
- My current explanation:
- What I would like help understanding:
